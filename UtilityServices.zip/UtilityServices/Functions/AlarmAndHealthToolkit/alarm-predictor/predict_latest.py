"""Predict alarm probabilities for recent measurements using a trained LightGBM model.

This module provides utilities for nightly inference runs that:
1. Filter to measurements with recent data (configurable lookback)
2. Calculate individual measurement alarm probabilities
3. Compute total system probability of at least one alarm occurring
"""

from dataclasses import dataclass
from pathlib import Path
from datetime import datetime
import argparse
import warnings

import numpy as np
import pandas as pd
import lightgbm as lgb

from src.models.train_lightgbm import infer_feature_columns
from src.models.baseline import load_phase1_dataset

# Categorical features used during training - must match for inference
CATEGORICAL_FEATURES = ["site_id", "measurement_type_id", "measurement_type_name", "day_of_week"]


@dataclass
class PredictionReport:
    """Container for prediction results and system-wide statistics."""
    predictions: pd.DataFrame  # Individual measurement predictions
    total_alarm_probability: float  # P(at least one alarm)
    most_recent_data_date: pd.Timestamp  # Most recent data point in dataset
    cutoff_date: pd.Timestamp  # Only measurements with data on/after this date included
    measurements_included: int  # Number of measurements in predictions
    measurements_excluded_stale: int  # Measurements filtered out due to stale data (date-based)
    measurements_excluded_missing_features: int  # Measurements dropped due to NaN features
    horizon_days: int  # Prediction horizon (1 or 7 days)
    
    @property
    def measurements_excluded(self) -> int:
        """Total excluded measurements (stale + missing features)."""
        return self.measurements_excluded_stale + self.measurements_excluded_missing_features


def filter_to_recent_measurements(
    df: pd.DataFrame,
    lookback_days: int = 0,
    reference_date: pd.Timestamp | None = None,
    feature_columns: list[str] | None = None,
) -> tuple[pd.DataFrame, pd.Timestamp, pd.Timestamp, int]:
    """
    Filter to only measurements with data within lookback_days of the reference date.

    Args:
        df: Feature dataframe with trend_day column.
        lookback_days: Days back from the reference date to include. 
                       0 means only measurements with data on the reference day.
        reference_date: Date to use as "now" for recency calculation. If None, uses
                        the most recent date from rows with complete (non-null) feature data.
        feature_columns: List of feature columns to check for completeness. If provided,
                         only rows with all these features non-null are considered valid.
                         This filters out erroneous entries that have dates but null values.

    Returns:
        Tuple of (filtered_df, most_recent_date, cutoff_date, excluded_count)
    """
    # Pre-filter to rows with complete feature data if feature_columns provided
    # This removes erroneous entries (valid dates but null features) BEFORE date filtering
    working_df = df
    if feature_columns:
        available_cols = [c for c in feature_columns if c in df.columns]
        if available_cols:
            valid_data_mask = df[available_cols].notna().all(axis=1)
            working_df = df[valid_data_mask].copy()
            dropped_incomplete = len(df) - len(working_df)
            if dropped_incomplete > 0:
                print(f"  Pre-filtered {dropped_incomplete} rows with incomplete feature data")
    
    if len(working_df) == 0:
        # No valid rows at all - return empty with fallback dates
        max_date_raw = df["trend_day"].max()
        most_recent_date = pd.Timestamp(max_date_raw)  # type: ignore[arg-type]
        cutoff_date: pd.Timestamp = most_recent_date - pd.Timedelta(days=lookback_days)  # type: ignore[assignment]
        return df.head(0), most_recent_date, cutoff_date, 0
    
    # Determine reference date
    if reference_date is not None:
        most_recent_date = reference_date
    else:
        # Auto-detect from valid (pre-filtered) data
        max_date_raw = working_df["trend_day"].max()
        most_recent_date = pd.Timestamp(max_date_raw)  # type: ignore[arg-type]
    
    cutoff_date = most_recent_date - pd.Timedelta(days=lookback_days)  # type: ignore[assignment]

    # Get latest trend_day for each measurement (from VALID rows only)
    latest_per_measurement = (
        working_df.groupby("measurement_id")["trend_day"]
        .max()
        .reset_index()
        .rename(columns={"trend_day": "latest_trend_day"})
    )

    # Filter to measurements with recent data
    recent_measurements = latest_per_measurement.loc[
        latest_per_measurement["latest_trend_day"] >= cutoff_date,
        "measurement_id"
    ]
    
    # Count excludes based on original unique measurements vs included
    all_measurements = df["measurement_id"].nunique()
    excluded_count = all_measurements - len(recent_measurements)

    # Keep only the latest VALID row per measurement for those with recent data
    filtered_df = (
        working_df.loc[working_df["measurement_id"].isin(recent_measurements)]  # type: ignore[union-attr]
        .sort_values(["measurement_id", "trend_day"])
        .groupby("measurement_id")
        .tail(1)
        .copy()
    )

    return filtered_df, most_recent_date, cutoff_date, excluded_count  # type: ignore[return-value]


def calculate_total_alarm_probability(probabilities: np.ndarray) -> float:
    """
    Calculate probability that at least one alarm occurs across all measurements.

    Uses complement probability: P(at least one) = 1 - Product(1 - p_i)
    This assumes alarm events are independent across measurements.

    Args:
        probabilities: Array of individual alarm probabilities for each measurement.

    Returns:
        Probability that at least one measurement will alarm within the horizon.
    """
    if len(probabilities) == 0:
        return 0.0

    # P(at least one alarm) = 1 - P(no alarms) = 1 - Π(1 - p_i)
    # Use log space for numerical stability with many small probabilities
    log_no_alarm = np.sum(np.log1p(-probabilities))  # log1p(-p) = log(1-p)
    prob_no_alarm = np.exp(log_no_alarm)
    total_probability = 1.0 - prob_no_alarm

    return float(total_probability)


def predict_from_dataframe(
    booster: lgb.Booster,
    df: pd.DataFrame,
    horizon: int,
    lookback_days: int = 0,
    reference_date: pd.Timestamp | None = None,
) -> PredictionReport:
    """
    Generate predictions for recent measurements from an in-memory DataFrame.

    Args:
        booster: Loaded LightGBM Booster model.
        df: Prepared phase1 dataset with features and labels.
        horizon: Prediction horizon in days (1 or 7).
        lookback_days: Only include measurements with data within this many days of 
                       the reference date. 0 = only the most recent day.
        reference_date: Optional date to use as "now" for recency filtering. If None,
                        uses the most recent date with valid (non-null) feature data.

    Returns:
        PredictionReport with individual predictions and system-wide statistics.
    """
    target_column = f"will_alarm_{horizon}d"
    if target_column not in df.columns:
        raise KeyError(f"Target column '{target_column}' not found in dataset.")

    # Get feature columns first - used for both validation and inference
    feature_columns = infer_feature_columns(df)

    print("\nFiltering to measurements with recent data...")
    # Pass feature columns so auto-detection only considers rows with complete data
    filtered_df, most_recent_date, cutoff_date, excluded_stale = filter_to_recent_measurements(
        df, lookback_days, reference_date=reference_date, feature_columns=feature_columns
    )
    print(f"  Reference date: {most_recent_date.date()}" + 
          (" (user-specified)" if reference_date else " (auto-detected from valid data)"))
    print(f"  Cutoff date: {cutoff_date.date()} (lookback={lookback_days} days)")
    print(f"  Measurements with recent dates: {len(filtered_df)}")
    print(f"  Measurements excluded (stale dates): {excluded_stale}")

    if len(filtered_df) == 0:
        warnings.warn("No measurements with recent data found!", UserWarning)
        empty_results = pd.DataFrame({
            "measurement_id": pd.Series(dtype="Int64"),
            "trend_day": pd.Series(dtype="datetime64[ns]"),
            "predicted_alarm_probability": pd.Series(dtype="float64"),
        })
        return PredictionReport(
            predictions=empty_results,
            total_alarm_probability=0.0,
            most_recent_data_date=most_recent_date,
            cutoff_date=cutoff_date,
            measurements_included=0,
            measurements_excluded_stale=excluded_stale,
            measurements_excluded_missing_features=0,
            horizon_days=horizon,
        )

    print("\nExtracting modeling feature columns...")
    print(f"  Using {len(feature_columns)} features.")

    X = filtered_df[feature_columns].copy()

    # Convert categorical columns to category dtype to match training
    for col in CATEGORICAL_FEATURES:
        if col in X.columns:
            try:
                X[col] = X[col].astype("category")
            except Exception:
                pass

    # Drop rows with NaNs in feature columns
    before_count = len(X)
    valid_mask = X.notna().all(axis=1)
    X = X[valid_mask]
    filtered_df = filtered_df[valid_mask]
    after_count = len(X)
    excluded_missing = before_count - after_count
    if excluded_missing > 0:
        print(f"  Dropped {excluded_missing} measurements with missing/null feature values.")
        print("  (This often indicates erroneous data entries with valid dates but null values)")
    if after_count == 0:
        warnings.warn(
            "No rows available after dropping NaNs in features. "
            "All recent measurements have missing feature values. "
            "Try specifying a reference_date to filter out erroneous future-dated entries.",
            UserWarning
        )
        empty_results = pd.DataFrame({
            "measurement_id": pd.Series(dtype="Int64"),
            "trend_day": pd.Series(dtype="datetime64[ns]"),
            "predicted_alarm_probability": pd.Series(dtype="float64"),
        })
        return PredictionReport(
            predictions=empty_results,
            total_alarm_probability=0.0,
            most_recent_data_date=most_recent_date,
            cutoff_date=cutoff_date,
            measurements_included=0,
            measurements_excluded_stale=excluded_stale,
            measurements_excluded_missing_features=excluded_missing,
            horizon_days=horizon,
        )

    print(f"\nGenerating predictions for {len(X)} measurements...")
    preds = np.asarray(booster.predict(X)).flatten()
    filtered_df["predicted_alarm_probability"] = preds

    # Calculate total system alarm probability
    total_prob = calculate_total_alarm_probability(preds)

    # Build result dataframe with useful columns
    result_columns = ["measurement_id", "trend_day", "predicted_alarm_probability"]
    # Add site_id and measurement_type_name if available for better context
    for extra_col in ["site_id", "measurement_type_name"]:
        if extra_col in filtered_df.columns:
            result_columns.insert(-1, extra_col)

    results = pd.DataFrame(filtered_df[result_columns])

    return PredictionReport(
        predictions=results,
        total_alarm_probability=total_prob,
        most_recent_data_date=most_recent_date,
        cutoff_date=cutoff_date,
        measurements_included=after_count,
        measurements_excluded_stale=excluded_stale,
        measurements_excluded_missing_features=excluded_missing,
        horizon_days=horizon,
    )


def predict_from_saved_model(
    model_path: Path,
    dataset_path: Path,
    horizon: int,
    lookback_days: int = 0,
    reference_date: pd.Timestamp | None = None,
) -> PredictionReport:
    """
    Load a saved LightGBM model and generate predictions for recent measurements.

    Args:
        model_path: Path to the saved LightGBM model file (.txt).
        dataset_path: Path to the prepared phase1 dataset (parquet or CSV).
        horizon: Prediction horizon in days (1 or 7).
        lookback_days: Only include measurements with data within this many days.
        reference_date: Optional date to use as "now" for recency filtering.

    Returns:
        PredictionReport with individual predictions and system-wide statistics.
    """
    print("\nLoading LightGBM model...")
    booster = lgb.Booster(model_file=str(model_path))
    print("Model loaded successfully.")

    print("\nLoading dataset...")
    df = load_phase1_dataset(dataset_path)
    print(f"Dataset loaded. Total rows: {len(df)}")

    return predict_from_dataframe(booster, df, horizon, lookback_days, reference_date)


def format_report(report: PredictionReport) -> str:
    """Format a PredictionReport as a human-readable summary string."""
    lines = [
        "",
        "=" * 70,
        f"ALARM PREDICTION REPORT - {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        "=" * 70,
        "",
        f"Prediction Horizon: {report.horizon_days} day(s)",
        f"Data Date Range: {report.cutoff_date.date()} to {report.most_recent_data_date.date()}",
        f"Measurements Analyzed: {report.measurements_included}",
        "Measurements Excluded:",
        f"  - Stale data (old dates): {report.measurements_excluded_stale}",
        f"  - Missing features (null values): {report.measurements_excluded_missing_features}",
        "",
        "-" * 70,
        "TOTAL SYSTEM ALARM PROBABILITY",
        "-" * 70,
        "",
        f"  P(at least one alarm in next {report.horizon_days}d) = {report.total_alarm_probability:.2%}",
        "",
        "  This is the probability that at least ONE of the monitored measurements",
        "  will trigger an alarm within the prediction horizon, assuming independence.",
        "",
    ]

    # Show top 10 highest risk measurements
    if len(report.predictions) > 0:
        top_n = min(10, len(report.predictions))
        top_risks = (
            report.predictions
            .sort_values("predicted_alarm_probability", ascending=False)
            .head(top_n)
        )

        lines.extend([
            "-" * 70,
            f"TOP {top_n} HIGHEST RISK MEASUREMENTS",
            "-" * 70,
            "",
        ])

        # Format as table
        for _, row in top_risks.iterrows():
            prob = row["predicted_alarm_probability"]
            meas_id = int(row["measurement_id"])
            site = row.get("site_id", "?")
            mtype = row.get("measurement_type_name", "?")
            date_val = row["trend_day"]
            # Convert to date string for display (handle potential NaT)
            try:
                date_str = pd.Timestamp(date_val).strftime("%Y-%m-%d")  # type: ignore[arg-type]
            except (ValueError, TypeError):
                date_str = "?"
            lines.append(f"  {prob:6.2%}  ID={meas_id:<6} Site={site:<8} Type={mtype}  ({date_str})")

        lines.append("")

    # Risk level summary
    if len(report.predictions) > 0:
        probs = report.predictions["predicted_alarm_probability"]
        high_risk = (probs >= 0.5).sum()
        medium_risk = ((probs >= 0.1) & (probs < 0.5)).sum()
        low_risk = (probs < 0.1).sum()

        lines.extend([
            "-" * 70,
            "RISK LEVEL SUMMARY",
            "-" * 70,
            "",
            f"  High Risk   (≥50%): {high_risk:4} measurements",
            f"  Medium Risk (10-50%): {medium_risk:4} measurements",
            f"  Low Risk    (<10%): {low_risk:4} measurements",
            "",
        ])

    lines.append("=" * 70)
    return "\n".join(lines)


def main():
    """CLI entrypoint for standalone predictions from saved dataset/model."""
    parser = argparse.ArgumentParser(
        description="Predict alarms for recent measurements using a trained LightGBM model."
    )
    parser.add_argument(
        "--model-path", type=Path, required=True,
        help="Path to LightGBM model (.txt)"
    )
    parser.add_argument(
        "--dataset-path", type=Path, required=True,
        help="Path to phase1_dataset.parquet or CSV"
    )
    parser.add_argument(
        "--horizon", type=int, choices=[1, 7], default=1,
        help="Prediction horizon (1 or 7 days)"
    )
    parser.add_argument(
        "--lookback-days", type=int, default=0,
        help="Include measurements with data within N days of most recent. 0=only most recent day."
    )
    parser.add_argument(
        "--reference-date", type=str, default=None,
        help="Override the 'now' date for recency filtering (format: YYYY-MM-DD). "
             "Useful for DB snapshots or testing with historical data."
    )
    parser.add_argument(
        "--output", type=Path, default=Path("outputs/predictions_latest.csv"),
        help="Output path for predictions CSV"
    )
    args = parser.parse_args()

    # Parse reference date if provided
    ref_date: pd.Timestamp | None = None
    if args.reference_date:
        try:
            parsed = pd.Timestamp(args.reference_date)
            # Check if parsing failed (NaT = Not a Time) using pd.isna() for reliability
            if bool(pd.isna(parsed)):
                print(f"Invalid date '{args.reference_date}', using auto-detection.")
            else:
                ref_date = parsed  # type: ignore[assignment]
                print(f"Using user-specified reference date: {parsed.date()}")
        except ValueError:
            print(f"Invalid date format '{args.reference_date}', expected YYYY-MM-DD. Using auto-detection.")

    report = predict_from_saved_model(
        model_path=args.model_path,
        dataset_path=args.dataset_path,
        horizon=args.horizon,
        lookback_days=args.lookback_days,
        reference_date=ref_date,
    )

    # Print human-readable report
    print(format_report(report))

    # Save predictions CSV
    args.output.parent.mkdir(parents=True, exist_ok=True)
    report.predictions.to_csv(args.output, index=False)
    print(f"Predictions saved to: {args.output}\n")


if __name__ == "__main__":
    main()
