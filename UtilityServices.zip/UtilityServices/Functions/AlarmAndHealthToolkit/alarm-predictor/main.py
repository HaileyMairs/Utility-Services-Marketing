"""Unified text menu to run Health Analyzer or Alarm Model (DB or CSV)."""

import sys
from pathlib import Path

# Ensure the script's directory is in sys.path for local imports
_script_dir = str(Path(__file__).parent.resolve())
if _script_dir not in sys.path:
    sys.path.insert(0, _script_dir)

from src import constants as C
from src.db_loader import load_phase1_tables_from_db
from src.data_loader import load_all_data_from_db

from health_analyzers.qc_analyzer import run_qc_analyzer
from health_analyzers.unit_health import run_unit_health
from health_analyzers.flatline_detector import run_detector
from health_analyzers.drift_detector import run_drift_detector

from connection_manager import get_connection, load_saved_connections

import importlib


# Database names used by this application
DB_OPSDC = "OPSDC"
DB_MCRWS_TELOG = "MCRWS-Telog"


def _get_validated_connection_string(db_name: str) -> str | None:
    """Get a validated connection string for the specified database.
    
    Uses get_connection() to test/prompt for the connection, then retrieves
    the saved connection string to pass to analyzers that create their own connections.
    
    Returns the connection string if successful, None if cancelled or failed.
    """
    # Test the connection (this will prompt user if needed and save if successful)
    conn = get_connection(db_name)
    if conn is None:
        return None
    
    # Close the test connection - analyzers will create their own
    conn.close()
    
    # Retrieve the saved connection string
    connections = load_saved_connections()
    conn_str = connections.get(db_name)
    
    if not conn_str:
        print(f"Error: Could not retrieve saved connection string for '{db_name}'.")
        return None
    
    return conn_str


def run_health_analyzer_db() -> None:
    """Run the QC analyzer using the OPSDC database."""
    conn_str = _get_validated_connection_string(DB_OPSDC)
    if conn_str is None:
        return
    
    try:
        run_qc_analyzer(conn_str)
    except Exception as e:
        print(f"\nError running Health Analyzer: {e}")
        print("Returning to main menu...")


def run_unit_health_db() -> None:
    """Run the unit health analyzer using the OPSDC database."""
    conn_str = _get_validated_connection_string(DB_OPSDC)
    if conn_str is None:
        return
    
    try:
        run_unit_health(conn_str)
    except Exception as e:
        print(f"\nError running Unit Health Analyzer: {e}")
        print("Returning to main menu...")


def run_flatline_detector_db() -> None:
    """Run the flatline detector using the OPSDC database."""
    conn_str = _get_validated_connection_string(DB_OPSDC)
    if conn_str is None:
        return
    
    try:
        run_detector(conn_str)
    except Exception as e:
        print(f"\nError running Flatline Detector: {e}")
        print("Returning to main menu...")


def run_drift_detector_db() -> None:
    """Run the drift detector using the OPSDC database."""
    conn_str = _get_validated_connection_string(DB_OPSDC)
    if conn_str is None:
        return
    
    try:
        run_drift_detector(conn_str)
    except Exception as e:
        print(f"\nError running Drift Detector: {e}")
        print("Returning to main menu...")


def run_phase1_from_db() -> None:
    """Run the Phase 1 pipeline using data from the MCRWS-Telog database."""
    conn = get_connection(DB_MCRWS_TELOG)
    if conn is None:
        return
    
    try:
        tables = load_phase1_tables_from_db(conn)
        bundle = load_all_data_from_db(tables)

        # The current pipeline entrypoint expects CSV paths; to avoid deep refactor we will
        # call the internal functions that run the steps using the DataBundle we made
        classified_alarms = importlib.import_module("src.alarm_filter").classify_alarms(bundle.alarms, bundle.alarm_defines)
        physical_alarms = importlib.import_module("src.alarm_filter").filter_physical_alarms(
            classified_alarms, bundle.measurements, bundle.measurement_types
        )
        feature_df = importlib.import_module("src.features.phase1_mvp").build_phase1_feature_matrix(
            bundle.trend,
            physical_alarms,
            bundle.measurements,
            bundle.measurement_types,
            max_ffill_gap_days=C.DEFAULT_MAX_FFILL_DAYS,
            rolling_window_days=C.PHASE1_ROLLING_WINDOW,
            history_window_days=C.PHASE1_ALARM_HISTORY_WINDOW,
        )
        labeled_df = importlib.import_module("src.labeling").generate_labels(feature_df, horizons=[1, 7])
        out_path = Path("outputs/alarm_dataset_from_db.parquet")
        out_path.parent.mkdir(parents=True, exist_ok=True)
        labeled_df.to_parquet(out_path, index=False)
        print(f"Saved prepared alarm dataset to: {out_path}")
    except Exception as e:
        print(f"\nError preparing alarm dataset: {e}")
        print("Returning to main menu...")
    finally:
        conn.close()


def run_phase1_from_csv(data_dir: Path) -> None:
    """Run Phase 1 pipeline from CSV files."""
    try:
        pipeline = importlib.import_module("src.pipeline_phase1")
        pipeline.run_phase1_pipeline(data_dir=data_dir, output_path=Path("outputs/alarm_dataset.parquet"), label_horizons=[1,7])
    except Exception as e:
        print(f"\nError preparing alarm dataset from CSV: {e}")
        print("Returning to main menu...")


def train_model_interactive():
    """Interactive model training workflow."""
    try:
        # Lazy import training utilities to avoid import errors on machines without lightgbm/libomp
        from src.models.train_lightgbm import (
            infer_feature_columns,
            prepare_train_test_split,
            train_model,
            _ensure_categorical_dtypes,
            evaluate_model,
        )
        from src.models.baseline import load_phase1_dataset

        # Prompt for dataset and training options, then train and optionally save model
        dataset_path = input("Prepared alarm dataset path [outputs/alarm_dataset_from_db.parquet]: ").strip() or "outputs/alarm_dataset_from_db.parquet"
        dataset = load_phase1_dataset(Path(dataset_path))
        print(f"Loaded dataset with {len(dataset)} rows and {len(dataset.columns)} columns")

        horizon_input = input("Target horizon (1 or 7) [1]: ").strip() or "1"
        try:
            horizon = int(horizon_input)
            if horizon not in (1, 7):
                print("Invalid horizon, defaulting to 1")
                horizon = 1
        except ValueError:
            horizon = 1

        target_column = f"will_alarm_{horizon}d"
        if target_column not in dataset.columns:
            print(f"Target column {target_column} not found in dataset. Aborting.")
            return

        exclude_input = input("Extra columns to exclude (space-separated) []: ").strip()
        exclude_cols = exclude_input.split() if exclude_input else []

        feature_columns = infer_feature_columns(dataset, exclude_cols)
        print(f"Using {len(feature_columns)} features")

        prepared = prepare_train_test_split(dataset, feature_columns, target_column)
        categorical = _ensure_categorical_dtypes(prepared, ["site_id", "measurement_type_id", "measurement_type_name", "day_of_week"])

        print("Training model...")
        model = train_model(
            prepared["train"],
            prepared["validation"],
            categorical,
            learning_rate=0.05,
            num_leaves=31,
            max_depth=-1,
            min_data_in_leaf=50,
            n_estimators=1000,
        )

        print("Evaluating on validation and test sets...")
        for split_name in ("validation", "test"):
            outcome, diag = evaluate_model(model, prepared[split_name], target_column, model_name="lightgbm_phase1")
            print(f"{outcome.model_name} -> {outcome.split_name}: AP={outcome.average_precision:.4f} ({outcome.positive_count}/{outcome.sample_count})")

        save = input("Save trained model to file? (y/n): ").strip().lower()
        if save == 'y':
            # Default filename includes horizon to differentiate 1d vs 7d models
            default_model_path = f"outputs/models/lightgbm_alarm_{horizon}d.txt"
            model_path = input(f"Model path [{default_model_path}]: ").strip() or default_model_path
            Path(model_path).parent.mkdir(parents=True, exist_ok=True)
            model.booster_.save_model(str(model_path))
            print(f"Saved model to {model_path}")
    except Exception as e:
        print(f"\nError during model training: {e}")
        print("Returning to main menu...")


def predict_latest_from_db():
    """Load fresh data from DB, build features, and predict alarms using a trained model.
    
    Designed for nightly runs - filters to only measurements with recent data and
    calculates total system alarm probability.
    """
    try:
        import lightgbm as lgb
        import pandas as pd
        from predict_latest import predict_from_dataframe, format_report

        # Ask for horizon to determine default model path
        horizon_input = input("Prediction horizon (1 or 7 days) [1]: ").strip() or "1"
        try:
            horizon = int(horizon_input)
            if horizon not in (1, 7):
                print("Invalid horizon, defaulting to 1")
                horizon = 1
        except ValueError:
            horizon = 1

        # Ask for lookback days - controls how recent data must be
        lookback_input = input("Days of recent data to consider (0=only most recent day) [0]: ").strip() or "0"
        try:
            lookback_days = int(lookback_input)
            if lookback_days < 0:
                print("Invalid lookback, defaulting to 0")
                lookback_days = 0
        except ValueError:
            lookback_days = 0

        # Ask for optional reference date override (useful for DB snapshots or demos)
        ref_date_input = input(
            "Reference date override (YYYY-MM-DD) or Enter for auto-detect []: "
        ).strip()
        reference_date: pd.Timestamp | None = None
        if ref_date_input:
            try:
                parsed = pd.Timestamp(ref_date_input)
                # Check if parsing failed (NaT = Not a Time) using pd.isna() for reliability
                if bool(pd.isna(parsed)):
                    print(f"  Invalid date '{ref_date_input}', using auto-detection.")
                else:
                    reference_date = parsed  # type: ignore[assignment]
                    print(f"  Using reference date: {parsed.date()}")
            except ValueError:
                print(f"  Invalid date format '{ref_date_input}', using auto-detection.")

        default_model_path = f"outputs/models/lightgbm_alarm_{horizon}d.txt"
        model_path = input(f"Trained model path [{default_model_path}]: ").strip() or default_model_path

        if not Path(model_path).exists():
            print(f"Model file not found: {model_path}")
            return

        print("\n--- Loading data from database ---")
        conn = get_connection(DB_MCRWS_TELOG)
        if conn is None:
            return
        
        try:
            tables = load_phase1_tables_from_db(conn)
            bundle = load_all_data_from_db(tables)

            # For live predictions, filter trend data to recent window to avoid
            # gaps causing NaN features. Use 60 days to ensure enough data for
            # rolling features and alarm history.
            # Reference point is the most recent VALID data in DB (capped at today to ignore future-dated junk)
            PREDICTION_DATA_WINDOW_DAYS = 60
            if not bundle.trend.empty and "trend_data_time" in bundle.trend.columns:
                today = pd.Timestamp.now().normalize()
                raw_max_date = bundle.trend["trend_data_time"].max()
                
                # Cap at today to filter out future-dated garbage entries
                if raw_max_date > today:
                    print(f"  WARNING: Found future-dated entries up to {raw_max_date.date()}, ignoring them")
                    bundle.trend = bundle.trend[bundle.trend["trend_data_time"] <= today].copy()
                
                # Now find the actual max date from valid data
                if bundle.trend.empty:
                    print("  ERROR: No valid trend data after filtering future dates")
                else:
                    max_trend_date = bundle.trend["trend_data_time"].max()
                    cutoff_date = max_trend_date - pd.Timedelta(days=PREDICTION_DATA_WINDOW_DAYS)
                    original_rows = len(bundle.trend)
                    bundle.trend = bundle.trend[bundle.trend["trend_data_time"] >= cutoff_date].copy()
                    filtered_rows = original_rows - len(bundle.trend)
                    print(f"  Most recent valid data: {max_trend_date.date()}")
                    print(f"  Using {PREDICTION_DATA_WINDOW_DAYS}-day window: {cutoff_date.date()} to {max_trend_date.date()}")
                    if filtered_rows > 0:
                        print(f"  Kept {len(bundle.trend)} trend rows (removed {filtered_rows} older rows)")

            print("\n--- Building feature matrix ---")
            classified_alarms = importlib.import_module("src.alarm_filter").classify_alarms(bundle.alarms, bundle.alarm_defines)
            physical_alarms = importlib.import_module("src.alarm_filter").filter_physical_alarms(
                classified_alarms, bundle.measurements, bundle.measurement_types
            )
            feature_df = importlib.import_module("src.features.phase1_mvp").build_phase1_feature_matrix(
                bundle.trend,
                physical_alarms,
                bundle.measurements,
                bundle.measurement_types,
                max_ffill_gap_days=C.DEFAULT_MAX_FFILL_DAYS,
                rolling_window_days=C.PHASE1_ROLLING_WINDOW,
                history_window_days=C.PHASE1_ALARM_HISTORY_WINDOW,
            )

            print("\n--- Generating labels ---")
            labeled_df = importlib.import_module("src.labeling").generate_labels(feature_df, horizons=[1, 7])
            print(f"Dataset ready: {len(labeled_df)} rows")

        finally:
            conn.close()

        print(f"\n--- Loading model from {model_path} ---")
        booster = lgb.Booster(model_file=str(model_path))

        print("\n--- Generating predictions for measurements with recent data ---")
        report = predict_from_dataframe(booster, labeled_df, horizon, lookback_days, reference_date)

        # Print the formatted report with total probability and summary
        print(format_report(report))

        # Save predictions to CSV
        output_path = Path("outputs/predictions_latest_db.csv")
        output_path.parent.mkdir(parents=True, exist_ok=True)
        report.predictions.to_csv(output_path, index=False)
        print(f"Predictions saved to: {output_path} ({report.measurements_included} measurements)")
    except Exception as e:
        print(f"\nError during prediction: {e}")
        print("Returning to main menu...")


def score_dataset_interactive():
    """Interactive dataset scoring workflow."""
    try:
        dataset_path = input("Dataset path to score [outputs/alarm_dataset_from_db.parquet]: ").strip() or "outputs/alarm_dataset_from_db.parquet"
        
        # Ask for horizon to determine default model path
        horizon_input = input("Model horizon (1 or 7) [1]: ").strip() or "1"
        try:
            horizon = int(horizon_input)
            if horizon not in (1, 7):
                print("Invalid horizon, defaulting to 1")
                horizon = 1
        except ValueError:
            horizon = 1
        
        default_model_path = f"outputs/models/lightgbm_alarm_{horizon}d.txt"
        model_path = input(f"Trained model path [{default_model_path}]: ").strip() or default_model_path
        threshold_input = input("Probability threshold for positive label [0.5]: ").strip() or "0.5"
        try:
            threshold = float(threshold_input)
        except ValueError:
            threshold = 0.5

        if not Path(model_path).exists():
            print(f"Model file not found: {model_path}")
            return

        from src.models.train_lightgbm import infer_feature_columns
        from src.models.baseline import load_phase1_dataset
        import lightgbm as lgb

        dataset = load_phase1_dataset(Path(dataset_path))
        feature_columns = infer_feature_columns(dataset)
        features = dataset[feature_columns].copy()

        # Coerce typical categorical columns (best-effort)
        for col in ["site_id", "measurement_type_id", "measurement_type_name", "day_of_week"]:
            if col in features.columns:
                try:
                    features[col] = features[col].astype("category")
                except Exception:
                    pass

        # Drop rows with NaNs in feature columns
        before = len(features)
        features = features.dropna()
        after = len(features)
        if after == 0:
            print("No rows available after dropping NaNs in features. Aborting.")
            return
        if after < before:
            print(f"Dropped {before-after} rows with missing features.")

        # Load Booster and predict
        booster = lgb.Booster(model_file=str(model_path))
        probs = booster.predict(features)

        out = features.copy()
        out["pred_probability"] = probs
        out["pred_label"] = (out["pred_probability"] >= threshold).astype(int)

        out_path = Path(f"outputs/predictions_{Path(model_path).stem}.csv")
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out.to_csv(out_path, index=False)
        print(f"Saved predictions to {out_path} (rows={len(out)})")
    except Exception as e:
        print(f"\nError during scoring: {e}")
        print("Returning to main menu...")


def execute_menu_choice(choice: str) -> bool:
    """
    Execute a single menu choice.
    Returns True if the program should continue to menu, False if it should exit.
    """
    if choice == '1':
        run_phase1_from_db()
    elif choice == '2':
        dd = input("Data directory containing CSV exports [.]: ").strip() or "."
        run_phase1_from_csv(Path(dd))
    elif choice == '3':
        train_model_interactive()
    elif choice == '4':
        score_dataset_interactive()
    elif choice == '5':
        predict_latest_from_db()
    elif choice == '6':
        run_health_analyzer_db()
    elif choice == '7':
        run_unit_health_db()
    elif choice == '8':
        run_flatline_detector_db()
    elif choice == '9':
        run_drift_detector_db()
    elif choice == '0':
        print("Goodbye.")
        return False
    else:
        print("Invalid choice.")
    return True


def main_menu():
    """Display the main menu and handle user selections."""
    while True:
        print("\n" + "="*60)
        print("TRINITY - ALARM & HEALTH ANALYZER - MAIN MENU")
        print("="*60)
        print("--- Alarm Prediction ---")
        print("1. Prepare alarm dataset (features & labels) — from DB")
        print("2. Prepare alarm dataset (features & labels) — from CSV directory")
        print("3. Train LightGBM model (use prepared alarm dataset)")
        print("4. Score dataset with trained LightGBM model (inference)")
        print("5. Predict latest alarms from DB (live inference)")
        print("--- Health Analyzers ---")
        print("6. Run Health Analyzer (QC summary) - from DB")
        print("7. Run Unit Health Scores - from DB")
        print("8. Run Flatline Detector - from DB")
        print("9. Run Drift Detection - from DB")
        print("---")
        print("0. Exit")
        choice = input("Enter choice (0-9): ").strip()
        if not execute_menu_choice(choice):
            sys.exit(0)


def main():
    """
    Main entry point.
    Supports --option flag to auto-select a menu choice without showing the menu.
    Usage: python main.py --option 1
    """
    import argparse
    
    parser = argparse.ArgumentParser(
        description="TRINITY - Alarm & Health Analyzer CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Menu Options:
  1  Prepare alarm dataset from DB
  2  Prepare alarm dataset from CSV
  3  Train LightGBM model
  4  Score dataset with model
  5  Predict latest alarms from DB
  6  Run QC Analyzer
  7  Run Unit Health Scores
  8  Run Flatline Detector
  9  Run Drift Detector
  0  Exit
        """
    )
    parser.add_argument(
        "--option", "-o",
        type=str,
        choices=["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"],
        help="Auto-select a menu option (skips the menu)"
    )
    
    args = parser.parse_args()
    
    try:
        if args.option:
            # Run the specified option directly without showing menu
            print(f"\n--- Running option {args.option} ---\n")
            execute_menu_choice(args.option)
            # After running, show the menu for further interaction
            print("\n--- Workflow complete. Returning to menu. ---")
            main_menu()
        else:
            # No option specified, show the interactive menu
            main_menu()
    except KeyboardInterrupt:
        print("\nInterrupted. Exiting.")
        sys.exit(0)


if __name__ == '__main__':
    main()
