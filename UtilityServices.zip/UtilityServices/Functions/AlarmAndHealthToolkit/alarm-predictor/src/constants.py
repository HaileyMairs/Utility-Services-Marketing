"""Shared configuration constants for the Alarm Predictor pipeline."""

from __future__ import annotations

import pandas as pd

# Minimum date boundary vetted during Phase 0 EDA
# Maximum date is dynamically set to current date to filter future-dated records
DATE_RANGE_MIN = pd.Timestamp("2014-03-06")

# Null tokens observed in raw CSV exports
CSV_NA_VALUES = ["", "NULL", "null", "None"]

# Alarm classification groupings (see PLAN.md)
SITE_PHYSICAL = [
    6000,
    6001,
    6002,
    6003,
    6004,
    6005,
    6006,
    6007,
    6008,
    6009,
    6010,
    6011,
    6012,
    6013,
    6014,
    6015,
]
MEASUREMENT_THRESHOLD = [2048, 2049, 2050, 2051]
BATTERY = [4000]
DATA_QUALITY = [2057, 2058, 2059]
RECORDER = [1024, 1025, 1026, 1027, 1028, 1029, 1030, 1031, 1032, 1033]
SYSTEM = [0, 1, 2, 3, 10]
CLEARANCE_KEYWORD = "normal"

# Phase 1 defaults
DEFAULT_MAX_FFILL_DAYS = 3
PHASE1_ROLLING_WINDOW = 7
PHASE1_ALARM_HISTORY_WINDOW = 30
DAYS_SINCE_LAST_ALARM_SENTINEL = 9999  # Large sentinel value for measurements that have never alarmed

# Time-based dataset splits defined in PLAN.md (Phase 1)
PHASE1_VALIDATION_START = pd.Timestamp("2024-01-01")
PHASE1_TEST_START = pd.Timestamp("2024-10-01")
PHASE1_TRAIN_END = PHASE1_VALIDATION_START - pd.Timedelta(days=1)
PHASE1_VALIDATION_END = PHASE1_TEST_START - pd.Timedelta(days=1)


