"""Label generation utilities for the Alarm Predictor pipeline."""

from __future__ import annotations

from typing import Iterable

import pandas as pd


def _safe_groupby_apply(grouped, func):
    """Call GroupBy.apply with include_groups=False when available."""
    try:
        return grouped.apply(func, include_groups=False)
    except TypeError:
        return grouped.apply(func)


def _future_alarm_label(group: pd.DataFrame, horizon_days: int) -> pd.Series:
    """Compute binary label indicating alarms within the upcoming horizon.
    
    Current implementation: Label = 1 if ANY alarm occurs in next N days.
    This includes both continuing alarms and new alarms.
    
    OPTION C (not implemented): To predict only NEW alarms, modify to:
        current_alarm = group["has_physical_alarm"].astype(int)
        shifted = current_alarm.shift(-1)
        future_max = <compute as below>
        return future_max & (~current_alarm)  # Only label if NO alarm today
    """
    shifted = group["has_physical_alarm"].astype(int).shift(-1)
    future_max = (
        shifted.fillna(0)
        .iloc[::-1]
        .rolling(window=horizon_days, min_periods=1)
        .max()
        .iloc[::-1]
    )
    future_max = future_max.astype("Int8")

    if horizon_days > 0:
        future_max.iloc[-horizon_days:] = pd.NA

    return future_max


def generate_labels(
    feature_df: pd.DataFrame, horizons: Iterable[int] = (1, 7)
) -> pd.DataFrame:
    """Attach `will_alarm_{h}d` targets for the requested horizons.

    Args:
        feature_df: Feature dataframe containing `has_physical_alarm`.
        horizons: Iterable of horizon lengths (days) for which to build labels.

    Returns:
        Copy of the feature dataframe limited to rows with full future coverage
        plus the generated target columns.
    """
    working_df = feature_df.sort_values(["measurement_id", "trend_day"]).reset_index(
        drop=True
    )
    label_columns: list[str] = []

    for horizon in horizons:
        column_name = f"will_alarm_{horizon}d"
        labels = _safe_groupby_apply(
            working_df.groupby("measurement_id", group_keys=False),
            lambda grp: _future_alarm_label(grp, horizon),
        )
        # Ensure proper index alignment by reindexing to match working_df
        # This handles edge cases where groupby might reorder or have index gaps
        if hasattr(labels, 'reindex'):
            # Reindex to ensure alignment with working_df's index
            aligned_labels = labels.reindex(working_df.index)
            working_df[column_name] = aligned_labels.values
        elif hasattr(labels, 'values'):
            # Fallback: assume order is preserved (less safe but works in most cases)
            working_df[column_name] = labels.values
        else:
            # Legacy fallback for older pandas handling
            working_df[column_name] = labels.reset_index(drop=True).values
        label_columns.append(column_name)

    # Drop tail rows lacking enough future data for every requested horizon
    valid_mask = working_df[label_columns].notna().all(axis=1)
    labeled_df = working_df.loc[valid_mask].copy()

    for column_name in label_columns:
        labeled_df[column_name] = labeled_df[column_name].astype("Int8")

    return labeled_df


