"""Database loader utilities for MS SQL Server (pyodbc).

This module centralizes the pyodbc connection creation and simple
table-loading helpers so the Health Analyzer and Phase1 pipeline can
optionally pull data directly from the OPSDC database instead of CSVs.
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Optional

import pandas as pd

# Import pyodbc type for annotations only (avoids runtime import on systems without the driver)
if TYPE_CHECKING:
    import pyodbc


def connect_from_connection_string(conn_str: str) -> "pyodbc.Connection":
    """Create a pyodbc connection from a full ODBC connection string.

    The user is expected to paste a connection string like:
      DRIVER={ODBC Driver 17 for SQL Server};SERVER=...;DATABASE=...;UID=...;PWD=...

    Returns a live pyodbc.Connection or raises on failure.
    """
    # import pyodbc lazily so environments without the driver can still import this module
    import pyodbc

    return pyodbc.connect(conn_str)


def safe_read_sql(query: str, conn) -> pd.DataFrame:
    try:
        return pd.read_sql(query, conn)
    except Exception as exc:
        print(f"[db_loader] SQL read failed: {exc}")
        return pd.DataFrame()


def load_phase1_tables_from_db(conn: "pyodbc.Connection") -> dict[str, pd.DataFrame]:
    """Load the minimal set of tables Phase1 expects from the DB.

    Returns a dict with keys: trend, alarms, alarm_defines, measurements, measurement_types
    
    Raises:
        RuntimeError: If critical tables (trend, measurements) fail to load or are empty.
    """
    out = {}
    out["trend"] = safe_read_sql(
        "SELECT trend_data_time AS trend_data_time, measurement_id, trend_data_interval, trend_data_interval_sum, trend_data_min, trend_data_avg, trend_data_max, trend_data_count FROM TREND_DATA_DAILY",  # noqa: E501
        conn,
    )
    out["alarms"] = safe_read_sql("SELECT * FROM ALARM_LOG", conn)
    out["alarm_defines"] = safe_read_sql("SELECT * FROM ALARM_DEFINES", conn)
    out["measurements"] = safe_read_sql("SELECT * FROM MEASUREMENTS", conn)
    out["measurement_types"] = safe_read_sql("SELECT * FROM MEASUREMENT_TYPES", conn)
    
    # Validate critical tables - trend and measurements are required for pipeline
    if out["trend"].empty:
        raise RuntimeError(
            "Failed to load trend data from database (TREND_DATA_DAILY table empty or query failed). "
            "Check database connection and table permissions."
        )
    if out["measurements"].empty:
        raise RuntimeError(
            "Failed to load measurements from database (MEASUREMENTS table empty or query failed). "
            "Check database connection and table permissions."
        )
    
    # Warn about empty non-critical tables
    if out["alarms"].empty:
        print("[db_loader] Warning: ALARM_LOG table is empty - no alarm history available")
    if out["alarm_defines"].empty:
        print("[db_loader] Warning: ALARM_DEFINES table is empty - alarm classification may fail")
    if out["measurement_types"].empty:
        print("[db_loader] Warning: MEASUREMENT_TYPES table is empty - measurement filtering may fail")
    
    return out


def load_health_tables_from_db(conn: "pyodbc.Connection") -> dict[str, pd.DataFrame]:
    """Load tables used by the Health Analyzer (VARDESC, VARQC, COMMENTS, DATADDH)."""
    out = {}
    out["vardesc"] = safe_read_sql("SELECT VARNUM AS VARID, NAME, SHORTNAME, UNITS, ENTRYMIN, ENTRYMAX FROM VARDESC", conn)
    out["varqc"] = safe_read_sql("SELECT * FROM VARQC", conn)
    out["comments"] = safe_read_sql("SELECT DATESTAMP, VARID, COMMENT FROM COMMENTS", conn)
    out["dataddh"] = safe_read_sql("SELECT DATESTAMP, VARID, CURVALUE FROM DATADDH", conn)
    return out
