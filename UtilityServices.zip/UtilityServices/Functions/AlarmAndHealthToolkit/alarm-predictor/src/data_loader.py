"""Data loading utilities for the Alarm Predictor Phase 1 pipeline."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import pandas as pd

from . import constants as C


def _get_effective_date_max() -> pd.Timestamp:
    """Return the effective maximum date for filtering (today's date).
    
    This filters out any future-dated records that may exist due to data quality issues.
    Returns a timezone-naive timestamp to ensure consistent comparison with both
    timezone-aware and timezone-naive data sources.
    """
    ts = pd.Timestamp.now()
    # Ensure timezone-naive for consistent comparisons with various data sources
    if ts.tzinfo is not None:
        ts = ts.tz_localize(None)
    return ts.normalize()


@dataclass
class DataBundle:
    """Container for all raw tables plus out-of-range removal counts."""

    trend: pd.DataFrame
    alarms: pd.DataFrame
    alarm_defines: pd.DataFrame
    measurements: pd.DataFrame
    measurement_types: pd.DataFrame
    trend_removed_out_of_range: int
    alarm_removed_out_of_range: int


def load_trend_data(csv_path: Path) -> tuple[pd.DataFrame, int]:
    """Load `trend_data_daily.csv` with schema enforcement and date filtering.

    Args:
        csv_path: Location of `trend_data_daily.csv`.

    Returns:
        Tuple of the cleaned dataframe and the count of rows removed because their
        timestamps fall outside the trusted Phase 0 date window.
    """
    dtype_map = {
        "measurement_id": "Int64",
        "trend_data_interval": "Int64",
        "trend_data_interval_sum": "float64",
        "trend_data_min": "float64",
        "trend_data_avg": "float64",
        "trend_data_max": "float64",
        "trend_data_count": "Int64",
    }

    # Parse timestamps and coerce numeric fields so downstream math is reliable
    trend_df = pd.read_csv(
        csv_path,
        dtype=dtype_map,
        parse_dates=["trend_data_time"],
        na_values=C.CSV_NA_VALUES,
    )
    initial_rows = len(trend_df)

    # Restrict timestamps to the vetted historical window, dynamically capped at today
    effective_max = _get_effective_date_max()
    in_range_mask = trend_df["trend_data_time"].between(C.DATE_RANGE_MIN, effective_max)
    trend_df = trend_df.loc[in_range_mask].copy()
    removed_rows = initial_rows - len(trend_df)
    if removed_rows > 0:
        print(f"[data_loader] Filtered {removed_rows} trend rows outside valid date range")

    return trend_df, removed_rows


def load_alarm_tables(
    alarm_log_path: Path, alarm_defines_path: Path
) -> tuple[pd.DataFrame, pd.DataFrame, int]:
    """Load alarm log and definition tables with common cleaning applied.

    Args:
        alarm_log_path: CSV path for `alarm_log.csv`.
        alarm_defines_path: CSV path for `alarm_defines.csv`.

    Returns:
        Tuple of alarm log dataframe, alarm definition dataframe, and the count
        of alarms removed for falling outside the trusted timestamp range.
    """
    alarm_dtype = {
        "alarm_id": "Int64",
        "alarm_system_address": "string",
        "alarm_source_type": "string",
        "alarm_source_id": "string",
        "alarm_type": "Int64",
        "alarm_message": "string",
        "alarm_acknowledged": "Int8",
        "alarm_ack_by": "string",
        "alarm_ack_comment": "string",
        "alarm_isnew": "Int8",
        "site_id": "string",
        "measurement_id": "Int64",
        "alarm_event_duration": "float64",
        "alarm_reading": "string",
        "alarm_printed": "Int8",
    }

    # Parse datetime fields to enable accurate temporal filtering downstream
    alarm_df = pd.read_csv(
        alarm_log_path,
        dtype=alarm_dtype,
        parse_dates=[
            "alarm_time_stamp",
            "alarm_event_time_stamp",
            "alarm_ack_time_stamp",
        ],
        na_values=C.CSV_NA_VALUES,
    )
    initial_rows = len(alarm_df)

    # Enforce time window to keep future-dated noise out of the model, dynamically capped at today
    effective_max = _get_effective_date_max()
    in_range_mask = alarm_df["alarm_time_stamp"].between(C.DATE_RANGE_MIN, effective_max)
    alarm_df = alarm_df.loc[in_range_mask].copy()
    removed_rows = initial_rows - len(alarm_df)
    if removed_rows > 0:
        print(f"[data_loader] Filtered {removed_rows} alarm rows outside valid date range")

    alarm_defines_dtype = {
        "alarm_type_id": "Int64",
        "alarm_name": "string",
        "alarm_usage": "Int64",
        "alarm_deactive_id": "Int64",
        "alarm_default_message": "string",
        "alarm_site_state": "string",
    }
    alarm_defines_df = pd.read_csv(
        alarm_defines_path,
        dtype=alarm_defines_dtype,
        na_values=C.CSV_NA_VALUES,
    )

    return alarm_df, alarm_defines_df, removed_rows


def load_measurement_metadata(
    measurements_path: Path, measurement_types_path: Path
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Load measurement and measurement type metadata with boolean coercion.

    Args:
        measurements_path: CSV path for `measurements.csv`.
        measurement_types_path: CSV path for `measurement_types.csv`.

    Returns:
        Tuple of measurements dataframe and measurement types dataframe.
    """
    measurements_dtype = {
        "measurement_id": "Int64",
        "site_id": "string",
        "measurement_name": "string",
        "unit_id": "Int64",
        "measurement_type_id": "Int64",
        "measurement_compression_method": "string",
        "measurement_notes": "string",
        "measurement_event_on_indicator": "Int8",
        "measurement_default_color": "string",
        "measurement_default_is_hidden": "Int8",
        "measurement_default_is_auto_calculated": "Int8",
    }

    measurements_df = pd.read_csv(
        measurements_path,
        dtype=measurements_dtype,
        na_values=C.CSV_NA_VALUES,
    )

    # Convert indicator columns to boolean for clarity
    bool_columns = [
        "measurement_event_on_indicator",
        "measurement_default_is_hidden",
        "measurement_default_is_auto_calculated",
    ]
    for column in bool_columns:
        measurements_df[column] = measurements_df[column].fillna(0).astype(bool)

    measurement_types_dtype = {
        "measurement_type_id": "Int64",
        "measurement_type_name": "string",
        "measurement_type_is_hidden": "Int8",
        "measurement_type_is_auto_calculated": "Int8",
        "measurement_type_is_editable": "Int8",
        "measurement_type_include_gis_realtime": "Int8",
        "measurement_type_is_event": "Int8",
        "measurement_type_is_mobile_measurement": "Int8",
        "measurement_type_is_core": "Int8",
        "measurement_type_class_id": "Int64",
    }

    measurement_types_df = pd.read_csv(
        measurement_types_path,
        dtype=measurement_types_dtype,
        na_values=C.CSV_NA_VALUES,
    )

    type_bool_columns = [
        "measurement_type_is_hidden",
        "measurement_type_is_auto_calculated",
        "measurement_type_is_editable",
        "measurement_type_include_gis_realtime",
        "measurement_type_is_event",
        "measurement_type_is_mobile_measurement",
        "measurement_type_is_core",
    ]
    for column in type_bool_columns:
        measurement_types_df[column] = measurement_types_df[column].fillna(0).astype(
            bool
        )

    return measurements_df, measurement_types_df


def load_all_data(
    trend_path: Path,
    alarm_log_path: Path,
    alarm_defines_path: Path,
    measurements_path: Path,
    measurement_types_path: Path,
) -> DataBundle:
    """Load every raw table used by Phase 1 and return a structured bundle.

    Args:
        trend_path: Path to `trend_data_daily.csv`.
        alarm_log_path: Path to `alarm_log.csv`.
        alarm_defines_path: Path to `alarm_defines.csv`.
        measurements_path: Path to `measurements.csv`.
        measurement_types_path: Path to `measurement_types.csv`.

    Returns:
        DataBundle with all raw tables plus removal diagnostics.
    """
    trend_df, trend_removed = load_trend_data(trend_path)
    alarm_df, alarm_defines_df, alarm_removed = load_alarm_tables(
        alarm_log_path, alarm_defines_path
    )
    measurements_df, measurement_types_df = load_measurement_metadata(
        measurements_path, measurement_types_path
    )

    return DataBundle(
        trend=trend_df,
        alarms=alarm_df,
        alarm_defines=alarm_defines_df,
        measurements=measurements_df,
        measurement_types=measurement_types_df,
        trend_removed_out_of_range=trend_removed,
        alarm_removed_out_of_range=alarm_removed,
    )


def load_all_data_from_db(tables: dict[str, pd.DataFrame]) -> DataBundle:
    """Construct a DataBundle from already-loaded DB tables with date filtering.

    The `tables` dict is expected to contain keys: trend, alarms,
    alarm_defines, measurements, measurement_types.
    This adapter keeps the pipeline interfaces stable while enabling
    DB-based ingestion.

    Applies the same date filtering as the CSV loaders to handle data quality
    issues like future-dated records.
    """
    trend_df = tables.get("trend", pd.DataFrame()).copy()
    trend_removed = 0

    # Parse and filter trend timestamps
    if not trend_df.empty and "trend_data_time" in trend_df.columns:
        # Ensure datetime dtype using robust type check (handles timezone-aware types too)
        if not pd.api.types.is_datetime64_any_dtype(trend_df["trend_data_time"]):
            try:
                trend_df["trend_data_time"] = pd.to_datetime(trend_df["trend_data_time"], errors="coerce")
            except (ValueError, TypeError) as e:
                print(f"[data_loader] Warning: Could not convert trend_data_time to datetime: {e}")

        # Ensure measurement_id is Int64 for consistency with CSV loader
        if "measurement_id" in trend_df.columns:
            trend_df["measurement_id"] = trend_df["measurement_id"].astype("Int64")
        
        # Filter to valid date range (same logic as CSV loader)
        initial_trend_rows = len(trend_df)
        effective_max = _get_effective_date_max()
        in_range_mask = trend_df["trend_data_time"].between(C.DATE_RANGE_MIN, effective_max)
        trend_df = trend_df.loc[in_range_mask].copy()
        trend_removed = initial_trend_rows - len(trend_df)
        if trend_removed > 0:
            print(f"[data_loader] Filtered {trend_removed} trend rows outside valid date range")
        
        # Filter out rows with NULL measurement values (garbage data with valid dates)
        if "trend_data_avg" in trend_df.columns:
            null_mask = trend_df["trend_data_avg"].isna()
            null_count = int(null_mask.sum())
            if null_count > 0:
                trend_df = trend_df.loc[~null_mask].copy()
                print(f"[data_loader] Filtered {null_count} trend rows with NULL measurement values")

    alarm_df = tables.get("alarms", pd.DataFrame()).copy()
    alarm_removed = 0

    # Parse and filter alarm timestamps
    if not alarm_df.empty:
        # Ensure measurement_id is Int64 for consistency with CSV loader
        if "measurement_id" in alarm_df.columns:
            alarm_df["measurement_id"] = alarm_df["measurement_id"].astype("Int64")
        
        # Ensure alarm_time_stamp is datetime using robust type check
        timestamp_col = "alarm_time_stamp"
        if timestamp_col in alarm_df.columns:
            if not pd.api.types.is_datetime64_any_dtype(alarm_df[timestamp_col]):
                try:
                    alarm_df[timestamp_col] = pd.to_datetime(alarm_df[timestamp_col], errors="coerce")
                except (ValueError, TypeError) as e:
                    print(f"[data_loader] Warning: Could not convert {timestamp_col} to datetime: {e}")

            # Filter to valid date range
            initial_alarm_rows = len(alarm_df)
            effective_max = _get_effective_date_max()
            in_range_mask = alarm_df[timestamp_col].between(C.DATE_RANGE_MIN, effective_max)
            alarm_df = alarm_df.loc[in_range_mask].copy()
            alarm_removed = initial_alarm_rows - len(alarm_df)
            if alarm_removed > 0:
                print(f"[data_loader] Filtered {alarm_removed} alarm rows outside valid date range")

    # Parse other alarm datetime columns for consistency with CSV loader
    for dt_col in ["alarm_event_time_stamp", "alarm_ack_time_stamp"]:
        if dt_col in alarm_df.columns and not pd.api.types.is_datetime64_any_dtype(alarm_df[dt_col]):
            try:
                alarm_df[dt_col] = pd.to_datetime(alarm_df[dt_col], errors="coerce")
            except (ValueError, TypeError) as e:
                print(f"[data_loader] Warning: Could not convert {dt_col} to datetime: {e}")

    # Use .copy() for consistency with other dataframes to prevent unintended mutations
    alarm_defines_df = tables.get("alarm_defines", pd.DataFrame()).copy()
    measurements_df = tables.get("measurements", pd.DataFrame()).copy()
    measurement_types_df = tables.get("measurement_types", pd.DataFrame()).copy()

    # Convert indicator columns to boolean (same as CSV loader)
    measurements_bool_columns = [
        "measurement_event_on_indicator",
        "measurement_default_is_hidden",
        "measurement_default_is_auto_calculated",
    ]
    for column in measurements_bool_columns:
        if column in measurements_df.columns:
            measurements_df[column] = measurements_df[column].fillna(0).astype(bool)

    # Convert measurement_types boolean columns (same as CSV loader)
    type_bool_columns = [
        "measurement_type_is_hidden",
        "measurement_type_is_auto_calculated",
        "measurement_type_is_editable",
        "measurement_type_include_gis_realtime",
        "measurement_type_is_event",
        "measurement_type_is_mobile_measurement",
        "measurement_type_is_core",
    ]
    for column in type_bool_columns:
        if column in measurement_types_df.columns:
            measurement_types_df[column] = measurement_types_df[column].fillna(0).astype(bool)

    return DataBundle(
        trend=trend_df,
        alarms=alarm_df,
        alarm_defines=alarm_defines_df,
        measurements=measurements_df,
        measurement_types=measurement_types_df,
        trend_removed_out_of_range=trend_removed,
        alarm_removed_out_of_range=alarm_removed,
    )


