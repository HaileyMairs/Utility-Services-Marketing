"""LightGBM training workflow implementing Step 6 of PLAN.md."""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
import math
from pathlib import Path
from typing import Iterable, Sequence

import lightgbm as lgb
import numpy as np
import pandas as pd
from sklearn.metrics import precision_recall_curve

from .baseline import (
    BaselineOutcome,
    ConfusionMatrixCounts,
    evaluate_split,
    load_phase1_dataset,
    split_dataset_by_time,
)


DEFAULT_EXCLUDE_COLUMNS = {
    "trend_day",
    "measurement_id",
    "will_alarm_1d",
    "will_alarm_7d",
    # OPTION A: Exclude same-day alarm features to avoid trivial "alarm persistence" patterns
    # These features make prediction too easy by encoding "alarm today → alarm tomorrow"
    # Comment out to restore (but expect AP > 0.95 due to alarm autocorrelation):
    "has_physical_alarm",
    "daily_alarm_count",
}


@dataclass
class PreparedSplit:
    """Container holding the aligned feature matrix, targets, and metadata."""

    name: str
    features: pd.DataFrame
    target: pd.Series
    evaluation_frame: pd.DataFrame


def infer_feature_columns(
    dataset: pd.DataFrame, exclude_columns: Iterable[str] | None = None
) -> list[str]:
    """Derive default feature columns by excluding identity + target fields.

    Args:
        dataset: Labeled Phase 1 dataframe.
        exclude_columns: Optional extra columns to drop from the feature set.

    Returns:
        Ordered list of columns to feed into the model.
    """
    exclude = set(DEFAULT_EXCLUDE_COLUMNS)
    if exclude_columns:
        exclude.update(exclude_columns)
    return [col for col in dataset.columns if col not in exclude]


def prepare_train_test_split(
    dataset: pd.DataFrame,
    feature_columns: Sequence[str],
    target_column: str,
) -> dict[str, PreparedSplit]:
    """Slice the dataset into train/validation/test splits for modeling.

    Args:
        dataset: Phase 1 dataframe containing features + targets.
        feature_columns: Columns to use as predictors.
        target_column: Specific target (e.g., `will_alarm_1d`).

    Returns:
        Dictionary keyed by split name containing `PreparedSplit` objects.
    """
    train_df, validation_df, test_df = split_dataset_by_time(dataset)
    raw_splits = {
        "train": train_df,
        "validation": validation_df,
        "test": test_df,
    }

    prepared: dict[str, PreparedSplit] = {}
    required_columns = set(feature_columns) | {target_column}

    for split_name, split_df in raw_splits.items():
        missing = required_columns.difference(split_df.columns)
        if missing:
            raise KeyError(
                f"Columns {missing} are missing from the {split_name} split."
            )

        # Drop rows with NaNs in any required column to keep LightGBM happy.
        working = split_df.dropna(subset=required_columns).copy()
        if working.empty:
            raise ValueError(f"{split_name} split contains no usable rows.")

        features = working[feature_columns].copy()
        target = working[target_column].astype(int)

        prepared[split_name] = PreparedSplit(split_name, features, target, working)

    return prepared


def _ensure_categorical_dtypes(
    splits: dict[str, PreparedSplit], categorical_features: Sequence[str]
) -> list[str]:
    """Convert configured categorical columns to pandas `category` dtype.

    Args:
        splits: Prepared splits produced by `prepare_train_test_split`.
        categorical_features: Column names to coerce to category.

    Returns:
        Filtered list of categorical features that actually exist.
    """
    valid_cats = [col for col in categorical_features if col in splits["train"].features]
    for split in splits.values():
        for column in valid_cats:
            split.features[column] = split.features[column].astype("category")
    return valid_cats


def _compute_scale_pos_weight(y: pd.Series) -> float:
    """Return LightGBM's scale_pos_weight value based on class ratio.

    Args:
        y: Binary training labels from the train split.

    Returns:
        Ratio of negatives to positives (minimum of 1.0).
    """
    positives = float(y.sum())
    negatives = float(len(y) - y.sum())
    if positives == 0:
        return 1.0
    return max(negatives / positives, 1.0)


def train_model(
    train_split: PreparedSplit,
    validation_split: PreparedSplit | None,
    categorical_features: Sequence[str],
    *,
    objective: str = "binary",
    learning_rate: float = 0.05,
    num_leaves: int = 31,
    max_depth: int = -1,
    min_data_in_leaf: int = 20,
    n_estimators: int = 500,
    feature_fraction: float = 0.9,
    bagging_fraction: float = 0.8,
    bagging_freq: int = 1,
    scale_pos_weight: float | None = None,
    early_stopping_rounds: int = 50,
    random_state: int = 42,
    n_jobs: int = -1,
) -> lgb.LGBMClassifier:
    """Train a LightGBM model using the provided splits.

    Args:
        train_split: Training split with features and labels.
        validation_split: Optional validation split for early stopping.
        categorical_features: Columns treated as categorical by LightGBM.
        objective: LightGBM objective string.
        learning_rate: Gradient boosting learning rate.
        num_leaves: Maximum leaves per tree.
        max_depth: Maximum depth (negative uses default).
        min_data_in_leaf: Minimum samples per leaf.
        n_estimators: Maximum boosting rounds.
        feature_fraction: Column subsampling ratio per tree.
        bagging_fraction: Row subsampling ratio per iteration.
        bagging_freq: Row subsampling frequency.
        scale_pos_weight: Optional manual class weight override.
        early_stopping_rounds: Early stopping patience when validation available.
        random_state: RNG seed for reproducibility.
        n_jobs: Thread count for LightGBM.

    Returns:
        Fitted `lgb.LGBMClassifier`.
    """
    effective_scale_pos_weight = (
        scale_pos_weight if scale_pos_weight is not None else _compute_scale_pos_weight(train_split.target)
    )

    model = lgb.LGBMClassifier(
        objective=objective,
        learning_rate=learning_rate,
        num_leaves=num_leaves,
        max_depth=max_depth,
        min_child_samples=min_data_in_leaf,
        n_estimators=n_estimators,
        subsample=bagging_fraction,
        subsample_freq=bagging_freq,
        colsample_bytree=feature_fraction,
        scale_pos_weight=effective_scale_pos_weight,
        random_state=random_state,
        n_jobs=n_jobs,
    )

    eval_set = None
    callbacks = None
    if validation_split:
        eval_set = [(validation_split.features, validation_split.target)]
        callbacks = [
            lgb.early_stopping(early_stopping_rounds, verbose=False),
            lgb.log_evaluation(50),
        ]

    model.fit(
        train_split.features,
        train_split.target,
        eval_set=eval_set,
        eval_metric="average_precision",
        callbacks=callbacks,
        categorical_feature=list(categorical_features),
    )

    return model


def recall_at_precision_threshold(
    y_true: pd.Series, y_scores: np.ndarray, min_precision: float
) -> tuple[float, float] | tuple[float, None]:
    """Compute the best recall achieved while meeting the minimum precision.

    Args:
        y_true: Ground-truth binary labels.
        y_scores: Model probability estimates.
        min_precision: Required precision floor.

    Returns:
        Tuple of (recall, threshold) where recall satisfies the precision floor.
        If the floor cannot be met, returns (nan, None).
    """
    if y_true.nunique() < 2:
        return float("nan"), None

    precision, recall, thresholds = precision_recall_curve(y_true, y_scores)
    precision = precision[:-1]
    recall = recall[:-1]
    thresholds = thresholds

    valid_indices = np.where(precision >= min_precision)[0]
    if len(valid_indices) == 0:
        return float("nan"), None

    best_idx = valid_indices[np.argmax(recall[valid_indices])]
    return float(recall[best_idx]), float(thresholds[best_idx])


def evaluate_model(
    model: lgb.LGBMClassifier,
    split: PreparedSplit,
    target_column: str,
    *,
    model_name: str,
    confusion_threshold: float | None = None,
    precision_floor: float | None = None,
) -> tuple[BaselineOutcome, dict[str, float]]:
    """Evaluate the trained model on a dataset split.

    Args:
        model: Trained LightGBM classifier.
        split: Data split to evaluate.
        target_column: Name of the target column.
        model_name: Identifier to include in metrics output.
        confusion_threshold: Optional threshold for confusion counts.
        precision_floor: Precision requirement for recall@precision.

    Returns:
        Tuple containing the `BaselineOutcome` metrics object and a dictionary
        with auxiliary diagnostics such as recall@precision.
    """
    y_scores = model.predict_proba(split.features)[:, 1]
    score_series = pd.Series(y_scores, index=split.evaluation_frame.index)

    outcome = evaluate_split(
        model_name=model_name,
        split_name=split.name,
        eval_df=split.evaluation_frame,
        target_column=target_column,
        score_series=score_series,
        confusion_threshold=confusion_threshold,
    )

    diagnostics: dict[str, float] = {}
    if precision_floor is not None:
        recall_value, threshold = recall_at_precision_threshold(
            split.target, y_scores, precision_floor
        )
        diagnostics["recall_at_precision"] = recall_value
        if threshold is not None:
            diagnostics["threshold_for_precision"] = threshold

    return outcome, diagnostics


def _write_confusion_matrix_csv(
    split_name: str,
    counts: ConfusionMatrixCounts,
    output_dir: Path,
) -> Path:
    """Persist a 2x2 confusion matrix CSV for downstream reporting.

    Args:
        split_name: Name of the evaluated split (`validation` or `test`).
        counts: Confusion-matrix counts produced by `evaluate_model`.
        output_dir: Directory where the CSV should be written.

    Returns:
        Path to the saved CSV file.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    matrix = pd.DataFrame(
        [
            [counts.true_negative, counts.false_positive],
            [counts.false_negative, counts.true_positive],
        ],
        index=pd.Index(["Actual 0", "Actual 1"], name="Actual"),
        columns=pd.Index(["Pred 0", "Pred 1"], name="Predicted"),
    )
    file_path = output_dir / f"confusion_matrix_{split_name}.csv"
    matrix.to_csv(file_path)
    return file_path


def _sanitize_for_json(obj):
    """Recursively replace NaN/inf values so the metrics file is valid JSON."""
    if isinstance(obj, dict):
        return {key: _sanitize_for_json(value) for key, value in obj.items()}
    if isinstance(obj, list):
        return [_sanitize_for_json(item) for item in obj]
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            return None
    return obj


def _parse_args() -> argparse.Namespace:
    """Configure CLI arguments for LightGBM training."""
    parser = argparse.ArgumentParser(description="Train LightGBM for Step 6.")
    parser.add_argument(
        "--dataset-path",
        type=Path,
        default=Path("outputs/phase1_dataset.parquet"),
        help="Path to the Phase 1 dataset.",
    )
    parser.add_argument(
        "--target-horizon",
        type=int,
        choices=[1, 7],
        default=1,
        help="Label horizon in days (1 or 7).",
    )
    parser.add_argument(
        "--exclude-columns",
        nargs="*",
        default=[],
        help="Additional columns to exclude from the feature set.",
    )
    parser.add_argument(
        "--categorical-features",
        nargs="*",
        default=["site_id", "measurement_type_id", "measurement_type_name", "day_of_week"],
        help="Columns treated as categorical inside LightGBM.",
    )
    parser.add_argument(
        "--learning-rate",
        type=float,
        default=0.05,
        help="LightGBM learning rate.",
    )
    parser.add_argument(
        "--num-leaves",
        type=int,
        default=31,
        help="Maximum number of leaves per tree.",
    )
    parser.add_argument(
        "--max-depth",
        type=int,
        default=-1,
        help="Maximum depth (-1 lets LightGBM decide).",
    )
    parser.add_argument(
        "--min-data-in-leaf",
        type=int,
        default=50,
        help="Minimum samples per leaf node.",
    )
    parser.add_argument(
        "--n-estimators",
        type=int,
        default=1000,
        help="Maximum boosting iterations.",
    )
    parser.add_argument(
        "--feature-fraction",
        type=float,
        default=0.9,
        help="Column subsampling ratio per tree.",
    )
    parser.add_argument(
        "--bagging-fraction",
        type=float,
        default=0.8,
        help="Row subsampling ratio per iteration.",
    )
    parser.add_argument(
        "--bagging-freq",
        type=int,
        default=1,
        help="Row subsampling frequency.",
    )
    parser.add_argument(
        "--early-stopping-rounds",
        type=int,
        default=100,
        help="Early-stopping patience for validation loss.",
    )
    parser.add_argument(
        "--precision-floor",
        type=float,
        default=0.1,
        help="Precision floor used when reporting recall@precision.",
    )
    parser.add_argument(
        "--confusion-threshold",
        type=float,
        default=0.1,
        help="Probability threshold for confusion-matrix diagnostics.",
    )
    parser.add_argument(
        "--model-output",
        type=Path,
        default=None,
        help="Optional path to persist the trained LightGBM model.",
    )
    parser.add_argument(
        "--metrics-output",
        type=Path,
        default=None,
        help="Optional path to persist evaluation metrics as JSON.",
    )
    parser.add_argument(
        "--confusion-matrix-dir",
        type=Path,
        default=Path("outputs/confusion_matrices"),
        help="Directory to store confusion matrix CSVs per split.",
    )
    return parser.parse_args()


def main() -> None:
    """Entry point for the Step 6 LightGBM trainer."""
    args = _parse_args()
    dataset = load_phase1_dataset(args.dataset_path)
    target_column = f"will_alarm_{args.target_horizon}d"
    if target_column not in dataset.columns:
        raise KeyError(f"Target column {target_column} missing from dataset.")

    feature_columns = infer_feature_columns(dataset, args.exclude_columns)
    prepared_splits = prepare_train_test_split(dataset, feature_columns, target_column)
    categorical_features = _ensure_categorical_dtypes(
        prepared_splits, args.categorical_features
    )

    model = train_model(
        prepared_splits["train"],
        prepared_splits["validation"],
        categorical_features,
        learning_rate=args.learning_rate,
        num_leaves=args.num_leaves,
        max_depth=args.max_depth,
        min_data_in_leaf=args.min_data_in_leaf,
        n_estimators=args.n_estimators,
        feature_fraction=args.feature_fraction,
        bagging_fraction=args.bagging_fraction,
        bagging_freq=args.bagging_freq,
        early_stopping_rounds=args.early_stopping_rounds,
    )

    outcomes: list[BaselineOutcome] = []
    diagnostics: dict[str, dict[str, float]] = {}
    confusion_matrix_paths: dict[str, Path] = {}

    for split_name in ("validation", "test"):
        outcome, split_diag = evaluate_model(
            model,
            prepared_splits[split_name],
            target_column,
            model_name="lightgbm_phase1",
            confusion_threshold=args.confusion_threshold,
            precision_floor=args.precision_floor,
        )
        outcomes.append(outcome)
        diagnostics[split_name] = split_diag
        if outcome.confusion_matrix and args.confusion_matrix_dir:
            cm_path = _write_confusion_matrix_csv(
                split_name, outcome.confusion_matrix, args.confusion_matrix_dir
            )
            confusion_matrix_paths[split_name] = cm_path

    for outcome in outcomes:
        print(outcome.model_name.upper(), "->", outcome.split_name)
        print(
            f"  AP={outcome.average_precision:.4f} "
            f"(positives={outcome.positive_count}/{outcome.sample_count})"
        )
        if outcome.per_site_average_precision:
            per_site = ", ".join(
                f"{site}:{'nan' if np.isnan(ap) else f'{ap:.4f}'}"
                for site, ap in sorted(outcome.per_site_average_precision.items())
            )
            print(f"  per-site AP: {per_site}")
        if outcome.confusion_matrix:
            cm = outcome.confusion_matrix
            print(
                "  confusion "
                f"(thr={cm.threshold:.3f}) -> "
                f"TP={cm.true_positive}, FP={cm.false_positive}, "
                f"TN={cm.true_negative}, FN={cm.false_negative}"
            )
        if diagnostics.get(outcome.split_name):
            diag = diagnostics[outcome.split_name]
            recall_display = diag.get("recall_at_precision")
            thresh_display = diag.get("threshold_for_precision")
            print(
                "  recall@precision "
                f"(>= {args.precision_floor:.2f}) -> "
                f"recall={recall_display:.4f} "
                + (
                    f"at threshold={thresh_display:.4f}"
                    if thresh_display is not None
                    else "(no threshold found)"
                )
            )
        if confusion_matrix_paths.get(outcome.split_name):
            print(f"  confusion matrix CSV: {confusion_matrix_paths[outcome.split_name]}")

    if args.model_output:
        args.model_output.parent.mkdir(parents=True, exist_ok=True)
        model.booster_.save_model(str(args.model_output))

    if args.metrics_output:
        args.metrics_output.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "target_column": target_column,
            "feature_columns": feature_columns,
            "categorical_features": categorical_features,
            "precision_floor": args.precision_floor,
            "confusion_threshold": args.confusion_threshold,
            "metrics": [
                {
                    "split": outcome.split_name,
                    "average_precision": outcome.average_precision,
                    "positive_count": outcome.positive_count,
                    "sample_count": outcome.sample_count,
                    "per_site_average_precision": outcome.per_site_average_precision,
                    "confusion_matrix": (
                        {
                            "threshold": outcome.confusion_matrix.threshold,
                            "true_positive": outcome.confusion_matrix.true_positive,
                            "false_positive": outcome.confusion_matrix.false_positive,
                            "true_negative": outcome.confusion_matrix.true_negative,
                            "false_negative": outcome.confusion_matrix.false_negative,
                        }
                        if outcome.confusion_matrix
                        else None
                    ),
                    "confusion_matrix_path": (
                        str(confusion_matrix_paths.get(outcome.split_name))
                        if confusion_matrix_paths.get(outcome.split_name)
                        else None
                    ),
                    "diagnostics": diagnostics.get(outcome.split_name),
                }
                for outcome in outcomes
            ],
        }
        sanitized_payload = _sanitize_for_json(payload)
        args.metrics_output.write_text(json.dumps(sanitized_payload, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()