"""Baseline models (Step 5) for the Alarm Predictor Phase 1 dataset."""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, confusion_matrix

from .. import constants as C


@dataclass
class ConfusionMatrixCounts:
    """Store confusion-matrix components for a binary classifier."""

    threshold: float
    true_positive: int
    false_positive: int
    true_negative: int
    false_negative: int


@dataclass
class BaselineOutcome:
    model_name: str
    split_name: str
    target_column: str
    average_precision: float
    positive_count: int
    sample_count: int
    per_site_average_precision: dict[str, float]
    confusion_matrix: ConfusionMatrixCounts | None = None


def load_phase1_dataset(dataset_path: Path | str) -> pd.DataFrame:
    """Load the labeled Phase 1 dataset from disk.

    Args:
        dataset_path: Path to the parquet or CSV file produced by Phase 1.

    Returns:
        Dataframe sorted by measurement and day with `trend_day` as datetime.
    """
    resolved_path = Path(dataset_path).resolve()
    if not resolved_path.exists():
        raise FileNotFoundError(f"Dataset not found at {resolved_path}")

    # Read the dataset using the appropriate loader based on the suffix.
    if resolved_path.suffix == ".parquet":
        df = pd.read_parquet(resolved_path)
    elif resolved_path.suffix == ".csv":
        df = pd.read_csv(resolved_path, parse_dates=["trend_day"])
    else:
        raise ValueError(
            "Unsupported dataset format. Use parquet (.parquet) or CSV (.csv)."
        )

    # Ensure the temporal key is a datetime dtype so time-based splits work reliably.
    if not pd.api.types.is_datetime64_any_dtype(df["trend_day"]):
        df["trend_day"] = pd.to_datetime(df["trend_day"])

    df = df.sort_values(["measurement_id", "trend_day"]).reset_index(drop=True)
    return df


def split_dataset_by_time(
    df: pd.DataFrame, date_column: str = "trend_day"
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split the dataset into train/validation/test windows per PLAN.md.

    Args:
        df: Labeled dataset containing the `trend_day` timestamp column.
        date_column: Name of the timestamp column that drives the split.

    Returns:
        Tuple of (train_df, validation_df, test_df) views.
    """
    if date_column not in df.columns:
        raise KeyError(f"{date_column} column missing from dataset")

    date_series = df[date_column]

    # Apply the date boundaries published in PLAN.md so baselines match future models.
    train_mask = date_series < C.PHASE1_VALIDATION_START
    validation_mask = (date_series >= C.PHASE1_VALIDATION_START) & (
        date_series < C.PHASE1_TEST_START
    )
    test_mask = date_series >= C.PHASE1_TEST_START

    return (
        df.loc[train_mask].copy(),
        df.loc[validation_mask].copy(),
        df.loc[test_mask].copy(),
    )


def compute_measurement_rate_scores(
    train_df: pd.DataFrame,
    eval_df: pd.DataFrame,
    measurement_column: str,
    target_column: str,
) -> pd.Series:
    """Generate naive baseline scores using per-measurement historical rates.

    Args:
        train_df: Training split used to estimate measurement alarm rates.
        eval_df: Evaluation split receiving the baseline predictions.
        measurement_column: Column that identifies a measurement (e.g., `measurement_id`).
        target_column: Target column name such as `will_alarm_1d`.

    Returns:
        Score series aligned to `eval_df` rows containing probability estimates.
    """
    if measurement_column not in train_df.columns:
        raise KeyError(f"{measurement_column} missing from training data")

    # Compute each measurement's historical positive rate using the training window only.
    grouped_rates = (
        train_df.dropna(subset=[target_column])
        .groupby(measurement_column)[target_column]
        .mean()
    )
    global_rate = float(train_df[target_column].mean())
    if np.isnan(global_rate):
        global_rate = 0.0

    scores = eval_df[measurement_column].map(grouped_rates).astype(float)
    scores = scores.fillna(global_rate)

    return scores


def compute_site_percentile_scores(
    train_df: pd.DataFrame,
    eval_df: pd.DataFrame,
    site_column: str,
    value_column: str,
    percentile: float = 0.95,
) -> pd.Series:
    """Apply the site-specific threshold rule baseline described in PLAN.md.

    Args:
        train_df: Training split used to derive percentile thresholds.
        eval_df: Evaluation split receiving the baseline predictions.
        site_column: Site identifier column (e.g., `site_id`).
        value_column: Continuous measurement column (e.g., `trend_data_avg`).
        percentile: Percentile (0-1] used when computing per-site thresholds.

    Returns:
        Score series containing binary predictions represented as floats.
    """
    if site_column not in train_df.columns:
        raise KeyError(f"{site_column} missing from training data")

    valid_training_values = train_df.dropna(subset=[site_column, value_column])

    # Calculate each site's historical percentile threshold using observed data only.
    site_thresholds = (
        valid_training_values.groupby(site_column)[value_column]
        .quantile(percentile)
        .to_dict()
    )
    global_threshold = valid_training_values[value_column].quantile(percentile)
    if np.isnan(global_threshold):
        # Fall back to +inf so the rule never fires when there is no historical context.
        global_threshold = float("inf")

    per_row_thresholds = eval_df[site_column].map(site_thresholds).fillna(
        global_threshold
    )

    # Flag rows where the current reading exceeds the site-specific percentile.
    above_threshold = eval_df[value_column] > per_row_thresholds
    scores = above_threshold.where(eval_df[value_column].notna(), False).astype(float)

    return scores


def _safe_average_precision(y_true: pd.Series, y_score: pd.Series) -> float:
    """Compute Average Precision while handling degenerate label distributions."""
    if y_true.nunique(dropna=True) < 2:
        return float("nan")
    return float(average_precision_score(y_true, y_score))


def _compute_confusion_counts(
    y_true: pd.Series, y_score: pd.Series, threshold: float
) -> ConfusionMatrixCounts:
    """Convert probabilistic scores into confusion-matrix counts for diagnostics."""
    # Apply a deterministic >= threshold rule so probability ties map consistently to positives.
    y_pred = (y_score >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(
        y_true, y_pred, labels=[0, 1], normalize=None
    ).ravel()
    return ConfusionMatrixCounts(
        threshold=float(threshold),
        true_positive=int(tp),
        false_positive=int(fp),
        true_negative=int(tn),
        false_negative=int(fn),
    )


def evaluate_split(
    model_name: str,
    split_name: str,
    eval_df: pd.DataFrame,
    target_column: str,
    score_series: pd.Series,
    group_column: str = "site_id",
    confusion_threshold: float | None = None,
) -> BaselineOutcome:
    """Summarize performance for a baseline on a given dataset split.

    Args:
        model_name: Name of the baseline being evaluated.
        split_name: Split identifier (`train`, `validation`, or `test`).
        eval_df: Dataframe representing the split.
        target_column: Target column used for evaluation.
        score_series: Predicted scores aligned to `eval_df`.
        group_column: Column used for per-group diagnostics (defaults to `site_id`).
        confusion_threshold: Optional probability threshold for confusion matrix.

    Returns:
        Populated `BaselineOutcome` with overall and per-site AP.
    """
    if eval_df.empty:
        return BaselineOutcome(
            model_name=model_name,
            split_name=split_name,
            target_column=target_column,
            average_precision=float("nan"),
            positive_count=0,
            sample_count=0,
            per_site_average_precision={},
        )

    y_true = eval_df[target_column].astype(int)
    y_scores = score_series.astype(float)

    overall_ap = _safe_average_precision(y_true, y_scores)

    per_site_ap: dict[str, float] = {}
    if group_column in eval_df.columns:
        # Calculate per-site AP so users can confirm Site 1 vs Site 3 behavior.
        for site_value, site_indices in eval_df.groupby(group_column).groups.items():
            site_true = y_true.loc[site_indices]
            site_scores = y_scores.loc[site_indices]
            per_site_ap[str(site_value)] = _safe_average_precision(site_true, site_scores)

    confusion_counts = None
    if confusion_threshold is not None:
        confusion_counts = _compute_confusion_counts(y_true, y_scores, confusion_threshold)

    return BaselineOutcome(
        model_name=model_name,
        split_name=split_name,
        target_column=target_column,
        average_precision=overall_ap,
        positive_count=int(y_true.sum()),
        sample_count=int(len(eval_df)),
        per_site_average_precision=per_site_ap,
        confusion_matrix=confusion_counts,
    )


def run_baseline_suite(
    dataset: pd.DataFrame,
    target_column: str,
    percentile: float = 0.95,
    confusion_threshold: float | None = None,
) -> list[BaselineOutcome]:
    """Evaluate all Step 5 baselines on validation and test splits.

    Args:
        dataset: Phase 1 labeled dataset containing targets and features.
        target_column: Target column to evaluate (`will_alarm_1d` or `will_alarm_7d`).
        percentile: Percentile for the site-threshold rule (default 95th).
        confusion_threshold: Optional probability threshold for confusion matrices.

    Returns:
        List of `BaselineOutcome` instances with metrics for each split/model combo.
    """
    train_df, validation_df, test_df = split_dataset_by_time(dataset)

    results: list[BaselineOutcome] = []
    for split_name, eval_df in (("validation", validation_df), ("test", test_df)):
        # Evaluate the naive measurement-level rate baseline.
        measurement_scores = compute_measurement_rate_scores(
            train_df, eval_df, "measurement_id", target_column
        )
        results.append(
            evaluate_split(
                model_name="measurement_alarm_rate",
                split_name=split_name,
                eval_df=eval_df,
                target_column=target_column,
                score_series=measurement_scores,
                confusion_threshold=confusion_threshold,
            )
        )

        # Evaluate the site-specific percentile rule baseline.
        percentile_scores = compute_site_percentile_scores(
            train_df,
            eval_df,
            site_column="site_id",
            value_column="trend_data_avg",
            percentile=percentile,
        )
        results.append(
            evaluate_split(
                model_name=f"site_{int(percentile * 100)}th_percentile_rule",
                split_name=split_name,
                eval_df=eval_df,
                target_column=target_column,
                score_series=percentile_scores,
                confusion_threshold=confusion_threshold,
            )
        )

    return results


def format_outcome(result: BaselineOutcome) -> str:
    """Format a single baseline outcome for CLI display."""
    ap_display = "nan" if np.isnan(result.average_precision) else f"{result.average_precision:.4f}"
    return (
        f"[{result.split_name}] {result.model_name} | target={result.target_column} | "
        f"AP={ap_display} | positives={result.positive_count}/{result.sample_count}"
    )


def print_outcomes(results: Iterable[BaselineOutcome]) -> None:
    """Print all baseline results along with per-site diagnostics."""
    for outcome in results:
        print(format_outcome(outcome))
        if outcome.per_site_average_precision:
            site_parts = []
            for site, ap in sorted(outcome.per_site_average_precision.items()):
                site_parts.append(f"{site}:{'nan' if np.isnan(ap) else f'{ap:.4f}'}")
            print(f"    per-site AP -> {', '.join(site_parts)}")
        if outcome.confusion_matrix:
            cm = outcome.confusion_matrix
            print(
                "    confusion "
                f"(thr={cm.threshold:.3f}) -> "
                f"TP={cm.true_positive}, FP={cm.false_positive}, "
                f"TN={cm.true_negative}, FN={cm.false_negative}"
            )


def _parse_args() -> argparse.Namespace:
    """Parse CLI arguments for the baseline evaluator."""
    parser = argparse.ArgumentParser(
        description="Evaluate naive baselines on the Phase 1 dataset."
    )
    parser.add_argument(
        "--dataset-path",
        type=Path,
        default=Path("outputs/phase1_dataset.parquet"),
        help="Path to the Phase 1 dataset produced by pipeline_phase1.",
    )
    parser.add_argument(
        "--target-horizon",
        type=int,
        choices=[1, 7],
        default=1,
        help="Target horizon to evaluate (in days).",
    )
    parser.add_argument(
        "--percentile",
        type=float,
        default=0.95,
        help="Percentile used by the site threshold rule (default: 0.95).",
    )
    parser.add_argument(
        "--confusion-threshold",
        type=float,
        default=None,
        help=(
            "Optional probability threshold used to compute confusion-matrix counts. "
            "If omitted, confusion matrices are not reported."
        ),
    )
    return parser.parse_args()


def main() -> None:
    """CLI entry point for running Step 5 baselines."""
    args = _parse_args()
    dataset = load_phase1_dataset(args.dataset_path)
    target_column = f"will_alarm_{args.target_horizon}d"
    if target_column not in dataset.columns:
        raise KeyError(
            f"Target column {target_column} missing from dataset {args.dataset_path}"
        )

    results = run_baseline_suite(
        dataset,
        target_column,
        percentile=args.percentile,
        confusion_threshold=args.confusion_threshold,
    )
    print_outcomes(results)


if __name__ == "__main__":
    main()