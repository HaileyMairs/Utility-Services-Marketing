"""Alarm classification and filtering utilities for Phase 1."""

from __future__ import annotations

from typing import Sequence

import pandas as pd

from . import constants as C


def classify_alarms(
    alarm_df: pd.DataFrame, alarm_defines_df: pd.DataFrame
) -> pd.DataFrame:
    """Attach alarm category labels per PLAN.md taxonomy.

    Args:
        alarm_df: Cleaned alarm log dataframe.
        alarm_defines_df: Alarm definition lookup table.

    Returns:
        Alarm dataframe with `alarm_category`, `alarm_physical_subtype`, and
        `alarm_is_physical` columns.
    """
    # Merge definitions once to expose alarm name and usage to downstream logic
    merged_df = alarm_df.merge(
        alarm_defines_df,
        how="left",
        left_on="alarm_type",
        right_on="alarm_type_id",
        suffixes=("", "_define"),
    )

    measurement_present = merged_df["measurement_id"].notna()
    measurement_missing = ~measurement_present
    type_series = merged_df["alarm_type"].fillna(-999_999)
    name_series = merged_df["alarm_name"].fillna("")

    physical_site_mask = type_series.isin(C.SITE_PHYSICAL)
    physical_measurement_mask = type_series.isin(C.MEASUREMENT_THRESHOLD) & measurement_present
    invalid_measurement_context_mask = type_series.isin(C.MEASUREMENT_THRESHOLD) & measurement_missing
    physical_battery_mask = type_series.isin(C.BATTERY)
    data_quality_mask = type_series.isin(C.DATA_QUALITY)
    recorder_mask = type_series.isin(C.RECORDER)
    system_mask = type_series.isin(C.SYSTEM)
    clearance_mask = (type_series < 0) | name_series.str.contains(
        C.CLEARANCE_KEYWORD, case=False, na=False
    )
    unknown_mask = type_series.eq(-999_999)

    category = pd.Series("other", index=merged_df.index, dtype="string")
    physical_subtype = pd.Series(pd.NA, index=merged_df.index, dtype="string")

    # Assign mutually exclusive categories in priority order
    category[physical_site_mask] = "physical_site"
    physical_subtype[physical_site_mask] = "site"

    category[physical_measurement_mask] = "physical_measurement"
    physical_subtype[physical_measurement_mask] = "measurement_threshold"

    category[physical_battery_mask] = "physical_battery"
    physical_subtype[physical_battery_mask] = "battery"

    category[data_quality_mask] = "data_quality"
    category[recorder_mask] = "recorder"
    category[system_mask] = "system"
    category[clearance_mask] = "clearance"
    category[invalid_measurement_context_mask] = "invalid_measurement_context"
    category[unknown_mask] = "unknown"

    merged_df["alarm_category"] = category
    merged_df["alarm_physical_subtype"] = physical_subtype
    merged_df["alarm_is_physical"] = category.str.startswith("physical")

    return merged_df


def build_measurement_allowlist(
    measurements_df: pd.DataFrame, measurement_types_df: pd.DataFrame
) -> pd.DataFrame:
    """Return measurements joined with types while applying PLAN.md filters."""
    merged_measurements = measurements_df.merge(
        measurement_types_df[
            [
                "measurement_type_id",
                "measurement_type_name",
                "measurement_type_is_event",
                "measurement_type_is_auto_calculated",
            ]
        ],
        how="left",
        on="measurement_type_id",
    )

    # Exclude only event flags (status indicators, not physical sensors)
    # NOTE: measurement_type_is_auto_calculated filter removed because ALL
    # measurements with physical alarms (Meter Flow, Batteries) are marked
    # as auto-calculated in this dataset, but they're legitimate physical sensors
    valid_mask = ~merged_measurements["measurement_type_is_event"]

    return merged_measurements.loc[valid_mask].copy()


def filter_physical_alarms(
    alarm_df: pd.DataFrame,
    measurements_df: pd.DataFrame,
    measurement_types_df: pd.DataFrame,
    allowed_categories: Sequence[str] | None = None,
) -> pd.DataFrame:
    """Keep only physical alarms tied to valid measurements.

    Args:
        alarm_df: Alarm dataframe with classification columns created by
            `classify_alarms`.
        measurements_df: Measurements metadata table.
        measurement_types_df: Measurement type lookup needed for filtering.
        allowed_categories: Optional list of physical categories to keep. The
            default limits results to measurement-level alarms to align with
            measurement-day feature engineering.

    Returns:
        Filtered alarm dataframe ready for Phase 1 label creation.
    """
    if allowed_categories is None:
        allowed_categories = ("physical_measurement", "physical_battery")

    # Focus on legitimately physical alarms first
    physical_df = alarm_df.loc[alarm_df["alarm_is_physical"]].copy()
    physical_df = physical_df.loc[physical_df["alarm_category"].isin(allowed_categories)]

    # Drop alarms that lack measurement context (measurement_id is required for labels)
    physical_df = physical_df.loc[physical_df["measurement_id"].notna()].copy()

    valid_measurements = build_measurement_allowlist(
        measurements_df, measurement_types_df
    )
    valid_measurement_ids = set(valid_measurements["measurement_id"].dropna().tolist())
    physical_df = physical_df.loc[
        physical_df["measurement_id"].isin(valid_measurement_ids)
    ].copy()

    # Attach measurement metadata for downstream joins
    # Build merge columns - exclude site_id if already present in alarm data to avoid duplicates
    merge_columns = ["measurement_id", "measurement_name", "measurement_type_id", "measurement_type_name"]
    if "site_id" not in physical_df.columns:
        merge_columns.insert(1, "site_id")
    
    physical_df = physical_df.merge(
        valid_measurements[merge_columns],
        on="measurement_id",
        how="left",
        suffixes=("", "_measurement"),
    )

    return physical_df


