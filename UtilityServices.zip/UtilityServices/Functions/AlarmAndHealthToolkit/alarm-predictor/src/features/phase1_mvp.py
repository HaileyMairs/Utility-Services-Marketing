"""Phase 1 MVP feature engineering utilities."""

from __future__ import annotations

from typing import Iterable

import pandas as pd

from .. import constants as C
from ..alarm_filter import build_measurement_allowlist


def _safe_groupby_apply(grouped, func):
    """Call GroupBy.apply with include_groups=False when supported by pandas."""
    try:
        return grouped.apply(func, include_groups=False)
    except TypeError:
        return grouped.apply(func)


def _prepare_daily_trend(trend_df: pd.DataFrame) -> pd.DataFrame:
    """Aggregate raw readings to unique measurement-day rows."""
    working_df = trend_df.loc[trend_df["measurement_id"].notna()].copy()
    working_df["measurement_id"] = working_df["measurement_id"].astype("Int64")
    working_df["trend_day"] = working_df["trend_data_time"].dt.floor("D")
    working_df["was_observed"] = True

    aggregated = (
        working_df.sort_values(["measurement_id", "trend_day"])
        .groupby(["measurement_id", "trend_day"], as_index=False)
        .agg(
            trend_data_min=("trend_data_min", "min"),
            trend_data_avg=("trend_data_avg", "mean"),
            trend_data_max=("trend_data_max", "max"),
            trend_data_count=("trend_data_count", "sum"),
            was_observed=("was_observed", "any"),
        )
    )

    return aggregated


def _resample_measurement_days(
    daily_df: pd.DataFrame, max_ffill_gap_days: int
) -> pd.DataFrame:
    """Resample each measurement to daily cadence with limited forward fill."""
    numeric_columns = [
        "trend_data_min",
        "trend_data_avg",
        "trend_data_max",
        "trend_data_count",
    ]

    def _reindex_group(group: pd.DataFrame) -> pd.DataFrame:
        measurement_id = int(group.name)
        group = group.set_index("trend_day").sort_index()
        if group.empty:
            return group.reset_index()

        full_index = pd.date_range(
            start=group.index.min(), end=group.index.max(), freq="D"
        )
        group = group.reindex(full_index)
        group["measurement_id"] = pd.Series(
            measurement_id, index=group.index, dtype="Int64"
        )
        group["was_observed"] = (
            group["was_observed"].astype("boolean", copy=False).fillna(False)
        )

        # Forward-fill values for short gaps only (Plan specifies ≤3 days)
        group[numeric_columns] = group[numeric_columns].ffill(limit=max_ffill_gap_days)
        group["was_forward_filled"] = (~group["was_observed"]) & group[
            "trend_data_avg"
        ].notna()

        group = group.reset_index(names="trend_day")
        return group

    resampled = _safe_groupby_apply(
        daily_df.groupby("measurement_id", group_keys=False), _reindex_group
    ).reset_index(drop=True)

    # Track the most recent real observation date to build freshness flags
    resampled["last_observed_day"] = resampled["trend_day"].where(
        resampled["was_observed"]
    )
    resampled["last_observed_day"] = resampled.groupby("measurement_id")[
        "last_observed_day"
    ].ffill()
    resampled["days_since_last_observation"] = (
        resampled["trend_day"] - resampled["last_observed_day"]
    ).dt.days
    resampled["missing_reading_last_7d"] = resampled[
        "days_since_last_observation"
    ].isna() | (resampled["days_since_last_observation"] > 7)

    return resampled


def _attach_alarm_history(
    feature_df: pd.DataFrame,
    physical_alarms_df: pd.DataFrame,
    history_window_days: int,
) -> pd.DataFrame:
    """Add alarm occurrence indicators and history-based aggregates."""
    if physical_alarms_df.empty:
        feature_df["daily_alarm_count"] = 0
    else:
        alarm_daily = (
            physical_alarms_df.assign(
                trend_day=physical_alarms_df["alarm_time_stamp"].dt.floor("D")
            )
            .groupby(["measurement_id", "trend_day"], as_index=False)
            .size()
            .rename(columns={"size": "daily_alarm_count"})
        )
        feature_df = feature_df.merge(
            alarm_daily, on=["measurement_id", "trend_day"], how="left"
        )
        feature_df["daily_alarm_count"] = feature_df["daily_alarm_count"].fillna(0)

    feature_df["has_physical_alarm"] = feature_df["daily_alarm_count"] > 0

    def _compute_days_since_last_alarm(group: pd.DataFrame) -> pd.Series:
        last_alarm_day = pd.NaT
        days_since = []
        for _, row in group.iterrows():
            if pd.isna(last_alarm_day):
                # Use large sentinel value for measurements that have never alarmed
                days_since.append(C.DAYS_SINCE_LAST_ALARM_SENTINEL)
            else:
                days_since.append(int((row["trend_day"] - last_alarm_day).days))
            if row["has_physical_alarm"]:
                last_alarm_day = row["trend_day"]
        return pd.Series(days_since, index=group.index, dtype="Int64")

    days_since = _safe_groupby_apply(
        feature_df.groupby("measurement_id", group_keys=False),
        _compute_days_since_last_alarm,
    )
    feature_df["days_since_last_alarm"] = (
        days_since.reset_index(level=0, drop=True).astype("Int64")
    )

    feature_df[
        f"physical_alarm_count_{history_window_days}d"
    ] = feature_df.groupby("measurement_id")["daily_alarm_count"].transform(
        lambda s: s.rolling(window=history_window_days, min_periods=1).sum()
    )

    return feature_df


def build_phase1_feature_matrix(
    trend_df: pd.DataFrame,
    physical_alarms_df: pd.DataFrame,
    measurements_df: pd.DataFrame,
    measurement_types_df: pd.DataFrame,
    max_ffill_gap_days: int = C.DEFAULT_MAX_FFILL_DAYS,
    rolling_window_days: int = C.PHASE1_ROLLING_WINDOW,
    history_window_days: int = C.PHASE1_ALARM_HISTORY_WINDOW,
) -> pd.DataFrame:
    """Create the Phase 1 MVP feature table at measurement-day granularity.

    Args:
        trend_df: Cleaned trend dataframe.
        physical_alarms_df: Alarm dataframe filtered to physical measurement alarms.
        measurements_df: Measurement metadata table.
        measurement_types_df: Measurement type metadata table.
        max_ffill_gap_days: Maximum gap (in days) to fill when resampling.
        rolling_window_days: Window for rolling statistics over `trend_data_avg`.
        history_window_days: Window for alarm count statistics.

    Returns:
        Feature dataframe ready for label generation.
    
    Raises:
        ValueError: If trend_df or measurements_df is empty, as features cannot be built.
    """
    # Validate input dataframes before processing
    if trend_df.empty:
        raise ValueError(
            "Cannot build feature matrix: trend_df is empty. "
            "Check that trend data was loaded successfully from CSV or database."
        )
    if measurements_df.empty:
        raise ValueError(
            "Cannot build feature matrix: measurements_df is empty. "
            "Check that measurement metadata was loaded successfully."
        )
    if measurement_types_df.empty:
        raise ValueError(
            "Cannot build feature matrix: measurement_types_df is empty. "
            "Check that measurement type metadata was loaded successfully."
        )
    
    # Aggregate to unique measurement-day rows and align to full daily cadence
    daily_trend = _prepare_daily_trend(trend_df)
    resampled = _resample_measurement_days(daily_trend, max_ffill_gap_days)

    # Keep only measurements allowed by PLAN.md filtering guidance
    allowed_measurements = build_measurement_allowlist(
        measurements_df, measurement_types_df
    )[["measurement_id", "site_id", "measurement_type_id", "measurement_type_name"]]
    resampled = resampled.merge(
        allowed_measurements, on="measurement_id", how="inner"
    )

    # Rolling statistics capture short-term trend of the avg signal
    grouped = resampled.groupby("measurement_id", group_keys=False)
    resampled[
        f"trend_avg_roll_mean_{rolling_window_days}d"
    ] = grouped["trend_data_avg"].transform(
        lambda s: s.rolling(window=rolling_window_days, min_periods=1).mean()
    )
    resampled[
        f"trend_avg_roll_std_{rolling_window_days}d"
    ] = grouped["trend_data_avg"].transform(
        lambda s: s.rolling(window=rolling_window_days, min_periods=1).std()
    )
    resampled[
        f"trend_avg_roll_min_{rolling_window_days}d"
    ] = grouped["trend_data_avg"].transform(
        lambda s: s.rolling(window=rolling_window_days, min_periods=1).min()
    )
    resampled[
        f"trend_avg_roll_max_{rolling_window_days}d"
    ] = grouped["trend_data_avg"].transform(
        lambda s: s.rolling(window=rolling_window_days, min_periods=1).max()
    )
    resampled["trend_avg_delta_1d"] = grouped["trend_data_avg"].diff()

    # Alarm history features provide recency context
    resampled = _attach_alarm_history(resampled, physical_alarms_df, history_window_days)

    resampled["day_of_week"] = resampled["trend_day"].dt.dayofweek.astype("Int8")

    feature_columns = [
        "measurement_id",
        "trend_day",
        "site_id",
        "measurement_type_id",
        "measurement_type_name",
        "trend_data_avg",
        "trend_data_min",
        "trend_data_max",
        "trend_data_count",
        "was_forward_filled",
        "missing_reading_last_7d",
        f"trend_avg_roll_mean_{rolling_window_days}d",
        f"trend_avg_roll_std_{rolling_window_days}d",
        f"trend_avg_roll_min_{rolling_window_days}d",
        f"trend_avg_roll_max_{rolling_window_days}d",
        "trend_avg_delta_1d",
        "day_of_week",
        "daily_alarm_count",
        f"physical_alarm_count_{history_window_days}d",
        "has_physical_alarm",  # Needed for label generation, exclude from modeling features
        "days_since_last_alarm",
    ]

    feature_df = resampled[feature_columns].copy()
    feature_df = feature_df.sort_values(["measurement_id", "trend_day"]).reset_index(
        drop=True
    )

    return feature_df


