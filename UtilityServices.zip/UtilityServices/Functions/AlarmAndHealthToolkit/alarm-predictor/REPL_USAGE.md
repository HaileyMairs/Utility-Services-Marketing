# TRINITY - Alarm & Health Analyzer - Menu Usage

## Overview

The interactive menu provides a user-friendly interface for the TRINITY toolkit, which combines alarm prediction and sensor health analysis capabilities. It supports both database connections (SQL Server) and CSV file inputs.

## Starting the Menu

To start the interactive menu:

```bash
python main.py
```

To auto-select a specific menu option (skips the interactive menu):

```bash
python main.py --option 3    # or -o 3
```

## Menu Structure

The menu is organized into two main sections:

### Alarm Prediction (Options 1-5)

Tools for preparing alarm datasets, training machine learning models, and generating predictions.

### Health Analyzers (Options 6-9)

Tools for analyzing sensor data quality, detecting problematic sensors, and monitoring system health.

---

## Menu Options

### 1. Prepare Alarm Dataset (from DB)

Connects to the **MCRWS-Telog** database and runs the Phase 1 pipeline:
- Loads trend data, alarms, measurements, and metadata from SQL Server
- Classifies alarms and filters to physical alarms
- Builds feature matrix with rolling statistics
- Generates labels for 1-day and 7-day prediction horizons
- Saves to `outputs/alarm_dataset_from_db.parquet`

**Configuration Defaults:**
- Max forward-fill gap: 3 days
- Rolling window: 7 days
- Alarm history window: 30 days
- Label horizons: 1 and 7 days

### 2. Prepare Alarm Dataset (from CSV Directory)

Runs the same Phase 1 pipeline using local CSV files instead of a database:
- Prompts for data directory path (default: current directory)
- Expects CSV files: `trend_data_daily.csv`, `alarm_log.csv`, `alarm_defines.csv`, `measurements.csv`, `measurement_types.csv`
- Saves to `outputs/alarm_dataset.parquet`

### 3. Train LightGBM Model

Interactive model training workflow:
- Prompts for dataset path (default: `outputs/alarm_dataset_from_db.parquet`)
- Selects target horizon (1 or 7 days)
- Allows specifying extra columns to exclude from features
- Automatically splits data into train/validation/test sets
- Trains with early stopping based on validation performance
- Reports Average Precision (AP) on validation and test sets
- Optionally saves the trained model (default: `outputs/models/lightgbm_alarm_{horizon}d.txt`)

**Default Hyperparameters:**
- Learning rate: 0.05
- Number of leaves: 31
- Maximum depth: unlimited (-1)
- Minimum samples per leaf: 50
- Maximum estimators: 1000 (with early stopping)

### 4. Score Dataset with Trained Model

Batch inference on a saved dataset:
- Prompts for dataset path and model horizon
- Loads a trained LightGBM model
- Generates probability scores for all rows
- Applies a configurable threshold for binary predictions
- Saves predictions to `outputs/predictions_{model_name}.csv`

### 5. Predict Latest Alarms from DB (Live Inference)

Designed for nightly operational runs:
- Connects to **MCRWS-Telog** database for fresh data
- Builds features on-the-fly from recent data (60-day window)
- Filters to measurements with recent data (configurable lookback)
- Supports reference date override for demos or testing
- Generates predictions using a trained model
- Calculates total system alarm probability (P(at least one alarm))
- Displays ranked report of highest-risk measurements
- Saves predictions to `outputs/predictions_latest_db.csv`

**Prompts:**
- Prediction horizon (1 or 7 days)
- Lookback days (0 = only most recent day)
- Reference date override (optional, YYYY-MM-DD format)
- Model path (default based on horizon)

**Output Report Includes:**
- Total system probability
- Top 10 highest-risk measurements
- Risk level summary (high/medium/low)

---

### 6. Run Health Analyzer (QC Summary)

Connects to the **OPSDC** database and analyzes QC flags:
- Examines the VARQC table for formal QC failures
- Scans COMMENTS table for QC-related keywords (e.g., "No Data", "missing", "LOST")
- Computes per-variable QC metrics:
  - Days with QC issues
  - Total QC events
  - Combined QC risk score
- Saves results to `outputs/qc_summary_per_varid.csv`
- Prints top 30 variables with most QC issues

### 7. Run Unit Health Scores

Connects to the **OPSDC** database and calculates health scores:
- Analyzes last 30 days of DATADDH process data
- Computes per-variable metrics:
  - **Availability**: Percentage of days with data
  - **In-Range Score**: Percentage of readings within engineering limits (ENTRYMIN/ENTRYMAX)
  - **Event Score**: Placeholder for future event-based metrics
- Calculates weighted health score: 40% availability + 40% in-range + 20% events
- Prints ranked list (best and worst 20 variables)

### 8. Run Flatline Detector

Connects to the **OPSDC** database and detects problematic sensors:
- Analyzes last 30 days of DATADDH data
- Identifies **flatline sensors**: Variables with constant or near-constant values
- Identifies **dead sensors**: Variables with no recent data (older than 7 days)
- Classifies sensors as:
  - `flatline_suspect`: Enough data points but no variation
  - `no_recent_data`: No data in analysis window
  - `dead_sensor`: Last seen before stale threshold
- Saves results to `outputs/dead_and_flatline_sensors.csv`
- Prints summary of flagged sensors

### 9. Run Drift Detection

Connects to the **OPSDC** database and detects sensor drift:
- Analyzes last 60 days of DATADDH data
- Computes daily averages per variable
- Fits linear regression to detect trending drift
- Calculates:
  - **Slope**: Units per day
  - **R²**: Goodness of fit (higher = more consistent drift)
  - **Relative drift**: Percent of engineering range per 30 days (when limits available)
- Filters to variables with R² ≥ 0.2
- Saves results to `outputs/sensor_drift_per_varid.csv`
- Prints top 30 drifting sensors

### 0. Exit

Gracefully exits the application.

---

## Database Connections

The toolkit uses two databases:

| Database | Used By | Purpose |
|----------|---------|---------|
| **MCRWS-Telog** | Options 1, 5 | Trend data, alarms, measurements for alarm prediction |
| **OPSDC** | Options 6, 7, 8, 9 | Process data (DATADDH), QC flags, variable metadata for health analysis |

Connections are managed by the `connection_manager` module:
- Prompts for connection details on first use
- Validates connections before saving
- Stores credentials in `connections.json` for reuse
- Tests connection before each operation

---

## Example Workflows

### Complete Alarm Model Training

1. Start the menu: `python main.py`
2. Choose option **1** to prepare alarm dataset from database
3. Choose option **3** to train a LightGBM model
4. When prompted, enter the dataset path (or press Enter for default)
5. Select target horizon (1 or 7)
6. Save the model when prompted
7. Choose option **0** to exit

### Nightly Alarm Predictions

1. Start with auto-option: `python main.py --option 5`
2. Enter prediction horizon (1 or 7)
3. Enter lookback days (typically 0 for most recent data)
4. Press Enter for reference date (auto-detect) or specify a date
5. Confirm model path
6. Review the prediction report
7. Check `outputs/predictions_latest_db.csv` for full results

### Sensor Health Check

1. Start the menu: `python main.py`
2. Choose option **6** for QC summary → identifies sensors with quality issues
3. Choose option **7** for health scores → ranks sensors by overall health
4. Choose option **8** for flatline detection → finds stuck/dead sensors
5. Choose option **9** for drift detection → finds sensors trending over time
6. Review CSV outputs in the `outputs/` directory

### Using CSV Files (Offline Mode)

1. Place CSV exports in a directory
2. Start: `python main.py`
3. Choose option **2** for CSV-based dataset preparation
4. Enter the directory path containing CSV files
5. Continue with option **3** to train on the generated dataset

---

## Tips

- **Default Values**: Prompts show current values in brackets `[value]`. Press Enter to accept.
- **Error Handling**: If an operation fails, a traceback is displayed and the menu returns.
- **Keyboard Interrupt**: Press `Ctrl+C` to exit gracefully at any time.
- **Auto-Option**: Use `--option N` to skip the menu for scripted/scheduled runs.
- **Connection Persistence**: Database connections are saved after first successful connection.

---

## Requirements

Install all dependencies:

```bash
pip install -r requirements.txt
```

Required packages:
- pandas
- numpy
- scikit-learn
- lightgbm
- pyarrow (for parquet support)
- scipy
- pyodbc (for SQL Server connections)

**Note**: SQL Server connections require an ODBC driver installed on your system.

---

## Data Files

### For CSV Mode (Option 2)

The pipeline expects these CSV files in the data directory:
- `trend_data_daily.csv` - Daily measurement trend data
- `alarm_log.csv` - Historical alarm events
- `alarm_defines.csv` - Alarm type definitions
- `measurements.csv` - Measurement metadata
- `measurement_types.csv` - Measurement type definitions

### Output Files

All outputs are saved to the `outputs/` directory:
- `alarm_dataset_from_db.parquet` - Prepared dataset from database
- `predictions_latest_db.csv` - Latest predictions from live inference
- `models/*.txt` - Trained LightGBM models
- `qc_summary_per_varid.csv` - QC analyzer results
- `dead_and_flatline_sensors.csv` - Flatline detector results
- `sensor_drift_per_varid.csv` - Drift detector results
