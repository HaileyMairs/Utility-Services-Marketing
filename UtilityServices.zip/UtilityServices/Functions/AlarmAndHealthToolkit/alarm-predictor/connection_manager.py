"""Connection manager for database connections with persistence.

This module handles:
- Loading saved connection strings from a JSON file
- Prompting users for connection strings when not saved
- Testing connections before saving
- Persisting working connections for future use
"""

import json
from pathlib import Path
from typing import Optional, TYPE_CHECKING

# Use TYPE_CHECKING to avoid runtime import of pyodbc for type hints only
if TYPE_CHECKING:
    import pyodbc


# Path to the JSON file that stores working connection strings
CONNECTIONS_FILE = Path(__file__).parent / "connections.json"

# Default connection string template shown to users as a hint
DEFAULT_TEMPLATE = (
    "DRIVER={ODBC Driver 17 for SQL Server};"
    "SERVER=your_server_name;"
    "DATABASE={db_name};"
    "Trusted_Connection=Yes;"
)


def load_saved_connections() -> dict[str, str]:
    """Load previously saved connection strings from the JSON file.
    
    Returns an empty dict if the file doesn't exist or is invalid.
    """
    if not CONNECTIONS_FILE.exists():
        return {}
    
    try:
        with open(CONNECTIONS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            # Ensure we return a dict of strings
            if isinstance(data, dict):
                return {k: v for k, v in data.items() if isinstance(v, str)}
            return {}
    except (json.JSONDecodeError, IOError) as e:
        print(f"[connection_manager] Warning: Could not load {CONNECTIONS_FILE}: {e}")
        return {}


def save_connection(db_name: str, conn_str: str) -> None:
    """Save a working connection string to the JSON file.
    
    Merges with existing saved connections.
    """
    connections = load_saved_connections()
    connections[db_name] = conn_str
    
    try:
        with open(CONNECTIONS_FILE, "w", encoding="utf-8") as f:
            json.dump(connections, f, indent=2)
        print(f"[connection_manager] Saved connection for '{db_name}' to {CONNECTIONS_FILE.name}")
    except IOError as e:
        print(f"[connection_manager] Warning: Could not save connection: {e}")


def test_connection(conn_str: str) -> tuple[bool, str]:
    """Test if a connection string works.
    
    Returns (success: bool, message: str).
    """
    # Lazy import pyodbc to avoid issues on systems without the driver
    import pyodbc
    
    try:
        conn = pyodbc.connect(conn_str, timeout=10)
        conn.close()
        return True, "Connection successful!"
    except pyodbc.Error as e:
        # Extract the error message from pyodbc
        error_msg = str(e)
        if hasattr(e, 'args') and len(e.args) >= 2:
            error_msg = e.args[1]
        return False, f"Connection failed: {error_msg}"
    except Exception as e:
        return False, f"Connection failed: {e}"


def prompt_for_connection(db_name: str) -> Optional[str]:
    """Prompt user to enter a connection string for the specified database.
    
    Shows a template as a hint and allows the user to cancel.
    Returns the connection string or None if cancelled.
    """
    print(f"\n{'='*60}")
    print(f"DATABASE CONNECTION REQUIRED: {db_name}")
    print("="*60)
    print("\nNo saved connection found. Please enter an ODBC connection string.")
    print("\nExample format:")
    print(f"  {DEFAULT_TEMPLATE.replace('{db_name}', db_name)}")
    print("\nYou can copy this from SQL Server Management Studio:")
    print("  Right-click server > Properties > View connection properties")
    print("\nEnter 'q' or leave blank to cancel and return to menu.")
    print("-"*60)
    
    user_input = input("Connection string: ").strip()
    
    if not user_input or user_input.lower() == 'q':
        print("Connection cancelled.")
        return None
    
    return user_input


def clear_saved_connection(db_name: str) -> None:
    """Remove a saved connection string for the specified database."""
    connections = load_saved_connections()
    if db_name in connections:
        del connections[db_name]
        try:
            with open(CONNECTIONS_FILE, "w", encoding="utf-8") as f:
                json.dump(connections, f, indent=2)
            print(f"[connection_manager] Cleared saved connection for '{db_name}'")
        except IOError as e:
            print(f"[connection_manager] Warning: Could not clear connection: {e}")


def get_connection(db_name: str, allow_prompt: bool = True) -> Optional["pyodbc.Connection"]:
    """Get a database connection, prompting user if needed.
    
    This is the main entry point for obtaining connections:
    1. Check for saved connection string
    2. If saved, test it - if it fails, offer to re-enter
    3. If not saved, prompt user for connection string
    4. Test the connection before returning
    5. Save working connections for future use
    
    Args:
        db_name: The database name (e.g., "OPSDC", "MCRWS-Telog")
        allow_prompt: If False, only use saved connections (for non-interactive use)
    
    Returns:
        A pyodbc.Connection object, or None if connection failed/cancelled.
    """
    # Lazy import pyodbc to avoid issues on systems without the driver
    import pyodbc
    
    connections = load_saved_connections()
    
    # Check if we have a saved connection
    if db_name in connections:
        conn_str = connections[db_name]
        print(f"Using saved connection for '{db_name}'...")
        
        success, message = test_connection(conn_str)
        if success:
            print(message)
            return pyodbc.connect(conn_str)
        else:
            print(f"\nSaved connection failed: {message}")
            if not allow_prompt:
                return None
            
            # Ask user what to do
            print("\nOptions:")
            print("  1. Enter a new connection string")
            print("  2. Return to menu")
            choice = input("Choice [1]: ").strip() or "1"
            
            if choice != "1":
                return None
            
            # Clear the bad connection and fall through to prompt
            clear_saved_connection(db_name)
    
    # No saved connection (or it was cleared) - prompt user
    if not allow_prompt:
        print(f"No saved connection for '{db_name}' and prompting disabled.")
        return None
    
    # Loop until user provides valid connection or cancels
    while True:
        conn_str = prompt_for_connection(db_name)
        if conn_str is None:
            return None
        
        print("\nTesting connection...")
        success, message = test_connection(conn_str)
        
        if success:
            print(message)
            save_connection(db_name, conn_str)
            return pyodbc.connect(conn_str)
        else:
            print(f"\n{message}")
            print("\nWould you like to try again? (y/n)")
            retry = input("Choice [y]: ").strip().lower() or "y"
            if retry != "y":
                return None


