"""
Dead Sensor & Flatline Detector
-------------------------------

This script analyzes continuous process data in the OPSDC database
to detect:

    1) DEAD / INACTIVE SENSORS:
        • Variables (VARIDs) that have no data in the last N days.
        • Variables whose last data point is older than a "stale" threshold.

    2) FLATLINE SENSORS:
        • Variables that do have data, but the value is essentially constant
          (no variation) over the analysis window.

The goal is to highlight sensors that:
    • Stopped reporting (dead / disconnected)
    • Are stuck at a constant or near-constant value (frozen / failed)
    • Might require inspection, repair, or reconfiguration

WHAT THIS PROGRAM DOES:
    • Connects to the OPSDC SQL Server database.
    • Determines the latest timestamp in DATADDH.
    • Defines an analysis window looking back N_DAYS from the latest timestamp.
    • Loads DATADDH rows in that window.
    • Calculates per-VARID statistics:
        - Number of samples (n_points)
        - Number of days with data (n_days)
        - Last seen timestamp in window
        - min, max, range, std deviation
        - number of unique values
    • Classifies sensors as:
        - flatline_suspect: very low variation and/or only 1 unique value
        - no_recent_data: last_seen < window_start
        - dead_sensor: last_seen older than STALE_DAYS threshold
    • Joins with VARDESC to attach NAME / SHORTNAME / UNITS.
    • Saves a CSV with all stats and flags.
    • Prints:
        - Top flatline candidates
        - Summary of dead/inactive sensors.

INTENDED USE:
    • Help operations & maintenance teams quickly identify:
        - Broken or frozen instruments
        - Tags that are no longer in service
        - Points that need reconfiguration or removal from dashboards
"""

from pathlib import Path
from datetime import timedelta

import pyodbc
import pandas as pd
import numpy as np


# ============================================================
# CONFIG
# ============================================================
DB_NAME = "OPSDC"

N_DAYS_WINDOW = 30         # Look-back window for flatline analysis
STALE_DAYS = 7             # If last_seen is older than this (days), treat as dead_sensor
MIN_POINTS_FOR_ANALYSIS = 50   # Minimum samples in window to consider flatline
MIN_DAYS_FOR_FLATLINE = 2      # Minimum distinct days in window for flatline flag
FLAT_RANGE_EPS = 1e-6          # If max-min <= this → consider constant
MIN_UNIQUE_VALUES = 1          # If unique values <= this → consider constant


# ============================================================
# CONNECTION
# ============================================================
def get_connection(conn_string: str) -> pyodbc.Connection:
    """Create and return a pyodbc connection to the database.
    
    Args:
        conn_string: Full ODBC connection string (provided by connection_manager).
    
    Returns:
        Active pyodbc.Connection object.
    
    Note:
        Connection string validation and persistence is handled by the
        connection_manager module in main.py. This function expects a
        pre-validated full connection string.
    """
    print("Connecting to SQL Server...")
    cnxn = pyodbc.connect(conn_string)
    print("Connected.\n")
    return cnxn


# ============================================================
# DATA LOADING
# ============================================================
def get_dataddh_date_range(cnxn: pyodbc.Connection) -> tuple[pd.Timestamp, pd.Timestamp]:
    """Return global min and max DATESTAMP in DATADDH."""
    date_range = pd.read_sql(
        "SELECT MIN(DATESTAMP) AS mind, MAX(DATESTAMP) AS maxd FROM DATADDH",
        cnxn
    )

    if date_range.isna().all(axis=None):
        raise RuntimeError("DATADDH has no data at all. Cannot analyze sensors.")

    min_ts = pd.to_datetime(date_range["mind"][0])
    max_ts = pd.to_datetime(date_range["maxd"][0])

    print(f"DATADDH date range in DB : {min_ts.date()}  →  {max_ts.date()}")
    return min_ts, max_ts


def load_recent_dataddh(cnxn: pyodbc.Connection, window_start: pd.Timestamp, window_end: pd.Timestamp) -> pd.DataFrame:
    """Load DATADDH rows in the analysis window."""
    df = pd.read_sql(
        """
        SELECT DATESTAMP, VARID, CURVALUE
        FROM DATADDH
        WHERE DATESTAMP >= ? AND DATESTAMP < ?
        """,
        cnxn,
        params=[window_start, window_end]
    )

    if df.empty:
        raise RuntimeError("No DATADDH rows in the selected window for flatline analysis.")

    df["DATESTAMP"] = pd.to_datetime(df["DATESTAMP"])
    df["DATE"] = df["DATESTAMP"].dt.date
    df["CURVALUE"] = pd.to_numeric(df["CURVALUE"], errors="coerce")

    # Drop non-numeric values
    df = df.dropna(subset=["CURVALUE"])

    print("Rows in DATADDH window:", len(df))
    return df


def load_global_last_seen(cnxn: pyodbc.Connection) -> pd.DataFrame:
    """Load last_seen timestamp for each VARID across the whole DATADDH table."""
    last_seen = pd.read_sql(
        """
        SELECT VARID, MAX(DATESTAMP) AS last_seen
        FROM DATADDH
        GROUP BY VARID
        """,
        cnxn
    )
    last_seen["last_seen"] = pd.to_datetime(last_seen["last_seen"])
    return last_seen


def load_vardesc(cnxn: pyodbc.Connection) -> pd.DataFrame:
    """Load VARDESC metadata."""
    vd = pd.read_sql(
        """
        SELECT 
            VARNUM AS VARID,
            NAME,
            SHORTNAME,
            UNITS
        FROM VARDESC
        """,
        cnxn
    )
    return vd


# ============================================================
# FLATLINE & DEAD SENSOR LOGIC
# ============================================================
def compute_per_var_stats(df: pd.DataFrame) -> pd.DataFrame:
    """
    Compute basic statistics per VARID within the analysis window:
        - n_points
        - n_days
        - last_seen_in_window
        - min_val, max_val, range_val
        - mean, std_dev
        - n_unique_values
    """
    grouped = df.groupby("VARID")

    stats = grouped.agg(
        n_points=("CURVALUE", "count"),
        n_days=("DATE", "nunique"),
        last_seen_in_window=("DATESTAMP", "max"),
        min_val=("CURVALUE", "min"),
        max_val=("CURVALUE", "max"),
        mean_val=("CURVALUE", "mean"),
        std_dev=("CURVALUE", "std"),
        n_unique_values=("CURVALUE", pd.Series.nunique),
    ).reset_index()

    stats["range_val"] = stats["max_val"] - stats["min_val"]

    return stats


def flag_flatline_and_dead(
    stats: pd.DataFrame,
    last_seen_global: pd.DataFrame,
    window_start: pd.Timestamp,
    max_ts: pd.Timestamp
) -> pd.DataFrame:
    """
    Add classification flags:
        - flatline_suspect
        - no_recent_data
        - dead_sensor

    Based on:
        - stats in the window
        - global last_seen timestamps
    """
    # Merge global last_seen into stats (to know overall last_seen)
    df = stats.merge(last_seen_global, on="VARID", how="left")

    # --- flatline_suspect ---
    # Conditions:
    #   - enough points and days
    #   - very small range OR very few unique values
    cond_enough_data = (
        (df["n_points"] >= MIN_POINTS_FOR_ANALYSIS) &
        (df["n_days"] >= MIN_DAYS_FOR_FLATLINE)
    )

    cond_small_range = df["range_val"].abs() <= FLAT_RANGE_EPS
    cond_low_unique = df["n_unique_values"] <= MIN_UNIQUE_VALUES

    df["flatline_suspect"] = cond_enough_data & (cond_small_range | cond_low_unique)

    # --- no_recent_data & dead_sensor ---
    # For VARIDs that never appear in the window at all, they won't be in stats.
    # We'll handle them separately, but here we still classify those in stats.
    df["no_recent_data"] = df["last_seen"] < window_start

    stale_cutoff = max_ts - timedelta(days=STALE_DAYS)
    df["dead_sensor"] = df["last_seen"] < stale_cutoff

    return df


def build_full_sensor_table(
    stats_in_window: pd.DataFrame,
    last_seen_global: pd.DataFrame,
    window_start: pd.Timestamp,
    max_ts: pd.Timestamp,
    vardesc: pd.DataFrame
) -> pd.DataFrame:
    """
    Build a full sensor table including:
        - VARIDs that appear in the window (stats_in_window)
        - VARIDs that do not appear in the window (only from last_seen_global)

    Attach:
        - Name, Shortname, Units
        - stats (where available)
        - flags for flatline_suspect, no_recent_data, dead_sensor
    """
    # Identify VARIDs with data in window vs. only historical
    var_in_window = set(stats_in_window["VARID"])
    var_all = set(last_seen_global["VARID"])

    only_historical = var_all - var_in_window
    historical_df = last_seen_global[last_seen_global["VARID"].isin(only_historical)].copy()

    # For historical-only vars, we still want to mark no_recent_data & dead_sensor,
    # but we won't have min/max/std etc.
    stale_cutoff = max_ts - timedelta(days=STALE_DAYS)
    historical_df["n_points"] = 0
    historical_df["n_days"] = 0
    historical_df["last_seen_in_window"] = pd.NaT
    historical_df["min_val"] = np.nan
    historical_df["max_val"] = np.nan
    historical_df["mean_val"] = np.nan
    historical_df["std_dev"] = np.nan
    historical_df["n_unique_values"] = 0
    historical_df["range_val"] = np.nan
    historical_df["flatline_suspect"] = False
    historical_df["no_recent_data"] = historical_df["last_seen"] < window_start
    historical_df["dead_sensor"] = historical_df["last_seen"] < stale_cutoff

    # Now classify those with stats in the window
    classified_stats = flag_flatline_and_dead(stats_in_window, last_seen_global, window_start, max_ts)

    # Combine both
    combined = pd.concat(
        [classified_stats, historical_df[classified_stats.columns]],
        ignore_index=True
    )

    # Attach metadata
    combined = combined.merge(vardesc, on="VARID", how="left")

    return combined


# ============================================================
# OUTPUT
# ============================================================
def print_summary(full_df: pd.DataFrame, window_start: pd.Timestamp, max_ts: pd.Timestamp) -> None:
    """Print a human-readable summary of flatline and dead sensors."""
    print("\n=== Dead Sensor & Flatline Detector Summary ===\n")
    print(f"Analysis window: {window_start.date()} → {max_ts.date()}")
    print(f"Flatline criteria: >= {MIN_POINTS_FOR_ANALYSIS} points, >= {MIN_DAYS_FOR_FLATLINE} days, small range or 1 unique value.")
    print(f"Dead sensor criteria: last_seen < (max_ts - {STALE_DAYS} days).\n")

    # Top flatline suspects (by number of points)
    flatliners = full_df[full_df["flatline_suspect"]].copy()
    flatliners = flatliners.sort_values("n_points", ascending=False)

    print("Top Flatline Suspects:\n")
    if flatliners.empty:
        print("  (none detected with current thresholds)\n")
    else:
        for _, row in flatliners.head(30).iterrows():
            varid = int(row["VARID"])
            name = row["SHORTNAME"] or row["NAME"]
            if pd.isna(name) or str(name).strip() == "":
                name = f"VARID {varid}"

            print(
                f"VARID={varid:6d} | "
                f"{name[:30].ljust(30)} | "
                f"points={row['n_points']:5d}, days={row['n_days']:3d}, "
                f"min={row['min_val']!s:>8}, max={row['max_val']!s:>8}, "
                f"unique={row['n_unique_values']:3d}"
            )
        print("")

    # Dead / inactive sensors
    dead = full_df[full_df["dead_sensor"]].copy()
    dead = dead.sort_values("last_seen")

    print("Dead / Inactive Sensors (last_seen very old):\n")
    if dead.empty:
        print("  (none detected with current threshold)\n")
    else:
        for _, row in dead.head(50).iterrows():
            varid = int(row["VARID"])
            name = row["SHORTNAME"] or row["NAME"]
            if pd.isna(name) or str(name).strip() == "":
                name = f"VARID {varid}"
            last_seen = row["last_seen"]
            print(
                f"VARID={varid:6d} | "
                f"{name[:30].ljust(30)} | "
                f"last_seen={str(last_seen)}"
            )
        print("")

    # Sensors with no data at all in the window
    no_recent = full_df[full_df["no_recent_data"]].copy()
    no_recent = no_recent.sort_values("last_seen")

    print("Sensors with no data in analysis window:\n")
    if no_recent.empty:
        print("  (all active sensors have some data in the window)\n")
    else:
        print(f"  Total: {len(no_recent)} sensors with no data in last {N_DAYS_WINDOW} days.\n")


# ============================================================
# MAIN
# ============================================================
def run_detector(server_name) -> None:
    cnxn = get_connection(server_name)

    # Global date range and analysis window
    min_ts, max_ts = get_dataddh_date_range(cnxn)
    window_start = max_ts - timedelta(days=N_DAYS_WINDOW)
    window_end = max_ts + timedelta(days=1)

    print(f"Using analysis window: {window_start.date()} → {(window_end - timedelta(days=1)).date()}\n")

    # Load data
    df_window = load_recent_dataddh(cnxn, window_start, window_end)
    last_seen_global = load_global_last_seen(cnxn)
    vardesc = load_vardesc(cnxn)

    # Compute stats & build full table
    stats_in_window = compute_per_var_stats(df_window)
    full_table = build_full_sensor_table(stats_in_window, last_seen_global, window_start, max_ts, vardesc)

    # Save CSV for further analysis to outputs directory
    output_dir = Path(__file__).parent.parent / "outputs"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / "dead_and_flatline_sensors.csv"
    full_table.to_csv(output_path, index=False)
    print(f"Saved {output_path}\n")

    # Print summary to console
    print_summary(full_table, window_start, max_ts)


