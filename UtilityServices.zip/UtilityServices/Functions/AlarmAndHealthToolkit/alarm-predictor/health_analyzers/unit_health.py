"""
Process Unit Health Score Calculator
------------------------------------

This script analyzes continuous process data stored in the OPSDC database
and generates a "Health Score" for each process variable (VARID). The goal
is to evaluate data quality and sensor performance over a recent time window
(default: last 30 days of available DATADDH data).

WHAT THIS PROGRAM DOES:
    • Connects to the OPSDC SQL Server database.
    • Loads time-series data from DATADDH for the last N days.
    • Loads variable metadata and engineering limits from VARDESC
      (ENTRYMIN and ENTRYMAX).
    • Calculates key data-quality metrics for every VARID:
         - Data availability (number of days with valid data)
         - In-range percentage (how often data stays within limits)
         - Event score (placeholder; can be expanded later)
    • Computes a weighted “Health Score” per variable:
         Health Score =
             40% Data Availability +
             40% In-Range Score +
             20% Event Score
    • Sorts variables from healthiest to least healthy.
    • Prints a ranked report for operators/engineers.

INTENDED USE:
    • Identify sensors or process points needing maintenance.
    • Support proactive instrument reliability programs.
    • Provide automated data-quality insights for engineers.
    • Serve as a component for future “Unit Health Dashboards”.
"""

import pyodbc
import pandas as pd
from datetime import timedelta


# ============================================================
# CONFIG
# ============================================================
N_DAYS = 30          # Number of days to look back from latest DATESTAMP
DB_NAME = "OPSDC"


# ============================================================
# CONNECTION HELPERS
# ============================================================
def get_connection(conn_string: str) -> pyodbc.Connection:
    """Create and return a pyodbc connection to the database.
    
    Args:
        conn_string: Full ODBC connection string (provided by connection_manager).
    
    Returns:
        Active pyodbc.Connection object.
    
    Note:
        Connection string validation and persistence is handled by the
        connection_manager module in main.py. This function expects a
        pre-validated full connection string.
    """
    print("Connecting to SQL Server...")
    cnxn = pyodbc.connect(conn_string)
    print("Connected.\n")
    return cnxn


# ============================================================
# DATA LOADING FUNCTIONS
# ============================================================
def get_dataddh_date_window(cnxn: pyodbc.Connection) -> tuple[pd.Timestamp, pd.Timestamp]:
    """Determine min/max DATADDH timestamps and compute last N_DAYS window."""
    date_range = pd.read_sql(
        "SELECT MIN(DATESTAMP) AS mind, MAX(DATESTAMP) AS maxd FROM DATADDH",
        cnxn
    )

    if date_range.isna().all(axis=None):
        raise RuntimeError("DATADDH has no data at all. Cannot compute health scores.")

    min_date = pd.to_datetime(date_range["mind"][0])
    max_date = pd.to_datetime(date_range["maxd"][0])

    start_date = max_date - timedelta(days=N_DAYS)
    end_date = max_date + timedelta(days=1)

    print(f"DATADDH date range in DB : {min_date.date()}  →  {max_date.date()}")
    print(f"Using analysis window    : {start_date.date()} → {(end_date - timedelta(days=1)).date()}\n")

    return start_date, end_date


def load_vardesc(cnxn: pyodbc.Connection) -> pd.DataFrame:
    """Load VARDESC metadata."""
    return pd.read_sql(
        """
        SELECT 
            VARNUM     AS VARID,
            NAME,
            SHORTNAME,
            UNITS,
            ENTRYMIN,
            ENTRYMAX
        FROM VARDESC
        """,
        cnxn
    )


def load_dataddh(cnxn: pyodbc.Connection, start_date, end_date) -> pd.DataFrame:
    """Load DATADDH rows in date window."""
    df = pd.read_sql(
        """
        SELECT DATESTAMP, VARID, CURVALUE
        FROM DATADDH
        WHERE DATESTAMP >= ? AND DATESTAMP < ?
        """,
        cnxn,
        params=[start_date, end_date]
    )
    df["DATESTAMP"] = pd.to_datetime(df["DATESTAMP"])
    df["DATE"] = df["DATESTAMP"].dt.date

    print("Raw DATADDH rows in window:", len(df))

    if df.empty:
        raise RuntimeError(
            "No DATADDH rows in selected window – "
            "consider increasing N_DAYS or using DATADDF instead."
        )
    return df


# ============================================================
# CORE LOGIC
# ============================================================
def build_master_dataframe(dataddh: pd.DataFrame, vardesc: pd.DataFrame) -> pd.DataFrame:
    """Join DATADDH with VARDESC."""
    df = dataddh.merge(vardesc, on="VARID", how="left")
    
    # Convert numeric columns to ensure proper comparisons
    df["CURVALUE"] = pd.to_numeric(df["CURVALUE"], errors="coerce")
    df["ENTRYMIN"] = pd.to_numeric(df["ENTRYMIN"], errors="coerce")
    df["ENTRYMAX"] = pd.to_numeric(df["ENTRYMAX"], errors="coerce")

    print("Rows in joined dataset:", len(df))
    return df


def compute_var_health_scores(df: pd.DataFrame) -> pd.DataFrame:
    """Compute availability, in-range score, and health score."""

    # --------------------
    # Availability
    # --------------------
    days_present = df.groupby("VARID")["DATE"].nunique()
    availability_score = (days_present / N_DAYS).clip(0, 1) * 100
    availability_score = availability_score.rename("availability_score").reset_index()

    # --------------------
    # In-Range (% of readings within limits)
    # --------------------
    has_limits = df["ENTRYMIN"].notna() & df["ENTRYMAX"].notna()
    df_limits = df[has_limits].copy()

    if not df_limits.empty:
        df_limits["in_range_flag"] = (
            (df_limits["CURVALUE"] >= df_limits["ENTRYMIN"]) &
            (df_limits["CURVALUE"] <= df_limits["ENTRYMAX"])
        ).astype(int)

        in_range = (
            df_limits.groupby("VARID")["in_range_flag"].mean() * 100
        ).rename("in_range_score").reset_index()
    else:
        in_range = pd.DataFrame(columns=["VARID", "in_range_score"])

    # --------------------
    # Event score (fixed placeholder)
    # --------------------
    event_score = pd.DataFrame({"VARID": availability_score["VARID"], "event_score": 100.0})

    # --------------------
    # Merge all metrics
    # --------------------
    scores = (
        availability_score
        .merge(in_range, on="VARID", how="left")
        .merge(event_score, on="VARID", how="left")
    )

    # ⚠ NEW: Missing limits → neutral 50 score (instead of 100)
    scores["in_range_score"] = pd.to_numeric(scores["in_range_score"], errors="coerce").fillna(50.0)

    # --------------------
    # Final weighted health score
    # --------------------
    scores["health_score"] = (
        0.4 * scores["availability_score"] +
        0.4 * scores["in_range_score"] +
        0.2 * scores["event_score"]
    )

    return scores.sort_values("health_score", ascending=False)


# ============================================================
# OUTPUT
# ============================================================
def print_health_scores(scores: pd.DataFrame, vardesc: pd.DataFrame, top_n: int = 50):
    """Pretty-print top variable health scores."""

    scores = scores.merge(vardesc, on="VARID", how="left")

    print("\n=== Top Variable Health Scores (Best) ===\n")
    for _, row in scores.head(top_n).iterrows():
        name = row["SHORTNAME"] or row["NAME"]
        if pd.isna(name) or str(name).strip() == "":
            name = f"VARID {int(row['VARID'])}"

        print(
            f"VARID={int(row['VARID']):6d} | "
            f"{name[:30].ljust(30)} | "
            f"Health={row['health_score']:6.1f}  "
            f"(Avail={row['availability_score']:5.1f}, "
            f"InRange={row['in_range_score']:5.1f}, "
            f"Events={row['event_score']:5.1f})"
        )

    print("\n=== Worst 20 Variable Health Scores (Bottom) ===\n")
    for _, row in scores.tail(20).iterrows():
        name = row["SHORTNAME"] or row["NAME"]
        if pd.isna(name) or str(name).strip() == "":
            name = f"VARID {int(row['VARID'])}"

        print(
            f"VARID={int(row['VARID']):6d} | "
            f"{name[:30].ljust(30)} | "
            f"Health={row['health_score']:6.1f}  "
            f"(Avail={row['availability_score']:5.1f}, "
            f"InRange={row['in_range_score']:5.1f}, "
            f"Events={row['event_score']:5.1f})"
        )

    print("\nDone.")


# ============================================================
# MAIN
# ============================================================
def run_unit_health(server_name):
    cnxn = get_connection(server_name)

    start_date, end_date = get_dataddh_date_window(cnxn)
    vardesc = load_vardesc(cnxn)
    dataddh = load_dataddh(cnxn, start_date, end_date)
    df = build_master_dataframe(dataddh, vardesc)
    scores = compute_var_health_scores(df)

    print_health_scores(scores, vardesc)


