"""
Sensor Drift Detection & Early Warning System
---------------------------------------------

This script analyzes continuous process data in the OPSDC database to detect
sensors (VARIDs) that are drifting over time. It estimates a linear trend
for each variable over a recent time window and ranks variables by the
magnitude of their drift.

WHAT THIS PROGRAM DOES:
    • Connects to the OPSDC SQL Server database.
    • Determines the latest timestamp in DATADDH and looks back N_DAYS.
    • Loads DATADDH data for that window and daily-averages each VARID.
    • For each VARID with enough daily points:
          - Fits a simple linear regression:
                CURVALUE ~ a + b * (day index)
          - Computes:
                slope (b) in units per day
                R² (goodness of fit)
                number of days used
    • If ENTRYMIN/ENTRYMAX are defined in VARDESC, it also computes:
          - relative drift per 30 days as % of the engineering range
            (how many % of (ENTRYMAX - ENTRYMIN) per 30 days)
    • Ranks variables by |relative drift| (if available) or |slope|.
    • Prints a "Top Drift" report for operators/engineers.

INTENDED USE:
    • Identify sensors that are slowly drifting but not yet in alarm.
    • Support proactive maintenance/calibration planning.
    • Highlight sensors that may cause lab/process mismatch over time.

NOTES:
    • This is a simple linear model; nonlinear patterns or oscillations are
      not captured here.
    • R² is included to help distinguish true drift from noisy scatter.

    The drift detection tool currently calculates absolute drift (slope and R²) for all variables with
    sufficient recent data. It also supports computing relative drift (percent of engineering range per 30 days)
    for variables that have ENTRYMIN and ENTRYMAX defined in VARDESC.

    In the OPSDC database, most variables do not have ENTRYMIN/ENTRYMAX configured, so the relative drift appears
    as n/a for those sensors. However, the tool is ready to use engineering limits wherever they exist and will
    automatically report relative drift once limits are configured or for any tags that already have valid ranges.
"""

from pathlib import Path
from datetime import timedelta

import pyodbc
import pandas as pd
import numpy as np


# ============================================================
# CONFIG
# ============================================================
DB_NAME = "OPSDC"

N_DAYS = 60          # Look-back window for drift analysis
MIN_DAILY_POINTS = 10  # Minimum number of daily averages required per VARID
MIN_R2_TO_REPORT = 0.2 # Only highlight drifts with at least this R²


# ============================================================
# CONNECTION
# ============================================================
def get_connection(conn_string: str) -> pyodbc.Connection:
    """Create and return a pyodbc connection to the database.
    
    Args:
        conn_string: Full ODBC connection string (provided by connection_manager).
    
    Returns:
        Active pyodbc.Connection object.
    
    Note:
        Connection string validation and persistence is handled by the
        connection_manager module in main.py. This function expects a
        pre-validated full connection string.
    """
    print("Connecting to SQL Server...")
    cnxn = pyodbc.connect(conn_string)
    print("Connected.\n")
    return cnxn


# ============================================================
# DATA LOADING
# ============================================================
def get_dataddh_window(cnxn: pyodbc.Connection) -> tuple[pd.Timestamp, pd.Timestamp]:
    """Determine min/max DATADDH timestamps and compute last N_DAYS window."""
    date_range = pd.read_sql(
        "SELECT MIN(DATESTAMP) AS mind, MAX(DATESTAMP) AS maxd FROM DATADDH",
        cnxn
    )

    if date_range.isna().all(axis=None):
        raise RuntimeError("DATADDH has no data at all. Cannot compute drift.")

    min_date = pd.to_datetime(date_range["mind"][0])
    max_date = pd.to_datetime(date_range["maxd"][0])

    start = max_date - timedelta(days=N_DAYS)
    end = max_date + timedelta(days=1)  # exclusive upper bound

    print(f"DATADDH date range in DB : {min_date.date()}  →  {max_date.date()}")
    print(f"Using drift window       : {start.date()} → {(end - timedelta(days=1)).date()}\n")

    return start, end


def load_dataddh_window(cnxn: pyodbc.Connection, start: pd.Timestamp, end: pd.Timestamp) -> pd.DataFrame:
    """Load DATADDH rows within [start, end) and compute daily averages."""
    df = pd.read_sql(
        """
        SELECT DATESTAMP, VARID, CURVALUE
        FROM DATADDH
        WHERE DATESTAMP >= ? AND DATESTAMP < ?
        """,
        cnxn,
        params=[start, end]
    )

    if df.empty:
        raise RuntimeError("No DATADDH rows in the selected window for drift detection.")

    df["DATESTAMP"] = pd.to_datetime(df["DATESTAMP"])
    df["DATE"] = df["DATESTAMP"].dt.date
    df["CURVALUE"] = pd.to_numeric(df["CURVALUE"], errors="coerce")

    # Drop rows with no numeric value
    df = df.dropna(subset=["CURVALUE"])

    print("Raw DATADDH rows in window:", len(df))

    # Daily mean per VARID
    daily = (
        df.groupby(["VARID", "DATE"])["CURVALUE"]
          .mean()
          .rename("daily_mean")
          .reset_index()
    )

    print("Daily-aggregated rows   :", len(daily))
    return daily


def load_vardesc(cnxn: pyodbc.Connection) -> pd.DataFrame:
    """Load VARDESC metadata (including ENTRYMIN / ENTRYMAX)."""
    return pd.read_sql(
        """
        SELECT 
            VARNUM AS VARID,
            NAME,
            SHORTNAME,
            UNITS,
            ENTRYMIN,
            ENTRYMAX
        FROM VARDESC
        """,
        cnxn
    )


# ============================================================
# DRIFT CALCULATION
# ============================================================
def compute_drift_for_var(daily_df: pd.DataFrame) -> dict | None:
    """
    Given a DataFrame for a single VARID with columns [DATE, daily_mean],
    fit a linear trend daily_mean ~ a + b * day_index.

    Returns a dictionary with:
        VARID, n_days, slope, r2
    or None if not enough points.
    """
    if len(daily_df) < MIN_DAILY_POINTS:
        return None

    # Sort by date and create x as integer day index
    daily_sorted = daily_df.sort_values("DATE").reset_index(drop=True)
    x = np.arange(len(daily_sorted), dtype=float)
    y = daily_sorted["daily_mean"].values.astype(float)

    # Degenerate case: all equal values → slope 0, r2 0
    if np.all(np.isclose(y, y[0])):
        return {
            "n_days": len(daily_sorted),
            "slope": 0.0,
            "r2": 0.0,
        }

    # Linear regression using polyfit
    b, a = np.polyfit(x, y, 1)  # y ≈ a + b*x

    # Compute R²
    y_pred = a + b * x
    ss_res = np.sum((y - y_pred) ** 2)
    ss_tot = np.sum((y - np.mean(y)) ** 2)
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0

    return {
        "n_days": len(daily_sorted),
        "slope": float(b),  # units per day
        "r2": float(r2),
    }


def compute_drift_for_all(daily: pd.DataFrame) -> pd.DataFrame:
    """
    Compute drift metrics for all VARIDs present in `daily` DataFrame.

    Returns DataFrame:
        VARID, n_days, slope, r2
    """
    results = []

    for varid, group in daily.groupby("VARID"):
        drift_info = compute_drift_for_var(group[["DATE", "daily_mean"]])
        if drift_info is not None:
            drift_info["VARID"] = int(varid)
            results.append(drift_info)

    if not results:
        raise RuntimeError("No VARIDs had enough data points for drift calculation.")

    drift_df = pd.DataFrame(results)
    return drift_df[["VARID", "n_days", "slope", "r2"]]


def attach_relative_drift(drift_df: pd.DataFrame, vardesc: pd.DataFrame) -> pd.DataFrame:
    """
    Attach ENTRYMIN/ENTRYMAX and compute:
        - range (ENTRYMAX - ENTRYMIN)
        - relative_drift_per_30d = (slope * 30) / range * 100  (% of range per 30 days)
    """
    vd = vardesc.copy()
    vd["ENTRYMIN"] = pd.to_numeric(vd["ENTRYMIN"], errors="coerce")
    vd["ENTRYMAX"] = pd.to_numeric(vd["ENTRYMAX"], errors="coerce")
    vd["range"] = vd["ENTRYMAX"] - vd["ENTRYMIN"]

    merged = drift_df.merge(vd, on="VARID", how="left")

    # Compute relative drift where range is valid
    valid_range = merged["range"].notna() & (merged["range"] > 0)
    merged["relative_drift_per_30d"] = np.nan

    merged.loc[valid_range, "relative_drift_per_30d"] = (
        merged.loc[valid_range, "slope"] * 30.0 / merged.loc[valid_range, "range"] * 100.0
    )

    return merged


# ============================================================
# OUTPUT
# ============================================================
def print_drift_report(drift_df: pd.DataFrame, top_n: int = 30) -> None:
    """
    Print a ranked drift report:
        - Prefer variables with defined range (relative drift).
        - Otherwise sort by absolute slope.
    """
    print("\n=== Sensor Drift Detection Report ===\n")

    # Filter by R² if desired
    df = drift_df.copy()
    df_filtered = df[df["r2"] >= MIN_R2_TO_REPORT].copy()
    if df_filtered.empty:
        print("No VARIDs met the minimum R² threshold; showing all instead.\n")
        df_filtered = df

    # Determine sorting key
    if df_filtered["relative_drift_per_30d"].notna().any():
        # Prioritize those with range-based metric
        df_with_rel = df_filtered[df_filtered["relative_drift_per_30d"].notna()].copy()
        df_with_rel["sort_key"] = df_with_rel["relative_drift_per_30d"].abs()

        df_without_rel = df_filtered[df_filtered["relative_drift_per_30d"].isna()].copy()
        df_without_rel["sort_key"] = df_without_rel["slope"].abs()

        df_sorted = pd.concat([df_with_rel, df_without_rel], ignore_index=True)
    else:
        df_filtered["sort_key"] = df_filtered["slope"].abs()
        df_sorted = df_filtered

    df_sorted = df_sorted.sort_values("sort_key", ascending=False)

    # Print top N
    count = 0
    for _, row in df_sorted.head(top_n).iterrows():
        varid = int(row["VARID"])
        name = row["SHORTNAME"] or row["NAME"]
        if pd.isna(name) or str(name).strip() == "":
            name = f"VARID {varid}"

        slope = row["slope"]
        r2 = row["r2"]
        n_days = row["n_days"]
        rel = row["relative_drift_per_30d"]

        if pd.notna(rel):
            rel_str = f"{rel:+6.2f}% / 30d"
        else:
            rel_str = "   n/a      "

        print(
            f"VARID={varid:6d} | "
            f"{name[:30].ljust(30)} | "
            f"slope={slope:+9.4f} /day | "
            f"R²={r2:4.2f} | "
            f"days={n_days:3d} | "
            f"rel_drift={rel_str}"
        )

        count += 1

    if count == 0:
        print("No drift metrics to display (check filters or data availability).")

    print("\nDone.")


# ============================================================
# MAIN
# ============================================================
def run_drift_detector(server_name) -> None:
    cnxn = get_connection(server_name)

    start, end = get_dataddh_window(cnxn)
    daily = load_dataddh_window(cnxn, start, end)
    vardesc = load_vardesc(cnxn)

    drift_raw = compute_drift_for_all(daily)
    drift_with_meta = attach_relative_drift(drift_raw, vardesc)

    # Save full table for further analysis to outputs directory
    output_dir = Path(__file__).parent.parent / "outputs"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / "sensor_drift_per_varid.csv"
    drift_with_meta.to_csv(output_path, index=False)
    print(f"Saved {output_path}\n")

    print_drift_report(drift_with_meta, top_n=30)


