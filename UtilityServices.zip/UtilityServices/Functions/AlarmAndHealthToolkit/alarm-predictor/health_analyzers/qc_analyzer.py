"""
Automated QC Flag Analyzer (Lab Data + Process Data)
----------------------------------------------------

This script identifies variables that have frequent Quality Control (QC)
problems by analyzing both formal QC flags (VARQC table) and informal
QC-related operator comments (COMMENTS table) in the OPSDC database.

WHAT THIS PROGRAM DOES:
    • Connects to the OPSDC SQL Server database.
    • Extracts all available records from:
         - VARQC  (formal QC failures)
         - COMMENTS (text-based QC issues such as “No Data”, “Missing”, etc.)
         - VARDESC (metadata for naming variables)
    • Auto-detects:
         - date column in VARQC
         - VARID column in VARQC
    • Identifies QC-related operator comments using keyword filters.
    • Computes QC metrics for every VARID:
         - Number of QC days from VARQC
         - Number of QC events from VARQC
         - Number of QC days from COMMENTS
         - Number of QC events from COMMENTS
    • Produces a combined QC Risk Score:
         QC Risk Score = (Total QC Days * 2) + Total QC Events

INTENDED USE:
    • Automatically flag variables with poor data quality.
    • Prioritize maintenance and calibration activities.
    • Support compliance, reporting, and operational decision-making.
    • Serve as an input to dashboards and reliability monitoring tools.
"""

from pathlib import Path

import pyodbc
import pandas as pd
import numpy as np


# ============================================================
# CONFIG
# ============================================================
DB_NAME = "OPSDC"


QC_COMMENT_PATTERNS = [
    "QC",
    "No Data",
    "missing",
    "NOT ANALYZED",
    "LOST",
    "INCOMPLETE",
]


# ============================================================
# CONNECTION & HELPERS
# ============================================================
def get_connection(conn_string: str) -> pyodbc.Connection:
    """Create and return a pyodbc connection to the database.
    
    Args:
        conn_string: Full ODBC connection string (provided by connection_manager).
    
    Returns:
        Active pyodbc.Connection object.
    
    Note:
        Connection string validation and persistence is handled by the
        connection_manager module in main.py. This function expects a
        pre-validated full connection string.
    """
    print("Connecting to SQL Server...")
    cnxn = pyodbc.connect(conn_string)
    print("Connected.\n")
    return cnxn


def safe_read_sql(query: str, conn: pyodbc.Connection) -> pd.DataFrame:
    """Execute a SQL query and return a DataFrame, or empty DataFrame on failure."""
    try:
        return pd.read_sql(query, conn)
    except Exception as e:
        print(f"[WARN] Failed to read SQL: {query.splitlines()[0]}...  Error: {e}")
        return pd.DataFrame()


# ============================================================
# DATA LOADING FUNCTIONS
# ============================================================
def load_vardesc(cnxn: pyodbc.Connection) -> pd.DataFrame:
    """Load variable metadata (VARDESC)."""
    return safe_read_sql(
        """
        SELECT 
            VARNUM AS VARID,
            NAME,
            SHORTNAME,
            UNITS,
            ENTRYMIN,
            ENTRYMAX
        FROM VARDESC
        """,
        cnxn
    )


def load_varqc(cnxn: pyodbc.Connection) -> pd.DataFrame:
    """
    Load VARQC and compute per-VARID counts:
        - varqc_days_with_qc
        - varqc_events

    Auto-detects:
        - a date-like column for QC date
        - a VARID-like column for variable ID
    """
    varqc_full = safe_read_sql("SELECT * FROM VARQC", cnxn)

    if varqc_full.empty:
        print("VARQC table is empty or missing.")
        return pd.DataFrame(columns=["VARID", "varqc_days_with_qc", "varqc_events"])

    print(f"Loaded {len(varqc_full)} rows from VARQC.")
    cols = list(varqc_full.columns)

    # Detect date column
    date_candidates = [c for c in cols if "DATE" in c.upper()]
    if not date_candidates:
        print("[WARN] VARQC has no column name containing 'DATE'; treating all rows as undated events.")
        date_col = None
    else:
        date_col = date_candidates[0]
        print(f"Using VARQC column '{date_col}' as date.")

    # Detect VARID column
    varid_candidates = [c for c in cols if "VAR" in c.upper() and "ID" in c.upper()]
    if not varid_candidates:
        print("[WARN] VARQC has no column name containing 'VAR' and 'ID'; cannot associate QC rows with variables.")
        return pd.DataFrame(columns=["VARID", "varqc_days_with_qc", "varqc_events"])

    varid_col = varid_candidates[0]
    print(f"Using VARQC column '{varid_col}' as VARID.\n")

    varqc = varqc_full[[varid_col] + ([date_col] if date_col else [])].copy()
    varqc = varqc.rename(columns={varid_col: "VARID"})
    varqc = varqc[varqc["VARID"].notna()]

    # Count events and days
    if date_col:
        varqc[date_col] = pd.to_datetime(varqc[date_col], errors="coerce")
        varqc["DATE"] = varqc[date_col].dt.date
        varqc_days = (
            varqc.groupby("VARID")["DATE"]
                 .nunique()
                 .rename("varqc_days_with_qc")
        )
    else:
        varqc["DATE"] = pd.NaT
        varqc_days = (
            varqc.groupby("VARID")["VARID"]
                 .count()
                 .rename("varqc_days_with_qc")
        )

    varqc_events = (
        varqc.groupby("VARID")["VARID"]
             .count()
             .rename("varqc_events")
    )

    varqc_counts = (
        varqc_days.to_frame()
        .join(varqc_events, how="outer")
        .reset_index()
    )

    varqc_counts[["varqc_days_with_qc", "varqc_events"]] = (
        varqc_counts[["varqc_days_with_qc", "varqc_events"]]
        .fillna(0)
        .astype(int)
    )

    return varqc_counts


def load_qc_comments(cnxn: pyodbc.Connection) -> pd.DataFrame:
    """
    Load COMMENTS and extract QC-related comment counts per VARID:
        - comment_qc_events
        - comment_qc_days
    """
    comments = safe_read_sql(
        """
        SELECT DATESTAMP, VARID, COMMENT
        FROM COMMENTS
        """,
        cnxn
    )

    if comments.empty:
        print("COMMENTS table is empty or missing.")
        return pd.DataFrame(columns=["VARID", "comment_qc_events", "comment_qc_days"])

    print(f"Loaded {len(comments)} rows from COMMENTS.")

    # Only comments tied to a specific VARID
    comments = comments[comments["VARID"].notna()].copy()

    # Normalize date
    if "DATESTAMP" in comments.columns:
        comments["DATESTAMP"] = pd.to_datetime(comments["DATESTAMP"], errors="coerce")
        comments["DATE"] = comments["DATESTAMP"].dt.date
    else:
        comments["DATE"] = pd.NaT

    # QC patterns
    pattern = "|".join(QC_COMMENT_PATTERNS)
    qc_comments = comments[comments["COMMENT"].str.contains(pattern, case=False, na=False)]

    print(f"Identified {len(qc_comments)} QC-related COMMENTS rows.")

    if qc_comments.empty:
        return pd.DataFrame(columns=["VARID", "comment_qc_events", "comment_qc_days"])

    # Per-VARID counts
    comment_qc_events = (
        qc_comments.groupby("VARID")["COMMENT"]
                   .count()
                   .rename("comment_qc_events")
    )

    if "DATE" in qc_comments.columns:
        comment_qc_days = (
            qc_comments.groupby("VARID")["DATE"]
                       .nunique()
                       .rename("comment_qc_days")
        )
    else:
        comment_qc_days = (
            qc_comments.groupby("VARID")["VARID"]
                       .count()
                       .rename("comment_qc_days")
        )

    comment_qc_counts = (
        comment_qc_events.to_frame()
        .join(comment_qc_days, how="outer")
        .reset_index()
    )

    comment_qc_counts[["comment_qc_events", "comment_qc_days"]] = (
        comment_qc_counts[["comment_qc_events", "comment_qc_days"]]
        .fillna(0)
        .astype(int)
    )

    return comment_qc_counts


# ============================================================
# CORE QC SUMMARY
# ============================================================
def build_qc_summary(
    varqc_counts: pd.DataFrame,
    comment_qc_counts: pd.DataFrame,
    vardesc: pd.DataFrame
) -> pd.DataFrame:
    """
    Combine VARQC-based QC metrics and COMMENT-based QC metrics
    into a per-VARID summary with a QC risk score.
    """
    all_varids = set(varqc_counts.get("VARID", [])) | set(comment_qc_counts.get("VARID", []))

    if not all_varids:
        raise RuntimeError("No QC issues found in VARQC or COMMENTS (based on current rules).")

    all_varids = sorted(all_varids)
    summary = pd.DataFrame({"VARID": all_varids})

    summary = summary.merge(varqc_counts, on="VARID", how="left")
    summary = summary.merge(comment_qc_counts, on="VARID", how="left")

    summary[["varqc_days_with_qc", "varqc_events",
             "comment_qc_events", "comment_qc_days"]] = (
        summary[["varqc_days_with_qc", "varqc_events",
                 "comment_qc_events", "comment_qc_days"]]
        .fillna(0)
        .astype(int)
    )

    # Total QC metrics
    summary["total_qc_days"] = summary["varqc_days_with_qc"] + summary["comment_qc_days"]
    summary["total_qc_events"] = summary["varqc_events"] + summary["comment_qc_events"]

    # Simple QC risk score: more QC days + events = higher score (worse)
    summary["qc_risk_score"] = (
        summary["total_qc_days"] * 2 +
        summary["total_qc_events"]
    )

    # Attach names/units
    summary = summary.merge(vardesc, on="VARID", how="left")

    return summary.sort_values("qc_risk_score", ascending=False)


# ============================================================
# OUTPUT
# ============================================================
def print_qc_summary(summary: pd.DataFrame, top_n: int = 30) -> None:
    """
    Pretty-print top variables by QC risk.
    """
    print("\n=== Automated QC Flag Analyzer: Variables with Most QC Issues ===\n")

    for _, row in summary.head(top_n).iterrows():
        raw_short = row.get("SHORTNAME")
        raw_name = row.get("NAME")

        if pd.notna(raw_short) and str(raw_short).strip():
            name = str(raw_short)
        elif pd.notna(raw_name) and str(raw_name).strip():
            name = str(raw_name)
        else:
            name = f"VARID {int(row['VARID'])}"

        print(
            f"VARID={int(row['VARID']):6d} | "
            f"{name[:35].ljust(35)} | "
            f"QC_Risk={int(row['qc_risk_score']):4d}  "
            f"(VARQC_days={row['varqc_days_with_qc']:3d}, "
            f"VARQC_events={row['varqc_events']:3d}, "
            f"Comm_days={row['comment_qc_days']:3d}, "
            f"Comm_events={row['comment_qc_events']:3d})"
        )

    print(f"\nTotal variables with at least one QC issue: {len(summary)}")
    print("Done.")


# ============================================================
# MAIN
# ============================================================
def run_qc_analyzer(server_name) -> None:
    cnxn = get_connection(server_name)

    vardesc = load_vardesc(cnxn)
    varqc_counts = load_varqc(cnxn)
    comment_qc_counts = load_qc_comments(cnxn)

    if varqc_counts.empty and comment_qc_counts.empty:
        print("\nNo QC issues found in VARQC or COMMENTS. Nothing to report.")
        return

    summary = build_qc_summary(varqc_counts, comment_qc_counts, vardesc)

    # Save full table for Excel / BI to outputs directory
    output_dir = Path(__file__).parent.parent / "outputs"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / "qc_summary_per_varid.csv"
    summary.to_csv(output_path, index=False)
    print(f"Saved {output_path}\n")

    print_qc_summary(summary, top_n=30)


