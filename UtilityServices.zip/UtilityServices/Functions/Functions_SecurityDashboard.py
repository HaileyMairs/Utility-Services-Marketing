#title: 'Security Dashboard'
#btn: 'Security Findings'
#btn: 'Table Risk Scores'
#btn: 'Database Risk Scores'
#btn: 'Device Health Status'

"""
Security Dashboard combined module for DynamicUtilityApp.
Includes backend engine and GUI wrapper.
"""

import os
from datetime import datetime
from typing import Optional
import pandas as pd
from sqlalchemy import create_engine, Column, Integer, String, Float, Text, DateTime
from sqlalchemy.orm import declarative_base, sessionmaker
from sqlalchemy.exc import SQLAlchemyError

Base = declarative_base()

# ---------------- GUI wrapper (must be first class!) ----------------
class SecurityDashboardUtility:
    def __init__(self):
        db_url = os.getenv("SEC_DASH_RESULTS_URL", "sqlite:///security_dashboard_results.db")
        self.engine = SecurityDashboardEngine(db_url)

    def _safe_session(self):
        return self.engine.SessionLocal()

    def _error(self, msg):
        return ("Message",), [(f"⚠️ {msg}",)]

    def get_security_findings(self):
        try:
            with self._safe_session() as session:
                rows = session.query(self.engine.SecurityFinding).order_by(
                    self.engine.SecurityFinding.created_at.desc()
                ).limit(500).all()
            if not rows:
                return self._error("No security findings found.")
            cols = ("ID","Source DB","Schema","Table","Column","Type","Severity","Description","Scanner","Created At")
            data = [(f.id, f.source_db or "", f.schema_name or "", f.table_name or "",
                     f.column_name or "", f.finding_type or "", f.severity or "",
                     (f.description or "")[:300], f.scanner_name or "",
                     f.created_at.strftime("%Y-%m-%d %H:%M:%S") if isinstance(f.created_at, datetime) else str(f.created_at))
                    for f in rows]
            return cols, data
        except Exception as e:
            return self._error(str(e))

    def get_table_risk_scores(self):
        try:
            with self._safe_session() as session:
                rows = session.query(self.engine.TableRiskScore).order_by(
                    self.engine.TableRiskScore.risk_score.desc()
                ).limit(500).all()
            if not rows:
                return self._error("No table risk scores found.")
            cols = ("ID","Source DB","Schema","Table","Risk Score","Risk Level","Last Calculated")
            data = [(r.id,r.source_db or "",r.schema_name or "",r.table_name or "",
                     r.risk_score,r.risk_level or "",
                     r.last_calculated_at.strftime("%Y-%m-%d %H:%M:%S") if isinstance(r.last_calculated_at, datetime) else str(r.last_calculated_at))
                    for r in rows]
            return cols, data
        except Exception as e:
            return self._error(str(e))

    def get_database_risk_scores(self):
        try:
            with self._safe_session() as session:
                rows = session.query(self.engine.DatabaseRiskScore).order_by(
                    self.engine.DatabaseRiskScore.risk_score.desc()
                ).all()
            if not rows:
                return self._error("No database risk scores found.")
            cols = ("ID","Source DB","Risk Score","Risk Level","Last Calculated")
            data = [(r.id,r.source_db or "",r.risk_score,r.risk_level or "",
                     r.last_calculated_at.strftime("%Y-%m-%d %H:%M:%S") if isinstance(r.last_calculated_at, datetime) else str(r.last_calculated_at))
                    for r in rows]
            return cols, data
        except Exception as e:
            return self._error(str(e))

    def get_device_health_status(self):
        try:
            with self._safe_session() as session:
                rows = session.query(self.engine.DeviceStatus).order_by(
                    self.engine.DeviceStatus.risk_score.desc()
                ).limit(500).all()
            if not rows:
                return self._error("No device status found.")
            cols = ("Device ID","Device Name","Status","Last Checked")
            data = []
            for d in rows:
                score = float(d.risk_score or 0.0)
                status = "Critical" if score >= 80 else "Warning" if score >= 40 else "Good"
                last_seen = d.last_seen.strftime("%Y-%m-%d %H:%M:%S") if isinstance(d.last_seen, datetime) else str(d.last_seen)
                device_name = f"Device {d.device_id}"
                data.append((d.device_id,device_name,status,last_seen))
            return cols, data
        except Exception as e:
            return self._error(str(e))


# ---------------- Backend engine ----------------
class SecurityDashboardEngine:
    class SecurityFinding(Base):
        __tablename__ = "security_findings"
        id = Column(Integer, primary_key=True)
        source_db = Column(String(255))
        schema_name = Column(String(255))
        table_name = Column(String(255))
        column_name = Column(String(255))
        finding_type = Column(String(50))
        severity = Column(String(50))
        description = Column(Text)
        scanner_name = Column(String(255))
        created_at = Column(DateTime, default=datetime.utcnow)

    class TableRiskScore(Base):
        __tablename__ = "table_risk_scores"
        id = Column(Integer, primary_key=True)
        source_db = Column(String(255))
        schema_name = Column(String(255))
        table_name = Column(String(255))
        risk_score = Column(Integer)
        risk_level = Column(String(50))
        last_calculated_at = Column(DateTime, default=datetime.utcnow)

    class DatabaseRiskScore(Base):
        __tablename__ = "database_risk_scores"
        id = Column(Integer, primary_key=True)
        source_db = Column(String(255), unique=True)
        risk_score = Column(Integer)
        risk_level = Column(String(50))
        last_calculated_at = Column(DateTime, default=datetime.utcnow)

    class DeviceStatus(Base):
        __tablename__ = "device_status"
        id = Column(Integer, primary_key=True)
        device_id = Column(String(255))
        last_seen = Column(DateTime)
        risk_score = Column(Float)

    def __init__(self, db_url: str):
        self.engine = create_engine(db_url)
        self.SessionLocal = sessionmaker(bind=self.engine)
        Base.metadata.create_all(bind=self.engine)
