"""
Gage_BatteryHealthModel.py

Self-contained utility module for DynamicUtilityApp.

- Appears in the sidebar as "Battery Health" -> "Forecast Summary"
- Uses a hard-coded connection to SQL Server (HaileyLaptop) via Windows Authentication
- Runs the BatteryForecastModel
- Displays a summary table in the GUI
"""

#title: 'Battery Health'
#btn: 'Forecast Summary'
#btn: 'Visual Forecast'

# ----------------------------------------------------------------------
# CONFIG: MODEL + DATABASE TABLE
# ----------------------------------------------------------------------
TREND_TABLE = "dbo.trend_data_daily"
MEASUREMENT_ID = 2        # which measurement_id/site to model
LOW_THRESHOLD = 11.6
CRIT_THRESHOLD = 11.3
REPLACEMENT_JUMP = 0.25   # volts
ROLLING_WINDOW = 3         # days
FORECAST_HORIZONS = [7, 30, 60]

# ----------------------------------------------------------------------
# IMPORTS
# ----------------------------------------------------------------------
import os
import tempfile
from math import erf
from dataclasses import dataclass
from typing import Optional, List, Any

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
import pyodbc

# ----------------------------------------------------------------------
# DATABASE SETTINGS
# ----------------------------------------------------------------------
SERVER_NAME = "HaileyLaptop"
DATABASE_NAME = "MCRWS-Telog"

# Attempt connection
try:
    db = pyodbc.connect(
        f"DRIVER={{ODBC Driver 17 for SQL Server}};"
        f"SERVER={SERVER_NAME};"
        f"DATABASE={DATABASE_NAME};"
        "Trusted_Connection=yes;"
    )
except pyodbc.Error as e:
    db = None
\
# ----------------------------------------------------------------------
# HELPER FUNCTION: Safe SQL query
# ----------------------------------------------------------------------
def safe_query(sql: str, params: list = None):
    """
    Execute a SQL query safely. Returns rows or raises an exception.
    """
   
    
    cursor = db.cursor()
    try:
        cursor.execute(sql, params or [])
        rows = cursor.fetchall()
    finally:
        cursor.close()
    return rows
    
# ======================================================================
#  FIRST CLASS (alphabetically): picked up by DynamicUtilityApp
# ======================================================================
class A_BatteryHealthUtility:
    """
    DynamicUtilityApp-compatible module with hard-coded database connection.
    """

    def __init__(self):
        # Hard-coded SQL Server connection
        self.db = db

        # model / table config
        self.trend_table = TREND_TABLE
        self.measurement_id = MEASUREMENT_ID
        self.low_threshold = LOW_THRESHOLD
        self.crit_threshold = CRIT_THRESHOLD
        self.replacement_jump = REPLACEMENT_JUMP
        self.rolling_window = ROLLING_WINDOW
        self.horizons = FORECAST_HORIZONS

    # ------------------------------------------------------------------
    # INTERNAL: DB helper
    # ------------------------------------------------------------------
    def _safe_query(self, sql: str, params: Optional[list[Any]] = None):
        cursor = self.db.cursor()
        cursor.execute(sql, params or [])
        rows = cursor.fetchall()
        cursor.close()
        return rows

    # ------------------------------------------------------------------
    # INTERNAL: fetch data from SQL and convert to DataFrame
    # ------------------------------------------------------------------
    def _fetch_dataframe(self) -> pd.DataFrame:
        sql = f"""
        SELECT trend_data_time, trend_data_avg, measurement_id
        FROM {self.trend_table}
        WHERE measurement_id = ?
        ORDER BY trend_data_time ASC;
        """
        rows = self._safe_query(sql, [self.measurement_id])

        if not rows:
            return pd.DataFrame(
                columns=["trend_data_time", "trend_data_avg", "measurement_id"]
            )

        data = [(r[0], float(r[1]), int(r[2])) for r in rows]
        df = pd.DataFrame(
            data,
            columns=["trend_data_time", "trend_data_avg", "measurement_id"],
        )
        return df

    # ------------------------------------------------------------------
    # INTERNAL: run the embedded BatteryForecastModel on a DataFrame
    # ------------------------------------------------------------------
    def _run_model_on_dataframe(self, df: pd.DataFrame) -> "BatteryForecastModel":
        if df.empty:
            raise RuntimeError(f"No trend data found for measurement_id={self.measurement_id}")

        with tempfile.NamedTemporaryFile(delete=False, suffix=".csv", mode="w", newline="") as tmp:
            csv_path = tmp.name
            df.to_csv(csv_path, index=False)

        try:
            model = BatteryForecastModel(
                csv_path=csv_path,
                measurement_id=self.measurement_id,
                low_threshold=self.low_threshold,
                crit_threshold=self.crit_threshold,
                replacement_jump_threshold=self.replacement_jump,
                rolling_window=self.rolling_window,
            )

            model.load_and_clean()
            model.detect_replacement_cycles()
            model.fit_decline_model()

            return model
        finally:
            try:
                os.remove(csv_path)
            except OSError:
                pass

    # ------------------------------------------------------------------
    # BUTTON HANDLER: 'Forecast Summary'
    # ------------------------------------------------------------------
    def get_forecast_summary(self):
        try:
            df = self._fetch_dataframe()
            model = self._run_model_on_dataframe(df)
        except Exception as exc:
            return ("Error",), [(str(exc),)]

        p = model.params
        days_to_low = model.estimate_days_to_threshold(self.low_threshold)
        days_to_crit = model.estimate_days_to_threshold(self.crit_threshold)

        rows = [
            ("Latest cycle ID", str(p.cycle_id)),
            ("Last timestamp", str(p.last_date)),
            ("Last voltage (V)", f"{p.last_voltage:.3f}"),
            ("Decline slope (V/day)", f"{p.slope:.6f}"),
            ("Residual sigma (V)", f"{p.noise_sigma:.4f}"),
            (f"Days to LOW ({self.low_threshold:.1f}V)", "-" if days_to_low is None else f"{days_to_low:.1f}"),
            (f"Days to CRIT ({self.crit_threshold:.1f}V)", "-" if days_to_crit is None else f"{days_to_crit:.1f}"),
        ]

        for h in self.horizons:
            rows.append(
                (f"P(V < {self.low_threshold:.1f}V) within {h} days", f"{model.probability_below_threshold_within(self.low_threshold, h):.3f}")
            )
            rows.append(
                (f"P(V < {self.crit_threshold:.1f}V) within {h} days", f"{model.probability_below_threshold_within(self.crit_threshold, h):.3f}")
            )

        columns = ("Metric", "Value")
        return columns, rows

    # ------------------------------------------------------------------
    # BUTTON HANDLER: 'Visual Forecast'
    # ------------------------------------------------------------------
    def get_visual_forecast(self):
        try:
            df = self._fetch_dataframe()
            model = self._run_model_on_dataframe(df)
        except Exception as exc:
            return ("Error",), [(str(exc),)]

        if model.params is None:
            return ("Error",), [("Model parameters not available.",)]

        p = model.params
        horizons = [0, 30, 60, 90, 180, 365]

        rows = []
        for h in horizons:
            t_future = p.cycle_last_t + h
            mean_voltage = p.intercept + p.slope * t_future
            prob_low = model.probability_below_threshold_within(self.low_threshold, h)
            prob_crit = model.probability_below_threshold_within(self.crit_threshold, h)
            rows.append((f"{h}", f"{mean_voltage:.3f}", f"{prob_low:.3f}", f"{prob_crit:.3f}"))

        columns = (
            "Days from last sample",
            "Expected Voltage (V)",
            f"P(V < {self.low_threshold:.1f} V)",
            f"P(V < {self.crit_threshold:.1f} V)",
        )
        return columns, rows

    # Optional alias
    def get_Forecast_Summary(self):
        return self.get_forecast_summary()


# ======================================================================
# MODEL CLASSES
# ======================================================================
@dataclass
class DeclineModelParams:
    slope: float
    intercept: float
    noise_sigma: float
    last_date: pd.Timestamp
    last_voltage: float
    cycle_last_t: float
    cycle_id: int


class BatteryForecastModel:
    def __init__(self, csv_path: str, measurement_id: int = 2, low_threshold: float = 11.6,
                 crit_threshold: float = 11.3, replacement_jump_threshold: float = 0.25,
                 rolling_window: int = 3):
        self.csv_path = csv_path
        self.measurement_id = measurement_id
        self.low_threshold = low_threshold
        self.crit_threshold = crit_threshold
        self.replacement_jump_threshold = replacement_jump_threshold
        self.rolling_window = rolling_window
        self.df: Optional[pd.DataFrame] = None
        self.params: Optional[DeclineModelParams] = None

    def load_and_clean(self) -> None:
        df = pd.read_csv(self.csv_path)
        df = df[df["measurement_id"] == self.measurement_id].copy()
        df["trend_data_time"] = pd.to_datetime(df["trend_data_time"])
        df["trend_data_avg"] = pd.to_numeric(df["trend_data_avg"], errors="coerce")
        df = df.dropna(subset=["trend_data_avg"])
        t0 = df["trend_data_time"].min()
        df["days_since_start"] = (df["trend_data_time"] - t0).dt.total_seconds() / 86400.0
        self.df = df.reset_index(drop=True)

    def detect_replacement_cycles(self) -> None:
        df = self.df.copy()
        df["roll_avg"] = df["trend_data_avg"].rolling(window=self.rolling_window, min_periods=1).mean()
        df["roll_diff"] = df["roll_avg"].diff()
        df["is_reset"] = (df["roll_diff"] >= self.replacement_jump_threshold).astype(int)
        df["cycle_id"] = df["is_reset"].cumsum()
        df["cycle_start_time"] = df.groupby("cycle_id")["trend_data_time"].transform("min")
        df["days_since_cycle_start"] = (df["trend_data_time"] - df["cycle_start_time"]).dt.total_seconds() / 86400.0
        self.df = df

    def fit_decline_model(self) -> None:
        df = self.df
        last_cycle_id = df["cycle_id"].max()
        cycle_df = df[df["cycle_id"] == last_cycle_id].copy()
        X = cycle_df["days_since_cycle_start"].values.reshape(-1, 1)
        y = cycle_df["trend_data_avg"].values
        lr = LinearRegression()
        lr.fit(X, y)
        slope = float(lr.coef_[0])
        intercept = float(lr.intercept_)
        y_pred = lr.predict(X)
        resid = y - y_pred
        sigma = float(np.std(resid, ddof=1)) if len(resid) > 1 else 0.0
        last_date = cycle_df["trend_data_time"].max()
        last_row = cycle_df.loc[cycle_df["trend_data_time"].idxmax()]
        last_voltage = float(last_row["trend_data_avg"])
        cycle_last_t = float(last_row["days_since_cycle_start"])
        self.params = DeclineModelParams(slope, intercept, sigma, last_date, last_voltage, cycle_last_t, last_cycle_id)

    def estimate_days_to_threshold(self, threshold: float) -> Optional[float]:
        p = self.params
        m = p.slope
        b = p.intercept
        if m >= 0:
            return None
        t_cross = (threshold - b) / m
        days_from_last = t_cross - p.cycle_last_t
        return float(max(days_from_last, 0.0))

    def probability_below_threshold_within(self, threshold: float, horizon_days: float) -> float:
        p = self.params
        m = p.slope
        b = p.intercept
        sigma = p.noise_sigma
        if sigma <= 0 or m >= 0:
            mean_voltage = b + m * (p.cycle_last_t + horizon_days)
            return 1.0 if mean_voltage < threshold else 0.0
        t_future = p.cycle_last_t + horizon_days
        mean_voltage = b + m * t_future
        z = (threshold - mean_voltage) / sigma
        return float(0.5 * (1.0 + erf(z / np.sqrt(2.0))))

