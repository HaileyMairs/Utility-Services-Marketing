''' ======================================================================
                         SIGNAL ACTIVITY UTILITY
 ======================================================================'''
#title: 'Signal Activity'
#btn: 'High Runtime Signals'
#btn: 'Flatlined Signals'

import pyodbc
from typing import List, Tuple, Any, Optional


class GenericUtility:
    """
    Signal Activity module for DynamicUtilityApp.

    Uses the REAL Telog trend table:

        dbo.trend_data

    Required columns (current schema):
        measurement_id
        trend_data_time
        trend_data_interval
        trend_data_flags
        trend_data_min
        trend_data_avg
        trend_data_max

    Buttons (from metadata above):
      - 'High Runtime Signals'  -> get_high_runtime_signals()
      - 'Flatlined Signals'     -> get_flatlined_signals()

    Each getter MUST return:
        (columns, rows)
    where:
        columns: tuple/list of column headers
        rows:    list of tuples/lists for each row
    """

    # ------------------------------------------------------------------
    # Constructor: connect to DB
    # ------------------------------------------------------------------
    def __init__(self):
        """
        Initialize DB connection.

        Adjust server / database / credentials here if needed.
        """
        self.server = "HaileyLaptop"
        self.database = "MCRWS-Telog"

        self.conn = self._connect_db()

    # ------------------------------------------------------------------
    # Defensive attribute resolution (helps with Windows quirks)
    # ------------------------------------------------------------------
    def __getattr__(self, name):
        """
        Fallback for when main.py asks for a function name that doesn't
        exist exactly as a method.

        This is here to handle cases where:
          - line endings on Windows cause hidden '\r'
          - main builds 'get_highruntimesignals' instead of
            'get_high_runtime_signals'
          - trailing whitespace sneaks into the attribute name

        Any missing attribute that looks like a "high runtime" request
        will be routed to get_high_runtime_signals().
        Any missing attribute that looks like a "flatlined" request
        will be routed to get_flatlined_signals().
        """
        lname = name.lower().strip()

        # Anything that looks like a "high runtime" request
        if lname.startswith("get_high") or "high_runtime" in lname:
            def wrapper():
                return self.get_high_runtime_signals()
            return wrapper

        # Anything that looks like "flatlined"
        if lname.startswith("get_flat") or "flatlined" in lname or "flat_line" in lname:
            def wrapper():
                return self.get_flatlined_signals()
            return wrapper

        # Otherwise, real missing attribute
        raise AttributeError("%s has no attribute '%s'" % (self.__class__.__name__, name))

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    def _connect_db(self):
        """
        Connect to SQL Server using **Windows Authentication**.
        Server example: "HaileyLaptop"
        """

        # Base connection settings
        base = (
            "SERVER=%s;"
            "DATABASE=%s;"
            "Trusted_Connection=yes;"   # <-- Windows Authentication
            "Encrypt=yes;"
            "TrustServerCertificate=yes;"
        ) % (self.server, self.database)

        # Try ODBC 18 first
        conn_str18 = (
            "DRIVER={ODBC Driver 18 for SQL Server};"
            + base +
            "Authentication=ActiveDirectoryIntegrated;"  # <-- needed for ODBC 18 WinAuth
        )

        # ODBC 17 (no AD-integrated needed)
        conn_str17 = (
            "DRIVER={ODBC Driver 17 for SQL Server};"
            + base
        )

        # FIRST: Try ODBC Driver 18
        try:
            return pyodbc.connect(conn_str18, autocommit=True, timeout=5)
        except Exception:
            pass

        # SECOND: Try ODBC Driver 17
        try:
            return pyodbc.connect(conn_str17, autocommit=True, timeout=5)
        except Exception as final_error:
            raise RuntimeError(
                "Failed to connect using Windows Authentication.\n"
                f"Server: {self.server}\n"
                f"Database: {self.database}\n"
                f"ODBC Error: {final_error}"
            )


    def _query(self, sql, params=None):
        """
        Simple query wrapper. Raises if connection is missing.
        """
        if self.conn is None:
            raise RuntimeError("Database connection not initialized.")

        cur = self.conn.cursor()
        cur.execute(sql, params or [])
        return cur.fetchall()

    # ------------------------------------------------------------------
    # 1) High Runtime Signals
    # Button: 'High Runtime Signals' -> get_high_runtime_signals()
    # ------------------------------------------------------------------
    def get_high_runtime_signals(self):
        """
        High Runtime Signals

        Uses dbo.trend_data REAL columns:
            measurement_id
            trend_data_time
            trend_data_avg

        Logic:
          - Look at the last 7 days of trend_data_avg.
          - For each measurement_id:
                sample_count  = number of rows
                active_count  = rows where trend_data_avg <> 0
                active_pct    = active_count / sample_count
                min_value     = MIN(trend_data_avg)
                max_value     = MAX(trend_data_avg)
                avg_value     = AVG(trend_data_avg)
          - Keep only signals with active_pct >= 0.5 (50%).

        Returns:
            columns = ("Signal ID", "Samples", "Active Samples",
                       "Active %", "Min", "Max", "Avg")
            rows    = list of formatted rows
        """
        days_back = 7
        min_active_pct = 0.5  # 50%

        sql = """
        WITH Recent AS (
            SELECT
                measurement_id      AS signal_id,
                trend_data_time     AS reading_time,
                trend_data_avg      AS value
            FROM dbo.trend_data
            WHERE trend_data_time >= DATEADD(DAY, -?, GETDATE())
        ),
        Agg AS (
            SELECT
                signal_id,
                COUNT(*) AS sample_count,
                SUM(CASE WHEN value IS NOT NULL AND value <> 0 THEN 1 ELSE 0 END)
                    AS active_count,
                MIN(value) AS min_value,
                MAX(value) AS max_value,
                AVG(CAST(value AS FLOAT)) AS avg_value
            FROM Recent
            GROUP BY signal_id
        )
        SELECT
            signal_id,
            sample_count,
            active_count,
            CAST(active_count * 1.0 / NULLIF(sample_count, 0) AS DECIMAL(10,4)) AS active_pct,
            min_value,
            max_value,
            avg_value
        FROM Agg
        WHERE (active_count * 1.0 / NULLIF(sample_count, 0)) >= ?
        ORDER BY active_pct DESC, sample_count DESC;
        """

        columns = (
            "Signal ID",
            "Samples",
            "Active Samples",
            "Active %",
            "Min",
            "Max",
            "Avg",
        )

        try:
            raw_rows = self._query(sql, [days_back, min_active_pct])
        except Exception as e:
            # If something goes wrong, show a message row instead of crashing the GUI
            return ("Message",), [("Error in High Runtime query: %s" % e,)]

        rows = []
        for r in raw_rows:
            signal_id, sample_count, active_count, active_pct, vmin, vmax, vavg = r
            # Defensive conversions
            sample_count = sample_count or 0
            active_count = active_count or 0
            active_pct = float(active_pct or 0.0)

            rows.append((
                str(signal_id),
                int(sample_count),
                int(active_count),
                "%.2f%%" % (active_pct * 100.0),
                "" if vmin is None else "%.3f" % float(vmin),
                "" if vmax is None else "%.3f" % float(vmax),
                "" if vavg is None else "%.3f" % float(vavg),
            ))

        return columns, rows

    # ------------------------------------------------------------------
    # 2) Flatlined Signals
    # Button: 'Flatlined Signals' -> get_flatlined_signals()
    # ------------------------------------------------------------------
    def get_flatlined_signals(self):
        """
        Flatlined Signals

        Uses dbo.trend_data REAL columns:
            measurement_id
            trend_data_time
            trend_data_avg

        Logic:
          - Look at the last 30 days of trend_data_avg.
          - For each measurement_id:
                sample_count
                min_value, max_value, avg_value
                stddev_value = STDEV(trend_data_avg)
          - Keep only signals with stddev_value <= 0.0001 (flatline).

        Returns:
            columns = ("Signal ID", "Samples", "Min", "Max", "Avg", "Std Dev")
            rows    = list of formatted rows
        """
        days_back = 30
        max_stddev = 0.0001

        sql = """
        WITH Recent AS (
            SELECT
                measurement_id  AS signal_id,
                trend_data_avg  AS value
            FROM dbo.trend_data
            WHERE trend_data_time >= DATEADD(DAY, -?, GETDATE())
        ),
        Agg AS (
            SELECT
                signal_id,
                COUNT(*) AS sample_count,
                MIN(value) AS min_value,
                MAX(value) AS max_value,
                AVG(CAST(value AS FLOAT)) AS avg_value,
                STDEV(CAST(value AS FLOAT)) AS stddev_value
            FROM Recent
            GROUP BY signal_id
        )
        SELECT
            signal_id,
            sample_count,
            min_value,
            max_value,
            avg_value,
            stddev_value
        FROM Agg
        WHERE
            sample_count > 0
            AND ISNULL(stddev_value, 0) <= ?
        ORDER BY sample_count DESC;
        """

        columns = (
            "Signal ID",
            "Samples",
            "Min",
            "Max",
            "Avg",
            "Std Dev",
        )

        try:
            raw_rows = self._query(sql, [days_back, max_stddev])
        except Exception as e:
            return ("Message",), [("Error in Flatlined query: %s" % e,)]

        rows = []
        for r in raw_rows:
            signal_id, sample_count, vmin, vmax, vavg, vstd = r
            sample_count = sample_count or 0

            rows.append((
                str(signal_id),
                int(sample_count),
                "" if vmin is None else "%.3f" % float(vmin),
                "" if vmax is None else "%.3f" % float(vmax),
                "" if vavg is None else "%.3f" % float(vavg),
                "" if vstd is None else "%.5f" % float(vstd),
            ))

        return columns, rows


# ---------------- Optional Standalone Test ----------------
if __name__ == "__main__":
    module = GenericUtility()
    for func_name in [
        "get_high_runtime_signals",
        "get_flatlined_signals",
        # extra names to simulate loader weirdness
        "get_highruntimesignals",
        "get_flatlinedsignals",
    ]:
        print("\nTESTING %s:" % func_name)
        try:
            func = getattr(module, func_name)
            cols, rows = func()
            print("COLUMNS:", cols)
            print("FIRST 3 ROWS:")
            for row in rows[:3]:
                print(row)
        except Exception as e:
            print("ERROR calling %s: %s" % (func_name, e))