"""
AlarmAndHealthToolkit.py

Integration module for DynamicUtilityApp GUI.
Opens the Alarm & Health Analyzer CLI REPL in a new console window.

The toolkit searches for main.py recursively in its directory and subdirectories,
then spawns the console with the working directory set to main.py's location.
This allows the toolkit to be placed in a parent directory while still running
main.py from its proper context.

Supported platforms:
- Windows: Uses CREATE_NEW_CONSOLE to spawn a new cmd window
- macOS: Uses AppleScript to open Terminal.app
- Linux: Tries gnome-terminal, konsole, xfce4-terminal, or xterm (in that order)

Returns an error if no supported terminal is available on the system.
"""

#title: 'Alarm & Health Toolkit'
#btn: 'Open CLI REPL'
#btn: 'Prepare Dataset DB'
#btn: 'Prepare Dataset CSV'
#btn: 'Train Model'
#btn: 'Score Dataset'
#btn: 'Predict Latest DB'
#btn: 'QC Analyzer'
#btn: 'Unit Health'
#btn: 'Flatline Detector'
#btn: 'Drift Detector'

import subprocess
import sys
import platform
from pathlib import Path
from typing import Optional


# Database names used by the workflows
DB_OPSDC = "OPSDC"
DB_MCRWS_TELOG = "MCRWS-Telog"


class AlarmAndHealthToolkit:
    """
    Integration class for the Alarm Predictor and Health Analyzer tools.
    Launches the interactive CLI menu in a separate console window.
    """

    def __init__(self):
        """Initialize the toolkit - finds main.py recursively and stores its path."""
        # Start searching from the directory where this toolkit file is located
        self.module_dir = Path(__file__).parent.resolve()
        self.main_script = self._find_main_script()
        # Working directory will be main.py's location, not the toolkit's
        self.script_dir = self.main_script.parent

    def _find_main_script(self) -> Path:
        """
        Recursively search for main.py starting from this toolkit's directory.
        Returns the path to main.py or raises FileNotFoundError if not found.
        """
        # First check if main.py is in the same directory (most common case)
        direct_path = self.module_dir / "main.py"
        if direct_path.exists():
            return direct_path
        
        # Recursively search subdirectories using rglob
        matches = list(self.module_dir.rglob("main.py"))
        if not matches:
            raise FileNotFoundError(
                f"main.py not found in {self.module_dir} or any subdirectories"
            )
        
        # If multiple matches, prefer the one closest to the toolkit (shortest path)
        matches.sort(key=lambda p: len(p.parts))
        return matches[0]

    def _setup_codebase_imports(self) -> None:
        """Add codebase directory to sys.path for importing modules."""
        codebase_dir = str(self.script_dir)
        if codebase_dir not in sys.path:
            sys.path.insert(0, codebase_dir)

    def _get_saved_connection(self, db_name: str) -> Optional[str]:
        """
        Check if a connection string is saved for the given database.
        Returns the connection string if found, None otherwise.
        """
        try:
            self._setup_codebase_imports()
            from connection_manager import load_saved_connections
            connections = load_saved_connections()
            return connections.get(db_name)
        except ImportError:
            return None

    def _make_error_table(self, error_type: str, message: str, 
                          module_name: Optional[str] = None) -> tuple:
        """
        Create a consistent error table for GUI display.
        Returns (columns, rows) tuple with error information.
        """
        columns = ("Field", "Value")
        rows = [
            ("Status", "Error"),
            ("Type", error_type),
            ("Message", message),
        ]
        if module_name:
            rows.append(("Missing Module", module_name))
            rows.append(("Solution", f"Install with: pip install {module_name}"))
        rows.append(("Alternative", "Use 'Open CLI REPL' to run in console"))
        return columns, rows

    def _open_workflow_console(self, menu_option: Optional[str] = None) -> tuple:
        """
        Open the CLI REPL in a new console window for interactive workflows.
        If menu_option is provided, that option is auto-selected via --option flag.
        Returns a status table for the GUI.
        """
        try:
            status = self._open_in_new_console(menu_option)
            success = True
        except Exception as e:
            status = f"Error: {e}"
            success = False

        columns = ("Field", "Value")
        rows = [
            ("Status", "Console Opened" if success else "Failed"),
            ("Message", status),
        ]
        if menu_option:
            rows.append(("Option", f"Auto-selected menu option {menu_option}"))
        return columns, rows

    def _open_in_new_console(self, menu_option: Optional[str] = None) -> str:
        """
        Opens main.py in a new console/terminal window based on the current OS.
        The working directory is set to main.py's location (self.script_dir).
        If menu_option is provided, passes --option flag to auto-select that menu item.
        Returns a status message indicating success or failure.
        """
        python_exe = sys.executable
        script_path = str(self.main_script)
        current_os = platform.system()
        
        # Build the command with optional --option flag
        if menu_option:
            cmd_args = [python_exe, script_path, "--option", menu_option]
            cmd_str = f"'{python_exe}' '{script_path}' --option {menu_option}"
        else:
            cmd_args = [python_exe, script_path]
            cmd_str = f"'{python_exe}' '{script_path}'"

        if current_os == "Windows":
            # Windows: use cmd /k to keep the window open after script exits
            # This allows users to see any error messages if the script crashes
            subprocess.Popen(
                ["cmd", "/k"] + cmd_args,
                creationflags=subprocess.CREATE_NEW_CONSOLE,
                cwd=str(self.script_dir)  # Run from main.py's directory
            )
            return "Workflow started in new window"

        elif current_os == "Darwin":
            # macOS: use osascript to open Terminal.app with the command
            # cd to main.py's directory before running
            apple_script = f'''
            tell application "Terminal"
                activate
                do script "cd '{self.script_dir}' && {cmd_str}"
            end tell
            '''
            subprocess.Popen(["osascript", "-e", apple_script])
            return "Workflow started in Terminal.app"

        else:
            # Linux/other: try common terminal emulators
            terminal_cmds = [
                ("gnome-terminal", ["gnome-terminal", "--"] + cmd_args),
                ("konsole", ["konsole", "-e"] + cmd_args),
                ("xfce4-terminal", ["xfce4-terminal", "-e", " ".join(cmd_args)]),
                ("xterm", ["xterm", "-e"] + cmd_args),
            ]
            for term_name, cmd in terminal_cmds:
                try:
                    subprocess.Popen(cmd, cwd=str(self.script_dir))  # Run from main.py's directory
                    return f"Workflow started in {term_name}"
                except FileNotFoundError:
                    continue  # Try next terminal emulator

            # No terminal emulator found - return error
            raise RuntimeError(
                "No supported terminal emulator found. "
                "Please install one of: gnome-terminal, konsole, xfce4-terminal, or xterm."
            )

    def get_open_cli_repl(self):
        """
        Opens the Alarm & Health Analyzer CLI REPL in a new console window.
        Returns a simple status table for the GUI.
        """
        try:
            status = self._open_in_new_console()
            success = True
        except Exception as e:
            status = f"Error: {e}"
            success = False

        # Return table format as required by the GUI
        columns = ("Field", "Value")
        rows = [
            ("Status", "Success" if success else "Failed"),
            ("Message", status),
            ("Script", str(self.main_script)),
            ("Platform", platform.system()),
        ]
        return columns, rows

    # ==================== Alarm Prediction Workflows ====================
    # These all open console windows since they require user interaction

    def get_prepare_dataset_db(self):
        """
        Prepare alarm dataset from database (menu option 1).
        Opens console with option 1 auto-selected - requires MCRWS-Telog connection.
        """
        conn_str = self._get_saved_connection(DB_MCRWS_TELOG)
        
        columns = ("Field", "Value")
        if conn_str:
            rows = [
                ("Workflow", "Prepare Alarm Dataset (DB)"),
                ("Database", DB_MCRWS_TELOG),
                ("Connection", "Saved connection found"),
            ]
        else:
            rows = [
                ("Workflow", "Prepare Alarm Dataset (DB)"),
                ("Database", DB_MCRWS_TELOG),
                ("Connection", "No saved connection - you will be prompted"),
            ]
        
        # Open console with option 1 auto-selected
        console_result = self._open_workflow_console("1")
        rows.extend(console_result[1])  # Add all status rows from console result
        return columns, rows

    def get_prepare_dataset_csv(self):
        """
        Prepare alarm dataset from CSV files (menu option 2).
        Opens console with option 2 auto-selected - no database connection needed.
        """
        columns = ("Field", "Value")
        rows = [
            ("Workflow", "Prepare Alarm Dataset (CSV)"),
            ("Database", "Not required"),
            ("Note", "You will be prompted for the CSV directory path"),
        ]
        
        # Open console with option 2 auto-selected
        console_result = self._open_workflow_console("2")
        rows.extend(console_result[1])
        return columns, rows

    def get_train_model(self):
        """
        Train LightGBM model (menu option 3).
        Opens console with option 3 auto-selected - requires prepared dataset.
        """
        columns = ("Field", "Value")
        rows = [
            ("Workflow", "Train LightGBM Model"),
            ("Prerequisite", "Prepared alarm dataset (from option 1 or 2)"),
            ("Note", "Configure training parameters interactively"),
        ]
        
        # Open console with option 3 auto-selected
        console_result = self._open_workflow_console("3")
        rows.extend(console_result[1])
        return columns, rows

    def get_score_dataset(self):
        """
        Score dataset with trained model (menu option 4).
        Opens console with option 4 auto-selected - requires trained model.
        """
        columns = ("Field", "Value")
        rows = [
            ("Workflow", "Score Dataset"),
            ("Prerequisite", "Trained LightGBM model"),
            ("Note", "Provide dataset and model paths when prompted"),
        ]
        
        # Open console with option 4 auto-selected
        console_result = self._open_workflow_console("4")
        rows.extend(console_result[1])
        return columns, rows

    def get_predict_latest_db(self):
        """
        Predict latest alarms from database (menu option 5).
        Opens console with option 5 auto-selected - requires MCRWS-Telog connection and trained model.
        """
        conn_str = self._get_saved_connection(DB_MCRWS_TELOG)
        
        columns = ("Field", "Value")
        if conn_str:
            rows = [
                ("Workflow", "Predict Latest Alarms (DB)"),
                ("Database", DB_MCRWS_TELOG),
                ("Connection", "Saved connection found"),
                ("Prerequisite", "Trained LightGBM model"),
            ]
        else:
            rows = [
                ("Workflow", "Predict Latest Alarms (DB)"),
                ("Database", DB_MCRWS_TELOG),
                ("Connection", "No saved connection - you will be prompted"),
                ("Prerequisite", "Trained LightGBM model"),
            ]
        
        # Open console with option 5 auto-selected
        console_result = self._open_workflow_console("5")
        rows.extend(console_result[1])
        return columns, rows

    # ==================== Health Analyzers ====================
    # These return table data when connection exists, otherwise open console

    def get_qc_analyzer(self):
        """
        Run QC Analyzer and return top variables by QC risk score.
        Returns table data if OPSDC connection exists, otherwise opens console.
        """
        # Check for saved connection first
        conn_str = self._get_saved_connection(DB_OPSDC)
        if not conn_str:
            columns = ("Field", "Value")
            rows = [
                ("Workflow", "QC Analyzer"),
                ("Database", DB_OPSDC),
                ("Connection", "No saved connection - opening console to prompt"),
            ]
            # Open console with option 6 auto-selected
            console_result = self._open_workflow_console("6")
            rows.extend(console_result[1])
            return columns, rows

        # Try to run the analyzer and return table data
        try:
            self._setup_codebase_imports()
            from health_analyzers.qc_analyzer import (
                get_connection, load_vardesc, load_varqc, 
                load_qc_comments, build_qc_summary
            )
            import pandas as pd
        except ImportError as e:
            # Use ImportError.name if available, otherwise fall back to string
            missing = e.name if hasattr(e, 'name') and e.name else str(e)
            return self._make_error_table("Import Error", str(e), missing)

        try:
            # Run the analyzer
            cnxn = get_connection(conn_str)
            vardesc = load_vardesc(cnxn)
            varqc_counts = load_varqc(cnxn)
            comment_qc_counts = load_qc_comments(cnxn)
            cnxn.close()

            if varqc_counts.empty and comment_qc_counts.empty:
                columns = ("Field", "Value")
                rows = [
                    ("Status", "No Data"),
                    ("Message", "No QC issues found in VARQC or COMMENTS"),
                ]
                return columns, rows

            summary = build_qc_summary(varqc_counts, comment_qc_counts, vardesc)

            # Format as table - top 30 by QC risk score
            columns = ("VARID", "Name", "QC Risk", "VARQC Days", "VARQC Events", 
                      "Comment Days", "Comment Events")
            rows = []
            for _, row in summary.head(30).iterrows():
                # Get display name
                name = row.get("SHORTNAME") or row.get("NAME") or f"VARID {int(row['VARID'])}"
                if pd.isna(name) or str(name).strip() == "":
                    name = f"VARID {int(row['VARID'])}"
                
                rows.append((
                    int(row["VARID"]),
                    str(name)[:35],
                    int(row["qc_risk_score"]),
                    int(row["varqc_days_with_qc"]),
                    int(row["varqc_events"]),
                    int(row["comment_qc_days"]),
                    int(row["comment_qc_events"]),
                ))
            
            return columns, rows

        except Exception as e:
            return self._make_error_table("Runtime Error", str(e))

    def get_unit_health(self):
        """
        Run Unit Health analyzer and return health scores for variables.
        Returns table data if OPSDC connection exists, otherwise opens console.
        """
        conn_str = self._get_saved_connection(DB_OPSDC)
        if not conn_str:
            columns = ("Field", "Value")
            rows = [
                ("Workflow", "Unit Health Scores"),
                ("Database", DB_OPSDC),
                ("Connection", "No saved connection - opening console to prompt"),
            ]
            # Open console with option 7 auto-selected
            console_result = self._open_workflow_console("7")
            rows.extend(console_result[1])
            return columns, rows

        try:
            self._setup_codebase_imports()
            from health_analyzers.unit_health import (
                get_connection, get_dataddh_date_window, load_vardesc,
                load_dataddh, build_master_dataframe, compute_var_health_scores
            )
            import pandas as pd
        except ImportError as e:
            # Use ImportError.name if available, otherwise fall back to string
            missing = e.name if hasattr(e, 'name') and e.name else str(e)
            return self._make_error_table("Import Error", str(e), missing)

        try:
            cnxn = get_connection(conn_str)
            start_date, end_date = get_dataddh_date_window(cnxn)
            vardesc = load_vardesc(cnxn)
            dataddh = load_dataddh(cnxn, start_date, end_date)
            cnxn.close()

            df = build_master_dataframe(dataddh, vardesc)
            scores = compute_var_health_scores(df)
            
            # Merge with vardesc for names
            scores = scores.merge(vardesc, on="VARID", how="left")

            # Format table - top 30 healthiest + bottom 20
            columns = ("VARID", "Name", "Health", "Availability", "In-Range", "Events")
            rows = []
            
            # Top 30 (healthiest)
            for _, row in scores.head(30).iterrows():
                name = row.get("SHORTNAME") or row.get("NAME") or f"VARID {int(row['VARID'])}"
                if pd.isna(name) or str(name).strip() == "":
                    name = f"VARID {int(row['VARID'])}"
                
                rows.append((
                    int(row["VARID"]),
                    str(name)[:30],
                    f"{row['health_score']:.1f}",
                    f"{row['availability_score']:.1f}",
                    f"{row['in_range_score']:.1f}",
                    f"{row['event_score']:.1f}",
                ))
            
            # Add separator row if we have bottom entries
            if len(scores) > 30:
                rows.append(("---", "--- Bottom 20 (Worst) ---", "---", "---", "---", "---"))
                
                # Bottom 20 (worst)
                for _, row in scores.tail(20).iterrows():
                    name = row.get("SHORTNAME") or row.get("NAME") or f"VARID {int(row['VARID'])}"
                    if pd.isna(name) or str(name).strip() == "":
                        name = f"VARID {int(row['VARID'])}"
                    
                    rows.append((
                        int(row["VARID"]),
                        str(name)[:30],
                        f"{row['health_score']:.1f}",
                        f"{row['availability_score']:.1f}",
                        f"{row['in_range_score']:.1f}",
                        f"{row['event_score']:.1f}",
                    ))

            return columns, rows

        except Exception as e:
            return self._make_error_table("Runtime Error", str(e))

    def get_flatline_detector(self):
        """
        Run Flatline Detector and return suspected flatline/dead sensors.
        Returns table data if OPSDC connection exists, otherwise opens console.
        """
        conn_str = self._get_saved_connection(DB_OPSDC)
        if not conn_str:
            columns = ("Field", "Value")
            rows = [
                ("Workflow", "Flatline Detector"),
                ("Database", DB_OPSDC),
                ("Connection", "No saved connection - opening console to prompt"),
            ]
            # Open console with option 8 auto-selected
            console_result = self._open_workflow_console("8")
            rows.extend(console_result[1])
            return columns, rows

        try:
            self._setup_codebase_imports()
            from health_analyzers.flatline_detector import (
                get_connection, get_dataddh_date_range, load_recent_dataddh,
                load_global_last_seen, load_vardesc, compute_per_var_stats,
                build_full_sensor_table, N_DAYS_WINDOW
            )
            from datetime import timedelta
            import pandas as pd
        except ImportError as e:
            # Use ImportError.name if available, otherwise fall back to string
            missing = e.name if hasattr(e, 'name') and e.name else str(e)
            return self._make_error_table("Import Error", str(e), missing)

        try:
            cnxn = get_connection(conn_str)
            min_ts, max_ts = get_dataddh_date_range(cnxn)
            window_start = max_ts - timedelta(days=N_DAYS_WINDOW)
            window_end = max_ts + timedelta(days=1)

            df_window = load_recent_dataddh(cnxn, window_start, window_end)
            last_seen_global = load_global_last_seen(cnxn)
            vardesc = load_vardesc(cnxn)
            cnxn.close()

            stats_in_window = compute_per_var_stats(df_window)
            full_table = build_full_sensor_table(
                stats_in_window, last_seen_global, window_start, max_ts, vardesc
            )

            # Get flatline suspects and dead sensors
            flatliners = full_table[full_table["flatline_suspect"]].copy()
            flatliners = flatliners.sort_values("n_points", ascending=False)

            dead_sensors = full_table[full_table["dead_sensor"]].copy()
            dead_sensors = dead_sensors.sort_values("last_seen")

            columns = ("VARID", "Name", "Type", "Points", "Days", "Min", "Max", "Unique")
            rows = []

            # Top 30 flatline suspects
            for _, row in flatliners.head(30).iterrows():
                name = row.get("SHORTNAME") or row.get("NAME") or f"VARID {int(row['VARID'])}"
                if pd.isna(name) or str(name).strip() == "":
                    name = f"VARID {int(row['VARID'])}"

                rows.append((
                    int(row["VARID"]),
                    str(name)[:30],
                    "Flatline",
                    int(row["n_points"]),
                    int(row["n_days"]),
                    f"{row['min_val']:.2f}" if pd.notna(row["min_val"]) else "N/A",
                    f"{row['max_val']:.2f}" if pd.notna(row["max_val"]) else "N/A",
                    int(row["n_unique_values"]) if pd.notna(row["n_unique_values"]) else 0,
                ))

            # Add dead sensors (up to 20)
            if not dead_sensors.empty:
                rows.append(("---", "--- Dead Sensors ---", "---", "---", "---", "---", "---", "---"))
                for _, row in dead_sensors.head(20).iterrows():
                    name = row.get("SHORTNAME") or row.get("NAME") or f"VARID {int(row['VARID'])}"
                    if pd.isna(name) or str(name).strip() == "":
                        name = f"VARID {int(row['VARID'])}"

                    rows.append((
                        int(row["VARID"]),
                        str(name)[:30],
                        "Dead",
                        int(row["n_points"]) if pd.notna(row["n_points"]) else 0,
                        int(row["n_days"]) if pd.notna(row["n_days"]) else 0,
                        "N/A",
                        "N/A",
                        0,
                    ))

            if not rows:
                columns = ("Field", "Value")
                rows = [
                    ("Status", "No Issues Found"),
                    ("Message", "No flatline or dead sensors detected"),
                ]

            return columns, rows

        except Exception as e:
            return self._make_error_table("Runtime Error", str(e))

    def get_drift_detector(self):
        """
        Run Drift Detector and return top drifting sensors.
        Returns table data if OPSDC connection exists, otherwise opens console.
        """
        conn_str = self._get_saved_connection(DB_OPSDC)
        if not conn_str:
            columns = ("Field", "Value")
            rows = [
                ("Workflow", "Drift Detector"),
                ("Database", DB_OPSDC),
                ("Connection", "No saved connection - opening console to prompt"),
            ]
            # Open console with option 9 auto-selected
            console_result = self._open_workflow_console("9")
            rows.extend(console_result[1])
            return columns, rows

        try:
            self._setup_codebase_imports()
            from health_analyzers.drift_detector import (
                get_connection, get_dataddh_window, load_dataddh_window,
                load_vardesc, compute_drift_for_all, attach_relative_drift,
                MIN_R2_TO_REPORT
            )
            import pandas as pd
            import numpy as np
        except ImportError as e:
            # Use ImportError.name if available, otherwise fall back to string
            missing = e.name if hasattr(e, 'name') and e.name else str(e)
            return self._make_error_table("Import Error", str(e), missing)

        try:
            cnxn = get_connection(conn_str)
            start, end = get_dataddh_window(cnxn)
            daily = load_dataddh_window(cnxn, start, end)
            vardesc = load_vardesc(cnxn)
            cnxn.close()

            drift_raw = compute_drift_for_all(daily)
            drift_df = attach_relative_drift(drift_raw, vardesc)

            # Filter by R² threshold
            df_filtered = drift_df[drift_df["r2"] >= MIN_R2_TO_REPORT].copy()
            if df_filtered.empty:
                df_filtered = drift_df.copy()

            # Sort by absolute drift (prefer relative if available)
            if df_filtered["relative_drift_per_30d"].notna().any():
                df_with_rel = df_filtered[df_filtered["relative_drift_per_30d"].notna()].copy()
                df_with_rel["sort_key"] = df_with_rel["relative_drift_per_30d"].abs()
                
                df_without_rel = df_filtered[df_filtered["relative_drift_per_30d"].isna()].copy()
                df_without_rel["sort_key"] = df_without_rel["slope"].abs()
                
                df_sorted = pd.concat([df_with_rel, df_without_rel], ignore_index=True)
            else:
                df_filtered["sort_key"] = df_filtered["slope"].abs()
                df_sorted = df_filtered

            df_sorted = df_sorted.sort_values("sort_key", ascending=False)

            columns = ("VARID", "Name", "Slope/day", "R²", "Days", "Drift %/30d")
            rows = []

            for _, row in df_sorted.head(30).iterrows():
                name = row.get("SHORTNAME") or row.get("NAME") or f"VARID {int(row['VARID'])}"
                if pd.isna(name) or str(name).strip() == "":
                    name = f"VARID {int(row['VARID'])}"

                rel_drift = row["relative_drift_per_30d"]
                rel_str = f"{rel_drift:+.2f}%" if pd.notna(rel_drift) else "N/A"

                rows.append((
                    int(row["VARID"]),
                    str(name)[:30],
                    f"{row['slope']:+.4f}",
                    f"{row['r2']:.2f}",
                    int(row["n_days"]),
                    rel_str,
                ))

            if not rows:
                columns = ("Field", "Value")
                rows = [
                    ("Status", "No Drift Detected"),
                    ("Message", "No significant drift found in the analysis window"),
                ]

            return columns, rows

        except Exception as e:
            return self._make_error_table("Runtime Error", str(e))


# ---------------- Optional Standalone Test ----------------
if __name__ == "__main__":
    toolkit = AlarmAndHealthToolkit()
    cols, rows = toolkit.get_open_cli_repl()
    print(f"\nColumns: {cols}")
    for row in rows:
        print(row)

