#title: 'Battery Maintenance'
#btn: 'Inventory'
#btn: 'Replacements'
#btn: 'Battery Low Alarms'

import pyodbc
from typing import List, Tuple


class BatteryMaintenance:
    """
    DynamicUtilityApp module for browsing battery-related tables
    from the Telog SQL Server database.
    """

    def __init__(self):

        self.conn = None
        self.conn_error = None

        try:
            self.conn = pyodbc.connect(
                "DRIVER={ODBC Driver 17 for SQL Server};"
                "SERVER=HAILEYLAPTOP;"
                "DATABASE=MCRWS-Telog;"
                "Trusted_Connection=yes;"
            )
        except Exception as e:
            self.conn_error = str(e)

    # ---------------- Helper -----------------

    def _query(self, sql: str, params: Tuple = ()) -> Tuple[Tuple[str, ...], List[Tuple]]:
        if self.conn is None:
            msg = self.conn_error or "Could not connect to database."
            return ("Message",), [(msg,)]

        cur = self.conn.cursor()
        try:
            cur.execute(sql, params)
            cols = tuple(col[0] for col in cur.description)
            rows = [tuple(row) for row in cur.fetchmany(300)]
        finally:
            cur.close()
        return cols, rows

    # ---------------- Inventory -----------------

    def get_inventory(self):
        """
        Shows recorder and battery information from:
        - RecInfoTable
        - rec_battery_info
        - site_rec_view
        - sites
        """

        sql = """
        SELECT TOP 300
            r.RecIdKey            AS RecorderID,
            r.RecType             AS RecorderType,
            r.CreatedOn           AS CreatedDate,

            -- Internal battery information
            bi.int_battery_level       AS IntBatteryLevel,
            bi.int_battery_status_text AS IntBatteryStatus,
            bi.int_battery_last_updated AS IntBatteryLastUpdated,

            -- External battery information
            bi.ext_battery_level       AS ExtBatteryLevel,
            bi.ext_battery_status_text AS ExtBatteryStatus,
            bi.ext_battery_last_updated AS ExtBatteryLastUpdated,

            s.site_name           AS SiteName,
            s.site_status         AS SiteStatus
        FROM [MCRWS-Telog].dbo.RecInfoTable AS r
        LEFT JOIN [MCRWS-Telog].dbo.rec_battery_info AS bi
            ON r.RecIdKey = bi.RecIdKey
        LEFT JOIN [MCRWS-Telog].dbo.site_rec_view AS srv
            ON r.RecIdKey = srv.RecIdKey
        LEFT JOIN [MCRWS-Telog].dbo.sites AS s
            ON srv.site_id = s.site_id
        ORDER BY bi.int_battery_last_updated DESC;
        """

        return self._query(sql)

    # ---------------- Battery Replacements -----------------

    def get_replacements(self):
        """
        Shows replacement history:
        - rec_battery_replacements
        - batteries
        - battery_types
        """

        sql = """
        SELECT TOP 300
            rr.rec_id                AS RecorderID,
            rr.replacement_date      AS ReplacementDate,
            b.battery_name           AS BatteryName,
            bt.battery_type_name     AS BatteryType,
            rr.rec_battery_status_text AS StatusText,
            rr.comments              AS Comments,
            s.site_name              AS SiteName
        FROM [MCRWS-Telog].dbo.rec_battery_replacements AS rr
        LEFT JOIN [MCRWS-Telog].dbo.batteries AS b
            ON rr.battery_id = b.battery_id
        LEFT JOIN [MCRWS-Telog].dbo.battery_types AS bt
            ON b.battery_type_id = bt.battery_type_id
        LEFT JOIN [MCRWS-Telog].dbo.site_rec_view AS srv
            ON rr.rec_id = srv.RecIdKey
        LEFT JOIN [MCRWS-Telog].dbo.sites AS s
            ON srv.site_id = s.site_id
        ORDER BY rr.replacement_date DESC;
        """

        return self._query(sql)

    # ---------------- Battery Low Alarms -----------------

    def get_battery_low_alarms(self):
        """
        Shows battery-related alarms from alarm_history.
        Looks at alarm_title for battery text.
        """

        sql = """
        SELECT TOP 300
            ah.alarm_history_id      AS AlarmID,
            ah.alarm_activation_time AS AlarmTime,
            ah.alarm_title           AS AlarmTitle,
            s.site_name              AS SiteName
        FROM [MCRWS-Telog].dbo.alarm_history AS ah
        LEFT JOIN [MCRWS-Telog].dbo.sites AS s
            ON ah.site_id = s.site_id
        WHERE ah.alarm_title LIKE '%battery%'
        ORDER BY ah.alarm_activation_time DESC;
        """

        return self._query(sql)


# ---------- Optional Standalone Test ----------
if __name__ == "__main__":
    mod = BatteryMaintenance()
    for name in ["get_inventory", "get_replacements", "get_battery_low_alarms"]:
        print(f"\n=== {name} ===")
        cols, rows = getattr(mod, name)()
        print(cols)
        for r in rows[:5]:
            print(r)
