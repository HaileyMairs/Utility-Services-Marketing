# Route_Optimizer_Integrated.py
#title: Route Optimizer
#btn: Launch Route Optimizer

from __future__ import annotations
from typing import Dict, List, Tuple, Optional
import math
import webbrowser

Coordinate = Tuple[float, float]
DeviceLocationDict = Dict[str, Coordinate]


class RouteOptimizerApp:
    """GUI-friendly Route Optimizer for DynamicUtilityApp Treeview integration."""

    OFFICE_NAME = "General Office (5300 S. Collins, Arlington, TX 76018)"
    OFFICE_COORD: Coordinate = (32.65954, -97.08976)

    # ---------------- Device Location Class ----------------
    class DeviceLocations:
        def __init__(self, mock: DeviceLocationDict = None):
            if mock is None:
                self.MOCK_DEVICE_COORDS = {
                    f"DEV{i:03d}": ((32.0 + 0.05 * i), (-97.0 + 0.05 * i))
                    for i in range(1, 21)
                }
            else:
                self.MOCK_DEVICE_COORDS = mock

        def get_device_locations(self, device_ids: List[str]) -> DeviceLocationDict:
            out = {}
            for dev in device_ids:
                if dev not in self.MOCK_DEVICE_COORDS:
                    raise ValueError(f"{dev} not found in demo set (DEV001–DEV020)")
                out[dev] = self.MOCK_DEVICE_COORDS[dev]
            return out

    # ---------------- Shortest Path ----------------
    class ShortestPath:
        @staticmethod
        def compute_route(
            locs: DeviceLocationDict,
            start_coord: Optional[Coordinate] = None
        ) -> tuple[list[str], float]:

            ids = list(locs.keys())
            if not ids:
                return [], 0.0

            curr = ids[0]
            unvisited = set(ids)
            route = []
            total_km = 0.0

            if start_coord:
                total_km += RouteOptimizerApp.ShortestPath._haversine(start_coord, locs[curr])

            while unvisited:
                route.append(curr)
                unvisited.remove(curr)
                if not unvisited:
                    break

                best = None
                best_dist = float("inf")

                for cand in unvisited:
                    d = RouteOptimizerApp.ShortestPath._haversine(locs[curr], locs[cand])
                    if d < best_dist:
                        best = cand
                        best_dist = d

                total_km += best_dist
                curr = best

            if start_coord:
                total_km += RouteOptimizerApp.ShortestPath._haversine(locs[route[-1]], start_coord)

            return route, total_km

        @staticmethod
        def _haversine(a: Coordinate, b: Coordinate) -> float:
            lat1, lon1 = a
            lat2, lon2 = b
            R = 6371
            dlat = math.radians(lat2 - lat1)
            dlon = math.radians(lon2 - lon1)
            lat1, lat2 = map(math.radians, (lat1, lat2))
            h = (math.sin(dlat/2)**2 +
                 math.cos(lat1)*math.cos(lat2)*math.sin(dlon/2)**2)
            return 2 * R * math.atan2(math.sqrt(h), math.sqrt(1 - h))

    # ---------------- INIT ----------------
    def __init__(self):
        self.device_locator = self.DeviceLocations()
        self.shortest_path = self.ShortestPath()
        self.google_maps_url = ""

    # ---------------- DECLARATIVE UI LAYOUT ----------------
    def get_launch_route_optimizer(self):

        office_text = (
            f"{self.OFFICE_NAME}\n"
            f"({self.OFFICE_COORD[0]}, {self.OFFICE_COORD[1]})"
        )

        return {
            "columns": ("Question", "Answer"),
            "rows": [
                {
                    "label": "1 = Demo, 2 = Real DB:",
                    "type": "input",
                    "id": "mode"
                },
                {
                    "label": "Enter device IDs (comma-separated):",
                    "type": "input",
                    "id": "device_ids"
                },
                {
                    "label": "Start/End Location:",
                    "type": "output",
                    "id": "office",
                    "value": office_text
                },
                {
                    "label": "Compute Route:",
                    "type": "button",
                    "id": "compute_btn"
                },
                {
                    "label": "Optimized Route:",
                    "type": "output",
                    "id": "route"
                },
                {
                    "label": "Total Distance (km):",
                    "type": "output",
                    "id": "distance"
                },
                {
                    "label": "Open in Google Maps:",
                    "type": "button",
                    "id": "maps_btn"
                }
            ]
        }

    # ---------------- CALCULATION HANDLER (called by main.py) ----------------
    def on_compute_route(self, table_inputs: dict) -> dict:
        """
        Called when main.py detects the Compute Route button press.
        Returns a dict mapping output IDs -> output text.
        """

        raw_ids = table_inputs.get("device_ids", "").strip()
        if not raw_ids:
            return {"error": "Enter device IDs first"}

        device_ids = [d.strip() for d in raw_ids.split(",") if d.strip()]
        locs = self.device_locator.get_device_locations(device_ids)

        route, total_km = self.shortest_path.compute_route(locs, self.OFFICE_COORD)

        # Build Google Maps URL
        waypoints = "|".join(f"{locs[d][0]},{locs[d][1]}" for d in route)
        self.google_maps_url = (
            f"https://www.google.com/maps/dir/?api=1"
            f"&origin={self.OFFICE_COORD[0]},{self.OFFICE_COORD[1]}"
            f"&destination={self.OFFICE_COORD[0]},{self.OFFICE_COORD[1]}"
            f"&waypoints={waypoints}"
            "&travelmode=driving"
        )

        return {
            "route": " → ".join(route),
            "distance": f"{total_km:.2f}"
        }

    # ---------------- OPEN MAPS ----------------
    def open_google_maps(self):
        if self.google_maps_url:
            webbrowser.open(self.google_maps_url)
