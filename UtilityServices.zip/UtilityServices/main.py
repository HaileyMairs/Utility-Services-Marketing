# main.py
# 11/12/25 16:30
# Dynamic Utility App with per-module Treeview / Route Optimizer GUI (fully inline answers)

import os
import importlib.util
import threading
import tkinter as tk
from tkinter import ttk, messagebox

# ---------------- Colors ----------------
BG_BLACK = "#000000"
CREAM = "#FFF8E1"
DARK_GREEN = "#0b5d3b"
PANEL_BG = "#0f0f0f"

class DynamicUtilityApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Dynamic Utility App")
        self.state("zoomed")
        self.configure(bg=BG_BLACK)


        self._setup_styles()
        self._create_sidebar()
        self._create_main_panel()

        self.build_dynamic_sidebar()

    # ---------------- Styles ----------------
    def _setup_styles(self):
        s = ttk.Style(self)
        s.theme_use("clam")
        s.configure("Treeview",
                    background=BG_BLACK,
                    foreground=CREAM,
                    fieldbackground=BG_BLACK,
                    rowheight=28,
                    font=("Segoe UI", 10))
        s.configure("Treeview.Heading",
                    background=DARK_GREEN,
                    foreground=CREAM,
                    font=("Segoe UI", 10, "bold"))
        s.map("Treeview",
              background=[('selected', '#1a7b50')],
              foreground=[('selected', 'white')])

    # ---------------- Sidebar ----------------
    def _create_sidebar(self):
        self.sidebar = tk.Frame(self, bg=PANEL_BG, width=220)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        tk.Label(
            self.sidebar,
            text="Menu",
            font=("Segoe UI", 14, "bold"),
            bg=PANEL_BG,
            fg=CREAM
        ).pack(pady=(16, 8))

        button_frame_container = tk.Frame(self.sidebar, bg=PANEL_BG)
        button_frame_container.pack(fill="both", expand=True)

        self.menu_canvas = tk.Canvas(button_frame_container, bg=PANEL_BG, highlightthickness=0)
        self.menu_canvas.pack(side="left", fill="both", expand=True)

        self.menu_scrollbar = tk.Scrollbar(button_frame_container, orient="vertical", command=self.menu_canvas.yview)
        self.menu_scrollbar.pack(side="right", fill="y")
        self.menu_canvas.configure(yscrollcommand=self.menu_scrollbar.set)

        self.menu_buttons_frame = tk.Frame(self.menu_canvas, bg=PANEL_BG)
        self.menu_window = self.menu_canvas.create_window((0, 0), window=self.menu_buttons_frame, anchor="nw")

        def resize_buttons(event):
            self.menu_canvas.itemconfig(self.menu_window, width=event.width)
        self.menu_canvas.bind("<Configure>", resize_buttons)

        self.menu_buttons_frame.bind(
            "<Configure>",
            lambda e: self.menu_canvas.configure(scrollregion=self.menu_canvas.bbox("all"))
        )

    # ---------------- Main Panel ----------------
    def _create_main_panel(self):
        self.main_frame = tk.Frame(self, bg=BG_BLACK)
        self.main_frame.pack(side="left", fill="both", expand=True, padx=8, pady=8)

        self.title_label = tk.Label(
            self.main_frame, text="", font=("Segoe UI", 18, "bold"),
            bg=BG_BLACK, fg=CREAM, anchor="w"
        )
        self.title_label.pack(fill="x", pady=(0, 5))


    # ---------------- Load Module ----------------
    def load_module_class(self, file_path):
        spec = importlib.util.spec_from_file_location(os.path.basename(file_path), file_path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        cls = None
        for name, obj in mod.__dict__.items():
            if isinstance(obj, type) and obj.__module__ == mod.__name__:
                cls = obj
                break
        if cls is None:
            raise Exception(f"No class found in {file_path}")
        try:
            instance = cls()
        except TypeError:
            instance = cls
        return instance

    # ---------------- Call Module Function ----------------
    def call_module_function(self, module_instance, btn_name):
        # Clear main_frame except title
        for widget in self.main_frame.winfo_children():
            if widget != self.title_label:
                widget.destroy()

        self.title_label.config(text=btn_name)

        # Get layout declaration from module
        try:
            func_name = "get_" + btn_name.lower().replace(" ", "_")
            func = getattr(module_instance, func_name)
            layout = func()
        except Exception as e:
            tk.Label(self.main_frame, text=f"Error: {e}", fg="red", bg=BG_BLACK).pack()
            return

        # If module uses declarative layout → build form UI
        if isinstance(layout, dict) and "rows" in layout:
            self.build_route_optimizer_ui(module_instance, layout)
            return

        # Otherwise fallback to Treeview (old behavior)
        cols, rows = layout
        frame = tk.Frame(self.main_frame, bg=BG_BLACK)
        frame.pack(fill="both", expand=True)
        tree = ttk.Treeview(frame, columns=cols, show="headings")
        tree.pack(side="left", fill="both", expand=True)
        scrollbar = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        scrollbar.pack(side="right", fill="y")
        tree.configure(yscrollcommand=scrollbar.set)

        tree["columns"] = cols
        for c in cols:
            tree.heading(c, text=c)
            tree.column(c, width=150)

        if not rows:
    # put "No data found" in the first column and blanks for the rest
            tree.insert("", "end", values=["No data found"] + [""] * (len(cols) - 1))
        else:
            for r in rows:
                tree.insert("", "end", values=r)

    def build_route_optimizer_ui(self, module_instance, layout):
        rows = layout["rows"]
        self.route_inputs = {}

        container = tk.Frame(self.main_frame, bg=BG_BLACK)
        container.pack(fill="both", expand=True, padx=20, pady=20)

        for row in rows:
            frame = tk.Frame(container, bg=BG_BLACK)
            frame.pack(fill="x", pady=4)

            tk.Label(frame, text=row["label"], fg=CREAM, bg=BG_BLACK, width=35, anchor="w").pack(side="left")

            rtype = row["type"]
            row_id = row["id"]

            # Text input
            if rtype == "input":
                entry = tk.Entry(frame, width=50)
                entry.pack(side="left")
                self.route_inputs[row_id] = entry

            # Output label
            elif rtype == "output":
                val = row.get("value", "")
                lbl = tk.Label(frame, text=val, fg=CREAM, bg=BG_BLACK)
                lbl.pack(side="left")
                self.route_inputs[row_id] = lbl

            # Button
            elif rtype == "button":
                if row_id == "compute_btn":
                    tk.Button(frame, text="Compute Route",
                              command=lambda: self.run_route_compute(module_instance)
                              ).pack(side="left")
                elif row_id == "maps_btn":
                    tk.Button(frame, text="Open Google Maps",
                              command=module_instance.open_google_maps
                              ).pack(side="left")

    def run_route_compute(self, module_instance):
        # Gather all input values
        data = {}
        for k, widget in self.route_inputs.items():
            if isinstance(widget, tk.Entry):
                data[k] = widget.get()

        # Compute route
        result = module_instance.on_compute_route(data)

        if "error" in result:
            messagebox.showerror("Error", result["error"])
            return

        # Update output widgets
        if "route" in result:
            self.route_inputs["route"].config(text=result["route"])

        if "distance" in result:
            self.route_inputs["distance"].config(text=result["distance"])

    # ---------------- Build Widget Table ----------------
    def build_widget_table(self, module_instance, data):
        rows = data["rows"]

        # Store entries for retrieving values
        self.widget_inputs = {}

        table = tk.Frame(self.main_frame, bg=BG_BLACK)
        table.pack(fill="both", expand=True, pady=15)

        for row in rows:
            row_frame = tk.Frame(table, bg=BG_BLACK)
            row_frame.pack(fill="x", pady=5)

            lbl = tk.Label(row_frame, text=row["label"], bg=BG_BLACK, fg=CREAM, font=("Segoe UI", 12))
            lbl.pack(side="left", padx=10)

            t = row["type"]
            row_id = row["id"]

            if t == "input":
                entry = tk.Entry(row_frame, width=45)
                entry.pack(side="left", padx=10)
                self.widget_inputs[row_id] = entry

            elif t == "output":
                out_lbl = tk.Label(row_frame, text="", bg=BG_BLACK, fg="#7fffd4", font=("Segoe UI", 12, "bold"))
                out_lbl.pack(side="left", padx=10)
                self.widget_inputs[row_id] = out_lbl

            elif t == "button":
                btn = tk.Button(
                    row_frame,
                    text="Open",
                    bg=DARK_GREEN,
                    fg=CREAM,
                    command=lambda m=module_instance: m.open_google_maps()
                )
                btn.pack(side="left", padx=10)

    # ---------------- Build Dynamic Sidebar ----------------
    def build_dynamic_sidebar(self):
        folder = os.path.join(os.path.dirname(__file__), "Functions")
        if not os.path.exists(folder):
            return
        for root, _, files in os.walk(folder):
            for file in files:
                if not file.endswith(".py"):
                    continue
                full_path = os.path.join(root, file)
                title = None
                btns = []
                with open(full_path, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if line.startswith("#title:"):
                            title = line.split(":", 1)[1].strip().strip("'\"")
                        elif line.startswith("#btn:"):
                            btn_name = line.split(":", 1)[1].strip().strip("'\"")
                            btns.append((btn_name, full_path))
                if not title or not btns:
                    continue

                container = tk.Frame(self.menu_buttons_frame, bg=PANEL_BG)
                container.pack(fill="x")
                main_btn = tk.Button(
                    container,
                    text=f"{title} ▸",
                    bg=DARK_GREEN,
                    fg=CREAM,
                    relief="flat",
                    anchor="w"
                )
                main_btn.pack(fill="x", padx=12, pady=6)

                frame = tk.Frame(container, bg=PANEL_BG)
                frame.pack(fill="x", padx=12, pady=0)
                frame.pack_forget()

                def toggle(f=frame, b=main_btn, t=title):
                    if f.winfo_ismapped():
                        f.pack_forget()
                        b.config(text=f"{t} ▸")
                    else:
                        f.pack(fill="x", padx=12)
                        b.config(text=f"{t} ▾")
                main_btn.config(command=toggle)

                for btn_name, module_file in btns:

                    mod_instance = self.load_module_class(module_file)
                    tk.Button(
                        frame,
                        text=btn_name,
                        bg=PANEL_BG,
                        fg=CREAM,
                        relief="flat",
                        anchor="w",
                        padx=12,
                        command=lambda m=mod_instance, b=btn_name: self.call_module_function(m, b)
                    ).pack(fill="x", pady=2)

    
# ---------------- Run App ----------------
if __name__ == "__main__":
    app = DynamicUtilityApp()
    app.mainloop()
